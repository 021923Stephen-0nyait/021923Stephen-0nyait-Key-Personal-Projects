const AWS = require("aws-sdk");

const api = new AWS.ApiGatewayManagementApi({
    endpoint:"17dus9o0fb.execute-api.us-east-1.amazonaws.com/production"
})

exports.handler = async (event) => {
    let eventBody =JSON.parse(event.body)
    let currency= eventBody.crypto_currency
    let sentiment=""
    
    //If statment to get the sentiment for all the crypto currencies
    if (currency=="all") {
        let neutral_sentiment = await get_sentiment('NEUTRAL')
        let negative_sentiment = await get_sentiment('NEGATIVE')
        let mixed_sentiment = await get_sentiment('MIXED')
        let positive_sentiment = await get_sentiment('POSITIVE')
        sentiment= JSON.stringify({TYPE:'Pie',STAGE:'initial',CURRENCY:currency,POSITIVE:positive_sentiment,NEGATIVE:negative_sentiment,MIXED:mixed_sentiment,NEUTRAL:neutral_sentiment})
    }
    //If statment to get the sentiment for indivdual crypto currencies
    if (currency!="all") {
        let crypto_neutral = await sentiment_by_name(currency,"NEUTRAL")
        let crypto_negative = await sentiment_by_name(currency,"NEGATIVE")
        let crypto_mixed = await sentiment_by_name(currency,"MIXED")
        let crypto_positive = await sentiment_by_name(currency,"POSITIVE")
        sentiment= JSON.stringify({TYPE:'Pie',STAGE:'initial',CURRENCY:currency,POSITIVE:crypto_positive,NEGATIVE:crypto_negative,MIXED:crypto_mixed,NEUTRAL:crypto_neutral})
    }
    //Users websocket connection id
    let ConnIds= event.requestContext["connectionId"]

    //Send the sentiment found back to the user
    await sendData(sentiment,ConnIds)
    
    // TODO implement
    const response = {
        statusCode: 200,
    };
    return response;
};


//Function to send sentiment back to the current user who used made a connection to the server
async function sendData(response,connID) {
    let data = {message:response}
    let params={
        ConnectionId:connID,
        Data: Buffer.from(response)
    }
    return api.postToConnection(params).promise()
}

//Function to get all the sentiment for all of the currencies
async function get_sentiment(sentiment) {

    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    //Table name and data for table
    let params = {
        TableName: "crypto_sentiment",
        IndexName: "crypto_sentiment-index",
        KeyConditionExpression: "crypto_sentiment = :sentiment",
        ExpressionAttributeValues: {
            ":sentiment" : {S:sentiment}
        }
    };

//Gets a single item

    try{
        let result = await documentClient.query(params).promise();

        return result.Count
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

//Function to get all the sentiment for one of the currencies
async function sentiment_by_name(crypto,sentiment) {

    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    //Table name and data for table
    let params = {
        TableName: "crypto_sentiment",
        IndexName: "crypto_name-index",
        KeyConditionExpression: "crypto_name=:crypto",
        FilterExpression : 'crypto_sentiment=:sentiment',
        ExpressionAttributeValues: {
            ":crypto" : {S:crypto},
            ":sentiment":{S:sentiment}
        }
    };

//Gets a single item

    try{
        let result = await documentClient.query(params).promise();
        return result.Count
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}