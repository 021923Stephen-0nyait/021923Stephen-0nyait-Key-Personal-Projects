const AWS = require("aws-sdk");
//Configuring API gateway
const api = new AWS.ApiGatewayManagementApi({
    endpoint:"17dus9o0fb.execute-api.us-east-1.amazonaws.com/production"
})
//Handling request
exports.handler = async (event) => {
    let newConnectionId= event.requestContext["connectionId"]
    await storeIds(newConnectionId)
    // TODO implement
    const response = {
        statusCode: 200,
    };
    return response;
};

//Function to store websocket connection ids to dynamoDb
async function storeIds(idNumber) {

    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    //Table name and data for table
    let params = {
        TableName: "ConnectionIds",
        Item: {
            "websocketId": {S:idNumber},

        }
    }

    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.putItem(params).promise();
        console.log("Data uploaded successfully: " + JSON.stringify(result));
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

