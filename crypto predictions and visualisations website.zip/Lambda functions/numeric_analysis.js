//Import AWS
let AWS = require("aws-sdk");
let test_data=require("test_data.json")
let train_data=require("train_data.json")

//formating Json data in files
let format_test_data=JSON.stringify(test_data)
let format_train_data=JSON.stringify(train_data)

let final_test_data=JSON.parse(format_test_data)
let final_train_data=JSON.parse(format_train_data)
//Configuring upi gateway
const api = new AWS.ApiGatewayManagementApi({
    endpoint:"17dus9o0fb.execute-api.us-east-1.amazonaws.com/production"
})

//Data that we are going to send to endpoint
let endpointData = {
    "instances":
        [
            {
                "start":final_test_data.start,
                "target":final_test_data.target
            }
        ],
    "configuration":
        {
            "num_samples": 50,
            "output_types":["mean","quantiles","samples"],
            "quantiles":["0.1","0.9"]
        }
};

//Name of endpoint
const endpointName = "cst3130-synthetic-predictions";

//Parameters for calling endpoint
let params = {
    EndpointName: endpointName,
    Body: JSON.stringify(endpointData),
    ContentType: "application/json",
    Accept: "application/json"
};

//AWS class that will query endpoint
let awsRuntime = new AWS.SageMakerRuntime({});

//Handler for Lambda function
exports.handler = event => {
    //Call endpoint and handle response
    let ConnIds= event.requestContext["connectionId"]
    awsRuntime.invokeEndpoint(params, (err, data)=>{
        if (err) {//An error occurred
            console.log(err, err.stack);

            //Return error response
            const response = {
                statusCode: 500,
                body: JSON.stringify('ERROR: ' + JSON.stringify(err)),
            };
            return response;
        }
        else{//Successful response
            //Convert response data to JSON
            let responseData = JSON.parse(Buffer.from(data.Body).toString('utf8'));
            
            let synthetic_handling = JSON.stringify({TYPE:"synthetic",TRAINING:final_train_data,TESTING:final_test_data,PREDICTION:responseData})
            //TODO: STORE DATA IN PREDICTION TABLE
            sendData(synthetic_handling,ConnIds)
            //Return successful response
            const response = {
                statusCode: 200,
                body: JSON.stringify('Predictions stored.'),
            };
            return response;
        }
    });
};


//Function to send data data from numeric analysis to user
async function sendData(response,connID) {
    let data = {message:response}
    let params={
        ConnectionId:connID,
        Data: Buffer.from(response)
    }
    
    
    return api.postToConnection(params).promise()
}


