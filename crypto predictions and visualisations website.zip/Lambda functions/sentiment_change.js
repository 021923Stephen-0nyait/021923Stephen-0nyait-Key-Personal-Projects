const AWS = require("aws-sdk");
//Configuring api gateway
const api = new AWS.ApiGatewayManagementApi({
    endpoint:"17dus9o0fb.execute-api.us-east-1.amazonaws.com/production"
})

exports.handler = async (event) => {
    //Getting the sentiments and adding it to a json string object
    let neutral_sentiment = await get_sentiment('NEUTRAL')
    let negative_sentiment = await get_sentiment('NEGATIVE')
    let mixed_sentiment = await get_sentiment('MIXED')
    let positive_sentiment = await get_sentiment('POSITIVE')
    let sentiment= JSON.stringify({TYPE:'Pie',STAGE:'update',POSITIVE:positive_sentiment,NEGATIVE:negative_sentiment,MIXED:mixed_sentiment,NEUTRAL:neutral_sentiment})
    let ConnIds=(await broadcastData())
    //Loop to broadcast the changes to all the connected users
   for(let i=0;i<ConnIds.length;i++)
    {
        await sendData(sentiment,ConnIds[i].websocketId.S)
    }
    // TODO implement
    const response = {
        statusCode: 200,
        
    };
    return response;
};


//Function to send data to the connected users
async function sendData(response,connID) {
    let data = {message:response}
    let params={
        ConnectionId:connID,
        Data: Buffer.from(response)
    }
    
    return api.postToConnection(params).promise()
}

//Method to get all the connectionids for the users who are using the website
async function broadcastData() {

    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    //Table name and data for table
    let params = {
        TableName: "ConnectionIds"
    }

    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.scan(params).promise();
        return result.Items
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

//Index query to get the number of different types of sentiment
async function get_sentiment(sentiment) {

    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    //Table name and data for table
    let params = {
        TableName: "crypto_sentiment",
        IndexName: "crypto_sentiment-index",
        KeyConditionExpression: "crypto_sentiment = :sentiment",
        ExpressionAttributeValues: {
            ":sentiment" : {S:sentiment}
        }
    };

//Gets a single item

    try{
        let result = await documentClient.query(params).promise();
        return result.Count
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}
