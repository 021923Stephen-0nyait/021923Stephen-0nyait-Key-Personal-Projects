const AWS = require("aws-sdk");

const api = new AWS.ApiGatewayManagementApi({
    endpoint:"17dus9o0fb.execute-api.us-east-1.amazonaws.com/production"
})


exports.handler = async (event) => {
    let eventBody =JSON.parse(event.body)
    let currency= eventBody.crypto_currency
    let crypto_data_limit=eventBody.data_limit
    let crypto_data_minimum=eventBody.data_minimum

    //Getting historical crpto data and formatting it
    let prices = await get_currency_prices(currency,crypto_data_limit,crypto_data_minimum)
    let historical_data= JSON.stringify({TYPE:'CandleStick',CURRENCY:currency,priceData:prices})
    let ConnIds= event.requestContext["connectionId"]

    //Sending historical data back to users
    await sendData(historical_data,ConnIds)
    // TODO implement
    const response = {
        statusCode: 200,
    };
    return response;
};


//Function to send historical data to user
async function sendData(response,connID) {
    let data = {message:response}
    let params={
        ConnectionId:connID,
        Data: Buffer.from(response)
    }
    
    
    return api.postToConnection(params).promise()
}

//Getting historical prices about a given currency
async function get_currency_prices(currency,data_limit,data_minimum) {

    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    //Table name and data for table
    let params = {
        TableName: "CryptoData",
        IndexName: "Currency-Price_time_stamp-index",
        KeyConditionExpression: "Currency = :crypto",
        FilterExpression : 'Price_index < :pmax and Price_index > :pmin',
        ExpressionAttributeValues: {
            ":crypto" : {S:currency},
            ":pmax": {"N":data_limit},
            ":pmin": {"N":data_minimum}
        }
    };

//Gets a single item

    try{
        let result = await documentClient.query(params).promise();
        return result.Items
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}


