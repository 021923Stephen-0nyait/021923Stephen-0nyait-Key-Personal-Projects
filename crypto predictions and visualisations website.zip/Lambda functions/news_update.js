const AWS = require("aws-sdk");
//Configure API gateway
const api = new AWS.ApiGatewayManagementApi({
    endpoint:"17dus9o0fb.execute-api.us-east-1.amazonaws.com/production"
})

exports.handler = async (event) => {
    let typeOfEvent = event.Records[0].eventName
    //If statment is triggered when data is inserted into the database. The data inserted is picked and sentiment analysis is done on it.
    if (typeOfEvent=="INSERT") {
        let news_data=event.Records[0].dynamodb["NewImage"]["content"]["S"]
        let crypto_currency=event.Records[0].dynamodb["NewImage"]["currency_name"]["S"]
        let news_title =event.Records[0].dynamodb["NewImage"]["sentiment_title"]["S"]
        let sentiment_analysis=await handle_sentiment(news_data)
        let sentiment_id = "id" + Math.random().toString(16).slice(2)
        await store_sentiment(crypto_currency,sentiment_analysis,sentiment_id,news_title)
    }
    if (typeOfEvent!="INSERT") {
        console.log("Not an inset")
    }

    // TODO implement
    const response = {
        statusCode: 200,
    };
    return response;
};

//the function store_sentiment is used to store the sentiment which has been done into a database
async function store_sentiment(name,sentiment_found,identification_number,sentiment_title) {
    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    //Table name and data for table
    let params = {
        TableName: "crypto_sentiment",//change this
        Item: {
            "crypto_name": {S:name},
            "crypto_id": {S:identification_number},
            "crypto_sentiment": {S:sentiment_found},
            "sentiment_title":{S:sentiment_title}
        }
    }
    
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.putItem(params).promise();
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

//The function below gets the sentiment of the data the has just been inserted
async function handle_sentiment(word) {
    //Create new DocumentClient
    let comprehend = new AWS.Comprehend({
        apiVersion:"2017-13-27"
    });

    //Parameters for call to AWS Comprehend
    let params = {
        LanguageCode: "en",//Possible values include: "en", "es", "fr", "de", "it", "pt"
        Text: word
    };

    //Store data in DynamoDB and handle errors
    try {
        let result = await comprehend.detectSentiment(params).promise();
        console.log("Data uploaded successfully: " + JSON.stringify(result));
        let final_result= result.Sentiment
        return final_result

    } catch (err) {
        console.error("ERROR uploading data: " + JSON.stringify(err));
    }
}


