const AWS = require("aws-sdk");


exports.handler = async (event) => {
    //Getting id of disconnected user
    let disConnectId = event.requestContext["connectionId"]
    //Removing id of user who just disconnected
    await removeIds(disConnectId)
    // TODO implement
    const response = {
        statusCode: 200,
        //body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};

//the function below stores the users data
async function removeIds(idNumber) {

    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    //Table name and data for table
    let params = {
        TableName: "ConnectionIds",
        Key: {
            "websocketId": {S:idNumber},
        }
    }

    //Remove data in DynamoDB and handle errors
    try {
        let result = await documentClient.deleteItem(params).promise();
        console.log("Data uploaded successfully: " + JSON.stringify(result));
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}