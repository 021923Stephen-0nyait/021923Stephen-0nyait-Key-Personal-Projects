namespace PutCryptoData{

    

    const fs = require("fs");
    const { parse } = require("csv-parse");
    const AWS = require("aws-sdk");

    //Aws configurations being set
    AWS.config.update({
        region: "us-east-1",
        endpoint: "https://dynamodb.us-east-1.amazonaws.com"
    });

    //the function putData is used to store the sentiment to dynamoDb
    async function putData(name:string,high:number,low:number,open:number,close:number,volume: number,time: number,long_date: string,price_index:number) {
        //Create new DocumentClient
        let documentClient = new AWS.DynamoDB.DocumentClient();

        //Table name and data for table
        let params = {
            TableName: "CryptoData",
            Item: {
                "Data_type":"Crypto",
                "Currency": name,
                "Price_time_stamp": time,
                "High": high,
                "Low":low,
                "Open":open,
                "Close":close,
                "Volume ":volume,
                "Full_price_date":long_date,
                "Price_index":price_index
            }
        }

        //Store data in DynamoDB and handle errors
        try {
            let result = await documentClient.put(params).promise();
            console.log("Data uploaded successfully: " + JSON.stringify(result));
        } catch (err) {
            console.error("ERROR uploading data: " + JSON.stringify(err));
        }
    }

    //Class which takes the file location for each csv file containing the crypto price data and store it in the database
    class Store_prices{
            file_name:string
            constructor(name_of_file:string)
            {
                this.file_name=name_of_file
            }

            //the method manage_data() gets the file path and uses it to get data from the file
            manage_data(){
                let price_data: string[] = []
                fs.createReadStream(this.file_name)
                .pipe(parse({ delimiter: ",", from_line: 2 }))
                .on("data", function (row:string) {
                    console.log(row);
                    price_data.push(row)
                    
                })
                .on("end", function () {
                    console.log("finished");
                    let start: number=price_data.length-501
                    let price_index= 0
                    //Looping through all the prices provided in the csv file and storing them in the database
                    for(let i=start;i<price_data.length;i++)
                    {
                        console.log(i)
                        console.log(price_data[i])
                        let date_info:string[] = price_data[i][3].split(" ")
                        let unix_time: number=Math.floor(new Date(date_info[0]).getTime() / 1000)
                        console.log(price_data.length)
                        let currency_name:string = price_data[i][1]

                        //Below is all the price data that will be needed
                        let current_high:number = Number(price_data[i][4])
                        let current_low:number = Number(price_data[i][5])
                        let current_open:number = Number(price_data[i][6])
                        let current_close:number = Number(price_data[i][7])
                        let current_volume: number= Number(price_data[i][8])
                        
                        
                        console.log(`currency ${currency_name},price: ${current_close},volume: ${current_volume},time: ${unix_time}`)
                        putData(currency_name,current_high,current_low,current_open,current_close,current_volume,unix_time,date_info[0],price_index)
                        price_index++

                    }
                })
                .on("error", function (error:any) {
                    console.log(error.message);
                });
            }
    }

//Creating an instance for each file path
let bitcoin_data= new Store_prices("./crypto_information/coin_Bitcoin.csv")
let cardona_data= new Store_prices("./crypto_information/coin_Cardano.csv")
let dodgecoin_data= new Store_prices("./crypto_information/coin_Dogecoin.csv")
let etherium_data= new Store_prices("./crypto_information/coin_Ethereum.csv")
let litecoin_data= new Store_prices("./crypto_information/coin_Litecoin.csv")
//calling to a method to store data from the csv file to the database
bitcoin_data.manage_data()
cardona_data.manage_data()
dodgecoin_data.manage_data()
etherium_data.manage_data()
litecoin_data.manage_data()

}