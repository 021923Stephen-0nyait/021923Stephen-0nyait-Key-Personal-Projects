namespace PutSentimentData{

let XMLHttpRequest = require('xhr2');
const AWS = require("aws-sdk");
//Tell AWS about region
AWS.config.update({
    region: "us-east-1",
    endpoint: "https://dynamodb.us-east-1.amazonaws.com"
});

async function putData(time:number,title:string,name:string,description:string) {
    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB.DocumentClient();

    console.log("n: "+name)
    //Table name and data for table
    let params = {
        TableName: "Sentiment_crypto_data",
        Item: {
            "currency_name":name,
            "sentiment_title": title,
            "sentiment_time_stamp": time,
            "content": description
        }
    }

    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.put(params).promise();
        console.log("Data uploaded successfully: " + JSON.stringify(result));
    } catch (err) {
        console.error("ERROR uploading data: " + JSON.stringify(err));
    }
}

class Store_sentiment{

    crypto_name:string
    constructor(crypto_name:string)
    {
        this.crypto_name=crypto_name
    }
    manage_data()
    {
        //Setting up news API query
        let name:string=this.crypto_name
        console.log("nam: "+this.crypto_name)
        let NEWS_API_KEY:string= "d257b9495e1140b8a47912db221af36b"
        let date= new Date()
        let current_date:string = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`
        let request:string=`https://newsapi.org/v2/everything?q=${name}&from=${current_date}&apiKey=${NEWS_API_KEY}`
        let xhttp = new XMLHttpRequest();
    
    
        //Set up function that is called when reply received from server
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                console.log("Hit")
                let server_response = xhttp.responseText
                let data_collected= JSON.parse(server_response)
                let news_data=data_collected.articles
                let checker:number =1
                for(let i=0;i<news_data.length;i++)
                {
                    let news_description:string = news_data[i].content
                    let news_title:string = news_data[i].title
                    let time_details:string=news_data[i].publishedAt.split("T")
                    let news_time:number = Math.floor(new Date(time_details[0]).getTime() / 1000)
                    
                    putData(news_time,news_title,name,news_description)
                    checker++
                    
                }
    
            }
        };
        xhttp.onerror=function(){
            console.log('Error occured') //Shows error if error occured
        }
        //Send request server
        xhttp.open("GET", request, true);
        xhttp.send();
    }
}
let bitcoin_data= new Store_sentiment("Bitcoin")
let cardona_data= new Store_sentiment("Cardano")
let dodgecoin_data= new Store_sentiment("Dogecoin")
let etherium_data= new Store_sentiment("Ethereum")
let litecoin_data= new Store_sentiment("Litecoin")
bitcoin_data.manage_data()
cardona_data.manage_data()
dodgecoin_data.manage_data()
etherium_data.manage_data()
litecoin_data.manage_data()

}