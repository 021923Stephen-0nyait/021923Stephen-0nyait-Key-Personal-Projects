let chart_tracker=0

let synthetic_xAxis=[]
let synthetic_xAxis_two=[]

let full_date=[]
let price_close=[]
let price_high=[]
let price_low=[]
let price_open=[]


let bitcoin_full_date=[]
let bitcoin_price_close=[]
let bitcoin_price_high=[]
let bitcoin_price_low=[]
let bitcoin_price_open=[]

let ethereum_full_date=[]
let ethereum_price_close=[]
let ethereum_price_high=[]
let ethereum_price_low=[]
let ethereum_price_open=[]

let litecoin_full_date=[]
let litecoin_price_close=[]
let litecoin_price_high=[]
let litecoin_price_low=[]
let litecoin_price_open=[]

let dodgecoin_full_date=[]
let dodgecoin_price_close=[]
let dodgecoin_price_high=[]
let dodgecoin_price_low=[]
let dodgecoin_price_open=[]

let cardona_full_date=[]
let cardona_price_close=[]
let cardona_price_high=[]
let cardona_price_low=[]
let cardona_price_open=[]

let crypto_chart= "crypto0"
let crypto_chart_number=0

let pie_chart= "pie0"
let pie_chart_number=0

let bitcoin_part=0
let ethereum_part=0
let litecoin_part=0
let doge_part=0
let cardano_part=0



let sock = new WebSocket("wss://17dus9o0fb.execute-api.us-east-1.amazonaws.com/production")

sock.addEventListener('open', e => {
    console.log("Connected to server")
    console.log(e)    
    getSentiment("all")
    getSentiment("Bitcoin")
    getSentiment("Ethereum")
    getSentiment("Litecoin")
    getSentiment("Dogecoin")
    getSentiment("Cardano")
    getHistoricalData("Bitcoin","250","0")
    getHistoricalData("Bitcoin","500","249")
    getHistoricalData("Ethereum","250","0")
    getHistoricalData("Ethereum","500","249")
    getHistoricalData("Litecoin","250","0")
    getHistoricalData("Litecoin","500","249")
    getHistoricalData("Dogecoin","250","0")
    getHistoricalData("Dogecoin","500","249")
    getHistoricalData("Cardano","250","0")
    getHistoricalData("Cardano","500","249")
})

sock.addEventListener('message', e => {
    console.log("Message from server")
    let dataParsed=JSON.parse(e.data)
    console.log(e.data)
    if(dataParsed.TYPE=="Pie")
    {
        
        drawPieChart(dataParsed.POSITIVE,dataParsed.NEGATIVE,dataParsed.MIXED,dataParsed.NEUTRAL,dataParsed.STAGE,dataParsed.CURRENCY)
    }

    if(dataParsed.TYPE=="synthetic")
    {
        setXaxis(dataParsed.TRAINING.target,dataParsed.TESTING.target)
        drawlinechart(dataParsed.TRAINING.target,dataParsed.TESTING.target,dataParsed.PREDICTION.predictions[0])
        syntheticForecastchart(dataParsed.TRAINING.target,dataParsed.TESTING.target,dataParsed.PREDICTION.predictions[0])
    }
    if(dataParsed.TYPE=="CandleStick")
    {
        console.log("Candle stick data")
        chart_tracker++
        let prices=dataParsed.priceData
        if(dataParsed.CURRENCY=="Bitcoin")
        {
            bitcoin_part++
            for(let i=0;i<prices.length;i++)
            {
                bitcoin_full_date.push(prices[i]["Full_price_date"]["S"])
                bitcoin_price_close.push(prices[i]["Close"]["N"])
                bitcoin_price_high.push(prices[i]["High"]["N"])
                bitcoin_price_low.push(prices[i]["Low"]["N"])
                bitcoin_price_open.push(prices[i]["Open"]["N"])
            }
            if(bitcoin_part==2)
            {
                drawCandleStickChart(bitcoin_full_date,bitcoin_price_close,bitcoin_price_high,bitcoin_price_low,bitcoin_price_open,dataParsed.CURRENCY)
            }
        }

        if(dataParsed.CURRENCY=="Ethereum")
        {
            ethereum_part++
            for(let i=0;i<prices.length;i++)
            {
                ethereum_full_date.push(prices[i]["Full_price_date"]["S"])
                ethereum_price_close.push(prices[i]["Close"]["N"])
                ethereum_price_high.push(prices[i]["High"]["N"])
                ethereum_price_low.push(prices[i]["Low"]["N"])
                ethereum_price_open.push(prices[i]["Open"]["N"])
            }
            if(ethereum_part==2)
            {
                drawCandleStickChart(ethereum_full_date,ethereum_price_close,ethereum_price_high,ethereum_price_low,ethereum_price_open,dataParsed.CURRENCY)
            }
        }

        if(dataParsed.CURRENCY=="Litecoin")
        {
            litecoin_part++
            for(let i=0;i<prices.length;i++)
            {
                litecoin_full_date.push(prices[i]["Full_price_date"]["S"])
                litecoin_price_close.push(prices[i]["Close"]["N"])
                litecoin_price_high.push(prices[i]["High"]["N"])
                litecoin_price_low.push(prices[i]["Low"]["N"])
                litecoin_price_open.push(prices[i]["Open"]["N"])
            }
            if(litecoin_part==2)
            {
                drawCandleStickChart(litecoin_full_date,litecoin_price_close,litecoin_price_high,litecoin_price_low,litecoin_price_open,dataParsed.CURRENCY)
            }
        
        }

        if(dataParsed.CURRENCY=="Dogecoin")
        {
            doge_part++
            for(let i=0;i<prices.length;i++)
            {
                dodgecoin_full_date.push(prices[i]["Full_price_date"]["S"])
                dodgecoin_price_close.push(prices[i]["Close"]["N"])
                dodgecoin_price_high.push(prices[i]["High"]["N"])
                dodgecoin_price_low.push(prices[i]["Low"]["N"])
                dodgecoin_price_open.push(prices[i]["Open"]["N"])
            }
            if(doge_part==2)
            {
                console.log("Dlen: "+dodgecoin_price_close.length)
                drawCandleStickChart(dodgecoin_full_date,dodgecoin_price_close,dodgecoin_price_high,dodgecoin_price_low,dodgecoin_price_open,dataParsed.CURRENCY)
            }
        }

        if(dataParsed.CURRENCY=="Cardano")
        {
            cardano_part++
            for(let i=0;i<prices.length;i++)
            {
                cardona_full_date.push(prices[i]["Full_price_date"]["S"])
                cardona_price_close.push(prices[i]["Close"]["N"])
                cardona_price_high.push(prices[i]["High"]["N"])
                cardona_price_low.push(prices[i]["Low"]["N"])
                cardona_price_open.push(prices[i]["Open"]["N"])
            }
            if(cardano_part==2)
            {
                drawCandleStickChart(cardona_full_date,cardona_price_close,cardona_price_high,cardona_price_low,cardona_price_open,dataParsed.CURRENCY)
            }
        }
        
        
    }

    //historical_data

})

sock.addEventListener('error', e => {
    console.error("Error: ",e)
})




function getSentiment(currency)
{


    let msgObject = {
      action: "initialConnection",//Used for routing in API Gateway
      crypto_currency: currency
    };
    //initialConnection

    //Send message
    sock.send(JSON.stringify(msgObject));
}

//syntheticDataHandler
function getHistoricalData(currency,data_limit,data_minimum)
{


    let msgObject = {
      action: "getHistoricalData",//Used for routing in API Gateway
      crypto_currency: currency,
      data_limit:data_limit,
      data_minimum:data_minimum
    };
    //initialConnection

    //Send message
    sock.send(JSON.stringify(msgObject));
}

function drawPieChart(POSITIVE,NEGATIVE,MIXED,NEUTRAL,STAGE,CURRENCY)
{
    if(STAGE=='initial')
    {
        pie_chart=CURRENCY
    }
    
    if(STAGE=='update')
    {
        pie_chart="all"
    }
   
    console.log("CURRENT PIE: "+pie_chart)
    let chart_background='rgb(16, 167, 16)'
    let chart_height=700
    let chart_width=700
    if(pie_chart!="all")
    {
        chart_background='rgb(0, 247, 0)'
        chart_height=300
        chart_width=300
    }
    var data = [{
    values: [POSITIVE,NEGATIVE,MIXED,NEUTRAL],
    labels: ['POSITIVE', 'NEGATIVE', 'MIXED','NEUTRAL'],
    type: 'pie',  
    marker: {
        colors:  ['rgb(0, 77, 0)', 'rgb(204, 0, 0)','rgb(204, 0, 153)', 'rgb(255, 204, 0)']
    }

    }];

    var layout = {
    height: chart_height,
    width: chart_width,
    paper_bgcolor:chart_background
    };

    Plotly.newPlot(pie_chart, data, layout);
}

function drawCandleStickChart(full_date,price_close,price_high,price_low,price_open,name)
{
    crypto_chart=name+"_candlestick"
    var trace1 = {

        x: full_date, 
        
        close: price_close, 
        
        decreasing: {line: {color: 'redF'}}, 
        
        high: price_high, 
        
        increasing: {line: {color: 'green'}}, 
        
        line: {color: 'rgba(31,119,180,1)'}, 
        
        low: price_low, 
        
        open: price_open, 
        
        type: 'candlestick', 
        xaxis: 'x', 
        yaxis: 'y'
    };
    
    var data = [trace1];
    
    var layout = {
        dragmode: 'zoom', 
        margin: {
        r: 10, 
        t: 25, 
        b: 40, 
        l: 60
        }, 
        showlegend: false, 
        xaxis: {
        autorange: true, 
        rangeslider: {range: [full_date[0],full_date[0]]}, 
        title: 'Date', 
        type: 'date'
        }, 
        yaxis: {
        autorange: true, 
        type: 'linear'
        },
        
        annotations: [
        {
            x: full_date[0],
            y: 0.9,
            xref: 'x',
            yref: 'paper',
            text: 'largest movement',
            font: {color: 'magenta'},
            showarrow: true,
            xanchor: 'right',
            ax: -20,
            ay: 0
        }
        ],
        
        shapes: [
            {
                type: 'rect',
                xref: 'x',
                yref: 'paper',
                x0: full_date[0],
                y0: 0,
                x1: full_date[1],
                y1: 1,
                fillcolor: '#d3d3d3',
                opacity: 0.2,
                line: {
                    width: 0
                }
            }
        ]
    };
   
    
        //Draw graph

        Plotly.newPlot(crypto_chart, data, layout);
        
}
