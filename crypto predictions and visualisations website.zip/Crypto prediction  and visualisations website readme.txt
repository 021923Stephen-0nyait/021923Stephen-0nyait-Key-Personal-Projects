CRYPTO CURRENCY PREDICTIONS AND VISUALISATION WEBSITE
DESCRIPTION
The project aims to develop a serverless web application for visualizing historical data and making predictions on five cryptocurrencies: Bitcoin, Cardano, Litecoin, Ethereum, and Dogecoin.
The application utilizes serverless architecture, leveraging cloud technologies for scalability and reliability.

TECHNOLOGIES USED
The following technology was used in the development of this project:
- Serverless architecture using AWS services
- Amazon S3 for web application hosting
- AWS SageMaker for machine learning-based predictions
- AWS Comprehend for sentiment analysis
- AWS Lambda for data processing
- API Gateway with WebSockets for real-time updates

FEATURES
- Visualization of historical price data for the past three years
- Machine learning-based price predictions using AWS SageMaker
- Sentiment analysis of text data to gauge buyer and seller opinions
- Real-time updates using WebSockets to notify users of database changes

DATA SOURCES
- Numeric data: Historical price data obtained from CSV files sourced from Kaggle
- Text data: News articles obtained from newsApi.org

CONTRIBUTORS
Stephen Onyait