let total_pages=0
let products_per_page =21
let comparisons_per_page =10
let current_query=""
let current_comparison=""
let current_page=0
let total_comparisons=0

/*The function below generates the comparison page where. The user
will see all the prices for an iPhone based on it's model
*/
function make_comparison(image,description,model)
{
    //updating number of phones with the specified model
    get_total_comparisons(model)
    current_comparison=model
    console.log("search_query")
    let all_products=`
    <link rel="stylesheet" href="comparison.css">
    <div class="results_title">
    <h1 class="title" style="color: rgb(147, 54, 0);">PRICE COMPARISON</h1>
    </div>
    <div class="product_information">
        <div class="products">
            <img src="${image}" alt="" class="product_image">
        </div>
        <div class="product_description">
            <div class="description">
                <div class="description_title">
                    <h1>DESCRIPTION</h1>
                </div>
                <div class="description_information">
                    <p>
                        ${description}
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="results_title all_comparisons">
    <h1 class="title" style="color: rgb(147, 54, 0);font-size: 30pt;">COMPARISONS FOUND<h1></h1>
    <div id="comparisons"></div>
    <div style="text-align: center;" id="pagination"></div>
    `
    document.getElementById("page_body").innerHTML=all_products
    update_comparisons(1) //updating comparison page
    

}

/*This function updates the content on the comparison results page based on the page that the user is on and the iphone model that they selected
and the users query.*/
function update_comparisons(starting_index)
{
    //request 
    let request=`/comparison/${current_comparison}/${starting_index}`
    let xhttp = new XMLHttpRequest();
    let product_url =""

    //Set up function that is called when reply received from server
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let server_response = xhttp.responseText
            let iPhone_found= JSON.parse(server_response)
            if(iPhone_found.length<=0)
            {
                document.getElementById("page_body").innerHTML="<h1>Page unavailable</h1><a href='/'><button>Go back</button></a>"
                return
            }
            console.log(total_comparisons)
            let end=iPhone_found.length
            let content=""
            /*The for loop below generates the html that will display all the products that were found
            based on the user's search
            */
            for(let i=0;i<end;i++)
            {
                let condition =0
                /*The conditional statements below format the url in a way that they can be clicked on and take the user to 
                The website where it is sold
                */
                if(iPhone_found[i].store_name=="Amazon")
                {
                    product_url="https://www.amazon.com"+iPhone_found[i].url
                    condition=1
                }
                if(iPhone_found[i].store_name=="FlipKart")
                {
                    product_url="https://www.flipkart.com"+iPhone_found[i].url
                    condition=1
                }
                if(iPhone_found[i].store_name=="John Lewis")
                {
                    product_url="https://www.johnlewis.com"+iPhone_found[i].url
                    condition=1
                }
                if(condition==0){
                    product_url=iPhone_found[i].url
                }
               
                let product = 
                `
                <div class="comparisons_found">
                    <div>
                        <h1 style="background-color: rgb(159, 63, 7);">${iPhone_found[i].store_name}</h1>
                    </div>
                    <div class="inner_description">
                        <div>
                            <h1>NAME:</h1>
                        </div>
                        <div>
                            <h2 style="background-color: rgb(225, 129, 74);">${iPhone_found[i].description}</h2>
                        </div>
                    </div>
                    <div class="inner_description">
                        <div>
                            <h1 style="background-color: rgb(225, 129, 74);">PRICE:</h1>
                        </div>
                        <div>
                            <h2 style="padding-top: 10px;">${iPhone_found[i].price}</h2>
                        </div>
                        
                    </div>
                    <div style="border-top: solid;">
                        <a href="${product_url}"><button class="select_button">GO TO SHOP</button></a>
                    </div>
                </div>
                `            
                content+=product
            }
            //Adding comparisons to the page
            document.getElementById("comparisons").innerHTML=content
            comparison_pagination(starting_index)
            
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured')
    }
    //Send new user data to server
    xhttp.open("GET", request, true);
    xhttp.send();
}
/*This function updates the content on the search results page based on the page that the user selected
and the users query.*/
function update_page(starting_index)
{
    //query
    let request=`/search/${current_query}/${starting_index}`
    let xhttp = new XMLHttpRequest();


    //Set up function that is called when reply received from server
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let server_response = xhttp.responseText
            let iPhone_found= JSON.parse(server_response)
            //The if statement below tells the user to go back to the home page if no products were found
            if(iPhone_found.length<=0)
            {
                document.getElementById("page_body").innerHTML="<h1>Page unavailable</h1><a href='/'><button>Go back</button></a>"
                return
            }
            console.log(iPhone_found)
            let end=iPhone_found.length
            let content=`
            <div class="results_title">
            <link rel="stylesheet" href="resultsStyling.css">
            <h1 class="title" style="color: rgb(147, 54, 0);">FIND PRODUCTS<h1>
            </div>
            `
            /*The for loop below generates the html that will display all the products that were found
            based on the user's search
            */
            for(let i=0;i<end;i++)
            {
                let condition =0
                /*The conditional statements below format the url in a way that they can be clicked on and take the user to 
                The website where it is sold
                */
                if(iPhone_found[i].store_name=="Amazon")
                {
                    product_url="https://www.amazon.com"+iPhone_found[i].url
                    condition=1
                }
                if(iPhone_found[i].store_name=="FlipKart")
                {
                    product_url="https://www.flipkart.com"+iPhone_found[i].url
                    condition=1
                }
                if(iPhone_found[i].store_name=="John Lewis")
                {
                    product_url="https://www.johnlewis.com"+iPhone_found[i].url
                    condition=1
                }
                if(condition==0){
                    product_url=iPhone_found[i].url
                }
        
                let product = `
                <div class="products">
                    <img src="${iPhone_found[i].image}" alt="product image" class="product_image">
                    <div>
                        <p>
                            ${iPhone_found[i].description}
                        </p>
                    </div>
                    <div>
                        <button class="select_button" onclick="make_comparison('${iPhone_found[i].image}','${iPhone_found[i].description}','${iPhone_found[i].model_id}')">
                            SELECT
                        </button>
                    </div>
                </div>
                `
                content+=product
            }
            //Adding a div which will show where the pagination will be
            let pagination =`<div style="text-align: center;" id="pagination"></div>`
            //Adding all products to the page
            content+=pagination
            document.getElementById("page_body").innerHTML=content
            pagination_details(starting_index)
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send request server
    xhttp.open("GET", request, true);
    xhttp.send();
}

/*The function below is used to update the pagination in the search results page*/
function pagination_details(starting_index)
{
    let validation=0
    let page_buttons=""
    let case_1=starting_index+1
    let case_2=starting_index-1
    if(starting_index<0){
        return -1;
    }

    /*Shows the next two pages if the user's on the first page*/
    if(case_2<=0 && validation==0)
    {
        page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" style=" background-color:yellow; color:brown; border-color:brown" onclick="update_page(${starting_index})">${starting_index}</button></span>`
        //Adds a pagination button to the page if parameters are not passed
        if(starting_index+1<=total_pages)
        {
            page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_page(${starting_index+1})">${starting_index+1}</button></span>`
        }
        //Adds a pagination button to the page if parameters are not passed
        if(starting_index+2<=total_pages)
        {
            page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_page(${starting_index+2})">${starting_index+2}</button></span>`
        }
        
        validation=1
    }

    /*Shows the previous two pages if the user's on the last page*/
    if(case_1>total_pages && validation==0)
    {
        //Adds a pagination button to the page if parameters are not passed
        if(starting_index-2>0)
        {
            page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_page(${starting_index-2})">${starting_index-2}</button></span>`
        }
        //Adds a pagination button to the page if parameters are not passed
        if(starting_index-1>0)
        {
            page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_page(${starting_index-1})">${starting_index-1}</button></span>`
        }
        
        page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" style=" background-color:yellow; color:brown; border-color:brown" onclick="update_page(${starting_index})">${starting_index}</button></span>`
        validation=1
    }

    /*Shows the previous page and next page if the user is not at the beginning and not at the end*/
    if(validation==0)
    {
        //Adds a pagination button to the page if parameters are not passed
        if(starting_index-1>0)
        {
            page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_page(${starting_index-1})">${starting_index-1}</button></span>`
        }
        
        page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" style=" background-color:yellow; color:brown; border-color:brown" onclick="update_page(${starting_index})">${starting_index}</button></span>`
        //Adds a pagination button to the page if parameters are not passed
        if(starting_index+1<=total_pages)
        {
            page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_page(${starting_index+1})">${starting_index+1}</button></span>`
        }
        validation=1
    }
    document.getElementById("pagination").innerHTML =page_buttons    
}

/*The function below is used to update the pagination in the price comparison page*/
function comparison_pagination(starting_index)
{
    let validation=0
    let page_buttons=""
    let case_1=starting_index+1
    let case_2=starting_index-1
    if(starting_index<0){
        return -1;
    }
    
    /*Shows the next two pages if the user's on the first page*/
    if(case_2<=0 && validation==0)
    {
        page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" style=" background-color:yellow; color:brown; border-color:brown" onclick="update_comparisons(${starting_index})">${starting_index}</button></span>`
        //Adds a pagination button to the page if parameters are not passed
        if(starting_index+1<=total_comparisons)
        {
            page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_comparisons(${starting_index+1})">${starting_index+1}</button></span>`
            //Adds a pagination button to the page if parameters are not passed
            if(starting_index+1<=total_comparisons)
            {
                page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_comparisons(${starting_index+2})">${starting_index+2}</button></span>`
            }
        }
        validation=1
    }

    /*Shows the previous two pages if the user's on the last page*/
    if(case_1>total_comparisons && validation==0)
    {
        //Adds a pagination button to the page if parameters are not passed
        if(starting_index-2>0)
        {
            page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_comparisons(${starting_index-2})">${starting_index-2}</button></span>`
        }
        //Adds a pagination button to the page if parameters are not passed
        if(starting_index-1>0)
        {
            page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_comparisons(${starting_index-1})">${starting_index-1}</button></span>`
        }
        
        page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" style=" background-color:yellow; color:brown; border-color:brown" onclick="update_comparisons(${starting_index})">${starting_index}</button></span>`
        validation=1
    }

    /*Shows the previous page and next page if the user is not at the beginning and not at the end*/
    if(validation==0)
    {
        //Adds a pagination button to the page if parameters are not passed
        if(starting_index-1>0)
        {
            page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_comparisons(${starting_index-1})">${starting_index-1}</button></span>`
        }
        page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" style=" background-color:yellow; color:brown; border-color:brown" onclick="update_comparisons(${starting_index})">${starting_index}</button></span>`
        //Adds a pagination button to the page if parameters are not passed
        if(starting_index+1<=total_comparisons)
        {
            page_buttons+=`<span style="padding-left:15px;"><button class="pagination_button" onclick="update_comparisons(${starting_index+1})">${starting_index+1}</button></span>`
        }
        validation=1
    }
    document.getElementById("pagination").innerHTML =page_buttons    
}

/*
The function below handles the users query that has been submitted
*/
function get_query()
{
    //Picking the query from text input bar
    let query=document.getElementById("iphone_query").value
    //updating the current query 
    current_query=query
    //getting the number of products available
    get_products(current_query)
    
    
}

/*The function below sends a request to the server that will find out how many values are present in
The database based on the user's search query.
*/
function get_products(search_query)
{
    let server_request=`/products_available/${search_query}`
    let xhttp = new XMLHttpRequest();
    console.log("search_query")
    //Set up function that is called when reply received from server
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let server_response = xhttp.responseText
            let format_response= JSON.parse(server_response)
            let number_of_phones=format_response[0].products_available
            //The function called updates the number of pages that will be available
            number_of_pages(number_of_phones)
            //displaying all the products found
            update_page(1)
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //handling error response
    }
    //Send new request
    xhttp.open("GET", server_request, true);
    xhttp.send();
}
/*The function below sends a request to the server that will find out how many values are present in
The database based on the iphone model selected by the user.
*/
function get_total_comparisons(model_id)
{
    let server_request=`/comparisons_available/${model_id}`
    let xhttp = new XMLHttpRequest();
    console.log("search_query")
    //Set up function that is called when reply received from server
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let server_response = xhttp.responseText
            let format_response= JSON.parse(server_response)
            let comparisons_total=format_response[0].comparisons_available
            console.log("comp_tot:"+comparisons_total)
            //The function called below updates the total number of comparison pages.
            number_of_comparisons(comparisons_total)
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Hanling request error
    }
    //Send request to server
    xhttp.open("GET", server_request, true);
    xhttp.send();
}

/*
The function below gives the number of pages that will be present by dividing the number of products by the number of products per page.
The the number that is found by dividing these numbers is then rounded up
*/
function number_of_pages(all_products)
{
    let possible_pages=all_products/products_per_page
    let pages_amount=Math.ceil(possible_pages) //Rounding up number
    total_pages=pages_amount
}

/*
The function below gives the number of pages that will be present by dividing the number of products by the number of products per page.
The the number that is found by dividing these numbers is then rounded up
*/
function number_of_comparisons(all_comparisons)
{
    let possible_comparisons=all_comparisons/comparisons_per_page
    let comparison_amount=Math.ceil(possible_comparisons) //Rounding up number
    total_comparisons=comparison_amount
}
