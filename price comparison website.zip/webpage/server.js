const express = require('express')
const app = express()
const bodyParser=require('body-parser')
const mysql =require('mysql')
app.use(bodyParser.json())
app.use(express.static('./public'))
const products_per_page=21
const comparisons_per_page =10

//Seeting up sql
const connectionPool = mysql.createPool({
    connectionLimit: 50,
    host: "localhost",
    user: "root",
    password: "",
    database: "Price_comparison",
    debug: false
});

/*The get request bellow takes the user back to the index page when it has been called*/
app.get('/',(req,res)=>{
    
    res.send("index.html")
})

/*The get request below is used to handle the users search query. Based on the search query and current page
the request handler below returns a certain number of products directly from the database
based on the page number that the user is currently on.
*/
app.get('/search/:search_query/:page_number',(req,res)=>{
    const phone_details=req.params
    fetchProducts(phone_details.search_query,phone_details.page_number).then ( result => {
        let valuesFetched = JSON.stringify(result)
        res.send(valuesFetched)
    }).catch( err => {//Handle the error
        console.error(JSON.stringify(err));
    });
})

/*
The get request below is used to handle the users search query. Based on the model id and current page
the request handler below returns a certain number of products directly from the database
based on the page number that the user is currently on.
*/
app.get('/comparison/:model_type/:page_number',(req,res)=>{
    const comparison_details=req.params
    fetchComparisons(comparison_details.model_type,comparison_details.page_number).then ( result => {
        let valuesFetched = JSON.stringify(result)
        res.send(valuesFetched)
    
    }).catch( err => {//Handle the error
        console.error(JSON.stringify(err));
    });
})

/*
The request below is used to get the total number of products found in the database based on the users search query.
*/
app.get('/products_available/:search_query',(req,res)=>{
    const phone_details=req.params
    fetch_products_available(phone_details.search_query).then ( result => {
        let valuesFetched = JSON.stringify(result)
        res.send(valuesFetched)
    }).catch( err => {//Handle the error
        console.error(JSON.stringify(err));
    });
})

/*
The request below is used to get the total number of products found in the database based on the model of the iphone that the user would like.
*/
app.get('/comparisons_available/:model_id',(req,res)=>{
    const comparison_details=req.params
    fetch_comparisons_available(comparison_details.model_id).then ( result => {
        let valuesFetched = JSON.stringify(result)
        res.send(valuesFetched)
    }).catch( err => {//Handle the error
        console.error(JSON.stringify(err));
    });
})

/*This promise below is used to find the number of products that are found based on the users search query.
Since node is asynchronous the web service would be unable to use the data fetched without a promise.
*/
function fetch_products_available(query)
{
    let sql =`SELECT COUNT(url) AS 'products_available' FROM phone_details INNER JOIN store INNER JOIN store_details 
    WHERE (phone_details.url=store.phone_url AND store.store_id=store_details.id AND phone_details.description like'%${query}%')`
    return new Promise ( (resolve, reject) => { 
        connectionPool.query(sql, (err, result) => {
            if (err){//Check for errors
                reject("Error executing query: " + JSON.stringify(err));
            }
            else{//Resolve promise with results
                resolve(result);
            }
        });
    });
}
/*This promise below is used to find the number of products that are found based on the iphone model that the user is looking for.
Since node is asynchronous the web service would be unable to use the data fetched without a promise.
*/
function fetch_comparisons_available(query)
{
    let sql =`SELECT COUNT(url) AS 'comparisons_available' FROM phone_details INNER JOIN store INNER JOIN store_details
    WHERE (phone_details.url=store.phone_url AND store.store_id=store_details.id AND phone_details.model_id='${query}')`;
    return new Promise ( (resolve, reject) => { 
        connectionPool.query(sql, (err, result) => {
            if (err){//Check for errors
                reject("Error executing query: " + JSON.stringify(err));
            }
            else{//Resolve promise with results
                resolve(result);
            }
        });
    });
}

/*This promise below is used to find all the product details that are found based on the users search query.
Since node is asynchronous the web service would be unable to use the data fetched without a promise.
*/
function fetchProducts(query,page_number)
{
    let current_page=0
    let end=page_number*products_per_page
    current_page=end-products_per_page
    let sql =`SELECT url,model_id,image,description,price,store_name  FROM phone_details INNER JOIN store INNER JOIN store_details 
    WHERE (phone_details.url=store.phone_url AND store.store_id=store_details.id AND phone_details.description like'%${query}%') LIMIT ${products_per_page} OFFSET ${current_page}`;
    return new Promise ( (resolve, reject) => { 
        connectionPool.query(sql, (err, result) => {
            if (err){//Check for errors
                reject("Error executing query: " + JSON.stringify(err));
            }
            else{//Resolve promise with results
                resolve(result);
            }
        });
    });
}

/*This promise below is used to find all the product details that are found based on the model that the user would like.
Since node is asynchronous the web service would be unable to use the data fetched without a promise.
*/
function fetchComparisons(query,page_number)
{
    let current_page=0
    let end=page_number*comparisons_per_page
    current_page=end-comparisons_per_page
    let sql =`SELECT url,model_id,image,description,price,store_name  FROM phone_details INNER JOIN store INNER JOIN store_details
    WHERE (phone_details.url=store.phone_url AND store.store_id=store_details.id AND phone_details.model_id="${query}") LIMIT ${comparisons_per_page} OFFSET ${current_page}`;
    return new Promise ( (resolve, reject) => { 
        connectionPool.query(sql, (err, result) => {
            if (err){//Check for errors
                reject("Error executing query: " + JSON.stringify(err));
            }
            else{//Resolve promise with results
                resolve(result);
            }
        });
    });
}

/*This middle ware is used to handle situations when a query is not found*/
app.use('*',(req,res)=>{
    res.send(`<h1>This page is not Available Press button to go back</h1>
    <button onclick='goBack()'>Go Back</button>
    <script>
    function goBack(){
        window.location.href="/"
    }
    </script>`)
})

//starting the server
app.listen(5000,()=>{
    console.log('Listening to server 5000......')
})


module.exports = app;