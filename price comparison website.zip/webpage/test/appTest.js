const server = require('../server.js')
//const assert = require('chai').assert

let chai = require('chai');
let should = chai.should();
let assert = chai.assert;
let expect = chai.expect;

//Set up Chai for testing web service
let chaiHttp = require ('chai-http');
chai.use(chaiHttp);


/*This test is used to evaluate whethter or not the server is responding correctly*/
describe('Web Service', () => {

    /*Checks that phones are fetched from the database when they are available*/
    describe('Phone found', () => {
        it('if phone is available shows all phones', (done) => {
            chai.request(server)
                .get("/search/iphone/1")
                .end((err, response) => {
                    //Check the status code
                    response.should.have.status(200);

                    //Convert returned JSON to JavaScript object
                    let resObj = JSON.parse(response.text);

                    //Check that an array of customers is returned
                    resObj.should.be.a('array');

                    //Check that appropriate properties are returned
                    if(resObj.length > 1){
                        resObj[0].should.have.property('image');
                        resObj[0].should.have.property('description');
                        resObj[0].should.have.property('model_id');
                    }

                    done();
                });
        });
    });

    /*Checks that no phones are fetched when a phone is not available*/
    describe('Phone not found', () => {
        it('if phone is not available shows 0 phones', (done) => {
            chai.request(server)
                .get("/search/fjkdshafkj/1")
                .end((err, response) => {
                    //Check the status code
                    response.should.have.status(200);

                    //Convert returned JSON to JavaScript object
                    let resObj = JSON.parse(response.text);

                    //Check that an array of customers is returned
                    resObj.should.be.a('array');

                    //Check length
                    let size = resObj.length
                    assert.equal(size,0)

                    done();
                });
        });
    });

    //Checks that no comparisons are fetched when a model does not exist in the database
    describe('Comparison not found', () => {
        it('if comparisons are not available shows 0 comparisons', (done) => {
            chai.request(server)
                .get("/comparison/fjkdshafkj/1")
                .end((err, response) => {
                    //Check the status code
                    response.should.have.status(200);

                    //Convert returned JSON to JavaScript object
                    let resObj = JSON.parse(response.text);

                    //Check that an array of customers is returned
                    resObj.should.be.a('array');

                    //Check length
                    let size = resObj.length
                    assert.equal(size,0)

                    done();
                });
        });
    });

    //Checks that comparisons are fetched when the model exists in the database
    describe('Comparison  found', () => {
        it('if comparisons are available shows comparisons', (done) => {
            chai.request(server)
                .get("/comparison/11/1")
                .end((err, response) => {
                    //Check the status code
                    response.should.have.status(200);

                    //Convert returned JSON to JavaScript object
                    let resObj = JSON.parse(response.text);

                    //Check that an array of customers is returned
                    resObj.should.be.a('array');

                    //Check that appropriate properties are returned
                    if(resObj.length > 1){
                        resObj[0].should.have.property('store_name');
                        resObj[0].should.have.property('url');
                        resObj[0].should.have.property('description');
                        resObj[0].should.have.property('price');
                    }

                    done();
                });
        });
    });

    //Checks that a number above 0 is shown when the products are available
    describe('Products available', () => {
        it('if products are availble show number of products', (done) => {
            chai.request(server)
                .get("/products_available/iphone")
                .end((err, response) => {
                    //Check the status code
                    response.should.have.status(200);

                    //Convert returned JSON to JavaScript object
                    let resObj = response.text;
                    let format_response= JSON.parse(resObj)
                    let comparisons_total=format_response[0].products_available
                    let checker =0
                    if(comparisons_total>0)
                    {
                        checker=1
                    }
                    //Checks that products are found
                    assert.equal(1,checker)

                    done();
                });
        });
    });

    //Checks that a number 0 is shown when the products are not available
    describe('Products not available', () => {
        it('if product is not available show 0', (done) => {
            chai.request(server)
                .get("/products_available/fjkdshafkj")
                .end((err, response) => {
                    //Check the status code
                    response.should.have.status(200);

                    //Convert returned JSON to JavaScript object
                    let resObj = response.text;
                    let format_response= JSON.parse(resObj)
                    let comparisons_total=format_response[0].products_available
                    let checker =0
                    if(comparisons_total>0)
                    {
                        checker=1
                    }
                    //Checks that no products are found
                    assert.equal(0,checker)

                    done();
                });
        });
    });

    //Checks that a number above 0 is shown when a specidied phone model is available
    describe('Comparison  available', () => {
        it('if comparison is available show all comparisons', (done) => {
            chai.request(server)
                .get("/comparisons_available/11")
                .end((err, response) => {
                    //Check the status code
                    response.should.have.status(200);

                    //Convert returned JSON to JavaScript object
                    let resObj = response.text;
                    let format_response= JSON.parse(resObj)
                    let comparisons_total=format_response[0].comparisons_available
                    let checker =0
                    
                    if(comparisons_total>0)
                    {
                        checker=1
                    }
                    //Checks that products are found
                    assert.equal(1,checker)

                    done();
                });
        });
    });

    //Checks that a number 0 is shown when a specidied phone model is not available
    describe('Comparison not available', () => {
        it('if comparison is not available show 0', (done) => {
            chai.request(server)
                .get("/comparisons_available/fjkdshafkj")
                .end((err, response) => {
                    //Check the status code
                    response.should.have.status(200);

                    //Convert returned JSON to JavaScript object
                    let resObj = response.text;
                    let format_response= JSON.parse(resObj)
                    let comparisons_total=format_response[0].comparisons_available
                    let checker =0
                    if(comparisons_total>0)
                    {
                        checker=1
                    }
                    //Checks that no products are found
                    assert.equal(0,checker)

                    done();
                });
        });
    });

    //Checks that error message is shown after request handles is not found
    describe('Params not found', () => {
        it('if page is not found show error message', (done) => {
            chai.request(server)
                .get("/fjkdfkjd")
                .end((err, response) => {
                    //Check the status code
                    response.should.have.status(200);

                    //Convert returned JSON to JavaScript object
                    let resObj = response.text;
                    let error_message=`<h1>This page is not Available Press button to go back</h1><button onclick='goBack()'>Go Back</button>
                    <script>
                    function goBack(){
                        window.location.href="/"
                    }
                    </script>`
                    let array_one=error_message.split("\s")
                    let array_two=resObj.split("\s")
                    assert.equal(array_one.length,array_two.length)

                    done();
                });
        });
    });
    
});
