package CST3130;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */

    @Test
    public void dataStored()
    {
        StorePhoneDetails savePhoneDetails = new StorePhoneDetails();
        savePhoneDetails.addPhone("ProductUrl.com","model","Image","Iphone something");
        assertEquals(1,getPhone());
    }

    @Test
    public void dataNotNull()
    {
        DataCleaner cleaning = new DataCleaner();
        assertEquals(0,cleaning.noEmptys(null,null,null,null,null));
    }

    @Test
    public void dataNotEmptyString()
    {
        DataCleaner cleaning = new DataCleaner();
        assertEquals(0,cleaning.noEmptys("","","","",""));

    }

    @Test
    public void dataContainsIphone()
    {
        DataCleaner cleaning = new DataCleaner();
        assertEquals(0,cleaning.containsIphone("not here"));
    }

    @Test
    public void dataContainsStorage()
    {
        DataCleaner cleaning = new DataCleaner();
        assertEquals(0,cleaning.containsStorage("not here"));
    }

    @Test
    public void dataInbounds()
    {
        DataCleaner cleaning = new DataCleaner();
        assertEquals(0,cleaning.inbounds(4,5));
    }

    public int getPhone()
    {
        PhoneDetails iphoneInformation = new PhoneDetails();
        Configuration con= new Configuration().configure().addAnnotatedClass(PhoneDetails.class);
        SessionFactory sf = con.buildSessionFactory();
        Session session = sf.openSession();

        PhoneDetails phone=(PhoneDetails) session.get(PhoneDetails.class,"ProductUrl.com");
        boolean verifySave = session.contains(phone);
        if (verifySave ==true)
        {
            System.out.println("Verification reached: "+verifySave);
            removePhone();
            sf.close();
            return 1;
        }
        System.out.println("nope");
        sf.close();
        return 0;

    }
    public void removePhone()
    {
        PhoneDetails iphoneInformation = new PhoneDetails();
        Configuration con= new Configuration().configure().addAnnotatedClass(PhoneDetails.class);
        SessionFactory sf = con.buildSessionFactory();
        Session session = sf.openSession();
        Transaction transaction = session.beginTransaction();
        iphoneInformation.setUrl("ProductUrl.com");
        session.delete(iphoneInformation);
        transaction.commit();
        sf.close();
    }
}
