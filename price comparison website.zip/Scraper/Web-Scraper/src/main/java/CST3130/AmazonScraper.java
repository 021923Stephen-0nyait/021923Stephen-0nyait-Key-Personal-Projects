package CST3130;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.Serializable;

/**This AmazonScraper class is used to scrap data from the website amazon.com
 * It sleeps every 30 seconds to prevent problems with amazon*/
public class AmazonScraper extends Thread implements Serializable {

    String itemName;
    String storeName;
    StoreShopDetails saveShopDetails;
    StorePhoneDetails savePhoneDetails;
    DataCleaner cleanData;

    /**The no argument constructor below is used for spring .
     * The getters and setters as well are used to make a spring bean.*/
    AmazonScraper(){
        itemName = "no name";
        storeName="no name";
    }

    public void run()
    {
        try{
            //jSoup Exercises
            exercise1();
        }
        catch(Exception ex){
            System.out.println("Exercise Exception: " + ex.getMessage());
        }
    }

    public void scrapWebsite()
    {
        this.start();
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public StoreShopDetails getSaveShopDetails() {
        return saveShopDetails;
    }

    public void setSaveShopDetails(StoreShopDetails saveShopDetails) {
        this.saveShopDetails = saveShopDetails;
    }

    public StorePhoneDetails getSavePhoneDetails() {
        return savePhoneDetails;
    }

    public void setSavePhoneDetails(StorePhoneDetails savePhoneDetails) {
        this.savePhoneDetails = savePhoneDetails;
    }

    public DataCleaner getCleanData() {
        return cleanData;
    }

    public void setCleanData(DataCleaner cleanData) {
        this.cleanData = cleanData;
    }

    /**The exercise1 function is used to scrap the data from 14 pages about iPhones.
     * It sleeps every 30 seconds.
     * @throws Exception shows if error occurs while running thread*/
    private void exercise1() throws Exception {

        for(int j=1;j<14;j++)
        {
            String itemPage=itemName+"&page="+j;
            //slecting all the products content from the webpage
            Document doc = Jsoup.connect("https://www.amazon.com/s?k="+itemPage).post();
            //Use CSS selectors to extract element with ID 'products'
            Elements products = doc.select(".sg-row");
            Elements productName = products.select(".s-list-col-right>.sg-col-inner>.a-section>.a-section>.a-size-mini>.a-link-normal>.a-size-medium");
            Elements productURLs = products.select(".s-list-col-right>.sg-col-inner>.a-section>.a-section>.a-size-mini>.a-link-normal");
            Elements productImage = products.select(".s-list-col-left>.sg-col-inner>.s-product-image-container>.aok-relative>.rush-component>.a-link-normal>.a-section>.s-image");
            Elements productsCost = products.select(".sg-row>.sg-col>.sg-col-inner>.a-section>.a-row>.a-size-base>.a-price>.a-offscreen");

            /**This for loop extracts all the data from the web page about iPhones then stores it in the database.
             * The data is cleaned before it is stored.*/
            for(int i =0;i<productName.size();i++)
            {
                String nameCheck = productName.get(i).text();
                if(cleanData.containsIphone(nameCheck)==1 && cleanData.containsStorage(nameCheck)==1){
                    int phoneFound=0;
                    String newProduct =productURLs.get(i).attr("href");
                    String newProductImage =productImage.get(i).attr("src");
                    String newProductName = productName.get(i).text();
                    String newCost = productsCost.get(i).text();
                    String currentPhoneDetails[] = newProductName.split("\\s");
                    String modelNumber="";
                    for (int h=0;h< currentPhoneDetails.length;h++)
                    {
                        String phone = currentPhoneDetails[h].toLowerCase();
                        if (phone.equals("iphone")&& phoneFound==0)
                        {
                            if (cleanData.inbounds(currentPhoneDetails.length,h+1)==1) {
                                modelNumber = currentPhoneDetails[h + 1];
                                int lastValue = modelNumber.length() - 1;
                                int verifyCurrentPhone = modelNumber.indexOf(",");
                                if (lastValue == verifyCurrentPhone) {
                                    modelNumber = modelNumber.substring(0, lastValue);
                                }
                                phoneFound = 1;
                            }
                        }
                    }
                    if (cleanData.noEmptys(newProduct,modelNumber,newProductImage,newProductName,newCost)==1)
                    {
                        savePhoneDetails.addPhone(newProduct,modelNumber,newProductImage,newProductName);
                        saveShopDetails.addDetails(newCost,newProduct,1);
                    }

                }

            }
            try {
                sleep(30000);
            } catch (InterruptedException ex) {
                System.err.println(ex.getMessage());
            }
        }
        try {
            sleep(30000);
        } catch (InterruptedException ex) {
            System.err.println(ex.getMessage());
        }

    }

}
