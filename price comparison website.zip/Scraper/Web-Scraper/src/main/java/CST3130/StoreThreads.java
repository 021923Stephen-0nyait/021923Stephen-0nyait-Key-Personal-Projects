package CST3130;
/**
 * The StoreThreads class below is used to start all the threads that scrap all the different websites.
 * It allows all these threads to run at the same.*/
public class StoreThreads extends Thread{
    String itemName;
    AmazonScraper amazonStore;
    eBayScraper eBayStore;
    FlipcartScraper flipcartStore;
    NewEggScraper newEggStore;
    JohnLewisScraper johnLewisStore;

    /**The no argument constructor below is used for spring .
     * The getters and setters as well are used to make a spring bean.*/
    StoreThreads()
    {
        itemName="no name";
    }

    public eBayScraper geteBayStore() {
        return eBayStore;
    }

    public void seteBayStore(eBayScraper eBayStore) {
        this.eBayStore = eBayStore;
    }

    public AmazonScraper getAmazonStore() {
        return amazonStore;
    }

    public void setAmazonStore(AmazonScraper amazonStore) {
        this.amazonStore = amazonStore;
    }

    public FlipcartScraper getFlipcartStore() {
        return flipcartStore;
    }

    public void setFlipcartStore(FlipcartScraper flipcartStore) {
        this.flipcartStore = flipcartStore;
    }

    public NewEggScraper getNewEggStore() {
        return newEggStore;
    }

    public void setNewEggStore(NewEggScraper newEggStore) {
        this.newEggStore = newEggStore;
    }

    public JohnLewisScraper getJohnLewisStore() {
        return johnLewisStore;
    }

    public void setJohnLewisStore(JohnLewisScraper johnLewisStore) {
        this.johnLewisStore = johnLewisStore;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    /**
     * The run method starts all the web scraper threads.*/
    public void run()
    {
        amazonStore.setItemName(itemName);
        eBayStore.setItemName(itemName);
        flipcartStore.setItemName(itemName);
        newEggStore.setItemName(itemName);
        johnLewisStore.setItemName(itemName);
        amazonStore.scrapWebsite();
        eBayStore.scrapWebsite();
        flipcartStore.scrapWebsite();
        newEggStore.scrapWebsite();
        johnLewisStore.scrapWebsite();
    }
    /**
     * getProducts method is used to start this thread that will run all the other threads.*/
    public void getProducts()
    {
        this.start();
    }
}
