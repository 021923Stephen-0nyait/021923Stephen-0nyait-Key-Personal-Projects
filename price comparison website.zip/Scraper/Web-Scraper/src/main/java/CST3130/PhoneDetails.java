package CST3130;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**The PhoneDetails class is used with hibernate to map the details with the database
 * The getters and setters are used for hibernate mapping*/
@Entity
@Table(name = "phone_details")
public class PhoneDetails {
    @Id
    @Column(name = "url")
    String url;
    @Column(name = "model_id")
    String modelId;
    @Column(name = "image")
    String image;
    @Column(name = "description")
    String description;

    public String getModelId() {
        return modelId;
    }

    public void setModelId(String modelId) {
        this.modelId = modelId;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return "PhoneDetails{" +
                "url=" + url +
                ", modelId='" + modelId + '\'' +
                ", image='" + image + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
