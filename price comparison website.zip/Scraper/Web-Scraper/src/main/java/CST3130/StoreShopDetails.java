package CST3130;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.io.Serializable;

/**
 * The StoreShopDetails class is used to store the details of
 * The comparisons found into the store table in the database*/
public class StoreShopDetails implements Serializable {

    /**
     * The empty constructor class is used in this case for the spring bean*/
    public StoreShopDetails() {
    }
/**
 * the addDetails function is used to take the new data to be inserted and add it to the database.
 * It does this by using hibernate.
 * @param price price of iPhone
 * @param phoneUrl link to e-commerce store
 * @param storeId id to get store details*/
    public void addDetails(String price, String phoneUrl, int storeId)
    {
        Store storeInformation = new Store();
        Configuration con= new Configuration().configure().addAnnotatedClass(Store.class);
        SessionFactory sf = con.buildSessionFactory();
        Session session = sf.openSession();

        /**
         * In this part of the addDetails function after the class is configured a transaction is started.
         * Details are added to the store table in the database*/
        Transaction transaction = session.beginTransaction();
        storeInformation.setPrice(price);
        storeInformation.setPhoneUrl(phoneUrl);
        storeInformation.setStoreId(storeId);
        session.save(storeInformation);
        transaction.commit();
        sf.close();

    }
}
