package CST3130;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.io.Serializable;

/**
 * The StorePhoneDetails class is used to store the details of
 * The comparisons found into the phone_details table in the database*/
public class StorePhoneDetails implements Serializable {

    public StorePhoneDetails() {
    }
    /**
     * the addPhone function is used to take the new data to be inserted and add it to the database.
     * It does this by using hibernate.
     * @param phoneUrl link to e-commerce web page
     * @param model model of the iPhone
     * @param image link to image of the iPhone
     * @param description description scraped about the iPhone*/
    public void addPhone(String phoneUrl, String model, String image, String description)
    {

        PhoneDetails iphoneInformation = new PhoneDetails();
        Configuration con= new Configuration().configure().addAnnotatedClass(PhoneDetails.class);
        SessionFactory sf = con.buildSessionFactory();
        Session session = sf.openSession();

        /**
         * In this part of the addPhone function after the class is configured a transaction is started.
         * Details are added to the phone_details table in the database*/
        Transaction transaction = session.beginTransaction();
        iphoneInformation.setUrl(phoneUrl);
        iphoneInformation.setModelId(model);
        iphoneInformation.setImage(image);
        iphoneInformation.setDescription(description);
        session.save(iphoneInformation);
        transaction.commit();
        sf.close();

    }
}
