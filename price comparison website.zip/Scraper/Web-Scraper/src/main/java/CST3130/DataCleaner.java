package CST3130;

import java.io.Serializable;

/**
 * the class DataCleaner is used to clean the data before it is stored in the database.*/
public class DataCleaner implements Serializable {
    /**The no argument constructor below is used for the spring bean.*/
    public DataCleaner() {
    }

    /**
     * containsIphone is used to ensure that the product found is an iPhone.
     * it does this by seeing whether the product description contains the word iPhone.
     * @param details the product description
     * @return returns 1 if description contains iPhone*/
    public int containsIphone(String details)
    {
        String checker = details.toLowerCase();
        if (checker.contains("iphone"))
        {
            return 1;
        }
        return 0;
    }
    /**
     * containsStorage is used to ensure again that the product found is an iPhone.
     * It does this by checking whether the product description contains storage.
     * @param details product description
     * @return returns 1 if product contains storage*/
    public int containsStorage(String details)
    {
        String checker = details.toLowerCase();
        if (checker.contains("gb"))
        {
            return 1;
        }
        return 0;
    }
    /**
     * The noEmptys function is used to ensure that a product missing a field is not added to the database
     * @param url url to the online store where product is sold
     * @param  model the model of the iPhone
     * @param image the link to the products image
     * @param description the products description
     * @param price the cost of the iPhone
     * @return returns 1 if data has no blanks*/
    public int noEmptys(String url,String model,String image,String description,String price)
    {
        if (url!=null && model!=null && image!=null && description!=null && price!=null)
        {
            if (!url.equals("") && !model.equals("") && !image.equals("") && !description.equals("") && !price.equals(""))
            {
                return 1;
            }
        }
        return 0;

    }
    /**
     * The inbounds function is used to ensure that we don't exceed the length of the array that contains information about the iPhone
     * @param arrayLength the length of the array
     * @param index the current array index that we are at
     * @return 1 if index is in bounds*/
    public int inbounds(int arrayLength,int index)
    {
        if (arrayLength>index)
        {
            return 1;
        }
        return 0;
    }
}
