package CST3130;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.Serializable;

/**This NewEggScraper class is used to scrap data from the website newegg.com
 * It sleeps every 30 seconds to prevent problems with newegg.com*/
public class NewEggScraper extends Thread implements Serializable {
    String itemName;
    String storeName;
    StoreShopDetails saveShopDetails;
    StorePhoneDetails savePhoneDetails;
    DataCleaner cleanData;

    /**The no argument constructor below is used for spring .
     * The getters and setters as well are used to make a spring bean.*/
    NewEggScraper(){
        itemName = "no name";
        storeName="no name";
    }

    public void run()
    {
        try{
            //jSoup Exercises
            exercise1();
        }
        catch(Exception ex){
            System.out.println("Exercise Exception: " + ex.getMessage());
        }
    }

    public void scrapWebsite()
    {
        this.start();
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public StoreShopDetails getSaveShopDetails() {
        return saveShopDetails;
    }

    public void setSaveShopDetails(StoreShopDetails saveShopDetails) {
        this.saveShopDetails = saveShopDetails;
    }

    public StorePhoneDetails getSavePhoneDetails() {
        return savePhoneDetails;
    }

    public void setSavePhoneDetails(StorePhoneDetails savePhoneDetails) {
        this.savePhoneDetails = savePhoneDetails;
    }

    public DataCleaner getCleanData() {
        return cleanData;
    }

    public void setCleanData(DataCleaner cleanData) {
        this.cleanData = cleanData;
    }

    /**The exercise1 function is used to scrap the data from 11 pages about iPhones.
     * It sleeps every 30 seconds.
     * @throws Exception shows if error occurs while running thread*/
    private void exercise1() throws Exception {

        for(int j=1;j<11;j++) {
            String urlEntry = "https://www.newegg.com/p/pl?d=iphone&page=" + j;
            System.out.println(urlEntry);
            Document doc = Jsoup.connect(urlEntry).get();
            //Use CSS selectors to extract element with ID 'products'

            Elements products = doc.select(".item-cells-wrap>.item-cell>.item-container");
            Elements productName = products.select(".item-info>.item-title");
            Elements productImage = products.select(".item-img>img");
            Elements productsCost = products.select(".item-action>.price>.price-current");

            /**This for loop extracts all the data from the web page about iPhones then stores it in the database.
             * The data is cleaned before it is stored.*/
            for (int i = 0; i < products.size(); i++) {
                String nameCheck = productName.get(i).text();
                if (cleanData.containsIphone(nameCheck)==1 && cleanData.containsStorage(nameCheck)==1) {
                    int phoneFound=0;
                    String newProduct = productName.get(i).attr("href");
                    String newProductImage = productImage.get(i).attr("src");
                    String newProductName = productName.get(i).text();
                    String newCost = productsCost.get(i).text();
                    if(!newCost.equals("")) {
                        String filterCost[] = newCost.split("\\s");
                        String cost = filterCost[0];
                        String currentPhoneDetails[] = newProductName.split("\\s");
                        String modelNumber = "";
                        for (int h = 0; h < currentPhoneDetails.length; h++) {
                            String phone = currentPhoneDetails[h].toLowerCase();
                            if (phone.equals("iphone") && phoneFound == 0)
                            {
                                if (cleanData.inbounds(currentPhoneDetails.length,h+1)==1) {
                                    modelNumber = currentPhoneDetails[h + 1];
                                    int lastValue = modelNumber.length() - 1;
                                    int verifyCurrentPhone = modelNumber.indexOf(",");
                                    if (lastValue == verifyCurrentPhone) {
                                        modelNumber = modelNumber.substring(0, lastValue);
                                    }
                                    phoneFound = 1;
                                }
                            }
                        }

                        if (cleanData.noEmptys(newProduct,modelNumber,newProductImage,newProductName,newCost)==1) {
                            savePhoneDetails.addPhone(newProduct, modelNumber, newProductImage, newProductName);
                            saveShopDetails.addDetails(cost, newProduct, 5);
                        }
                    }
                }
            }

            try {
                sleep(30000);
            } catch (InterruptedException ex) {
                System.err.println(ex.getMessage());
            }
        }
    }

}


