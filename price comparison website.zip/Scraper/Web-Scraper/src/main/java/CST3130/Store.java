package CST3130;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**The Store class is used with hibernate to map the details with the database
 * The getters and setters are used for hibernate mapping*/

@Entity
@Table(name = "store")
public class Store {
    @Id
    @Column(name = "id")
    int id;
    @Column(name = "price")
    String price;
    @Column(name = "phone_url")
    String phoneUrl;
    @Column(name = "store_id")
    int storeId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPhoneUrl() {
        return phoneUrl;
    }

    public void setPhoneUrl(String phoneUrl) {
        this.phoneUrl = phoneUrl;
    }

    public int getStoreId() {
        return storeId;
    }

    public void setStoreId(int storeId) {
        this.storeId = storeId;
    }
}
