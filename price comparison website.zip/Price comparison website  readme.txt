PRICE COMPARISON WEBSITE READ ME
DESCRIPTION
This project is a price comparison website for iPhones. It includes a web scraper component that collects data from five different websites.
The scraped data is cleaned and stored in a database. The web application component allows users to search for iPhones, view a range of options,
and compare prices from different online stores. Users can then proceed to the online store to make a purchase. Tests are implemented to ensure proper functioning of key features.

TECHNOLOGIES USED
The price comparison website is built using the following technologies:
- Java: Backend development and web scraping.
- JavaScript: Frontend development and RESTful API.
- Node.js: Server-side runtime environment for JavaScript.
- MySQL: Relational database management system for storing scraped and user data.

List of Websites
The following websites are scraped for iPhone price comparison:
1. Flipkart: https://www.flipkart.com/
2. eBay: https://www.ebay.com/
3. John Lewis: https://www.johnlewis.com/
4. Newegg: https://www.newegg.com/
5. Amazon: https://www.amazon.com/

TESTS
JAVA TESTS
Java tests are conducted to ensure data cleaning and storage functions properly.

JAVASCRIPT TESTS
RESTful API tests are performed to verify successful handling of data requests and responses in JSON format.

INSTALLATION AND SETUP
1. Download the project from the drive.
2. Ensure Java Development Kit (JDK) is installed.
3. Install Node.js if not already installed.
4. Set up a MySQL server and configure it.
5. Set environment variables for database connection.
6. Run the web scraper executable jar file to collect and store data.
7. Install project dependencies using npm install.
8. Configure the project settings as required.
9. Start the application with node app.js.

CONTRIBUTORS
Stephen Onyait