RIDDLE GAME
DESCRIPTION
This project is a riddle game that challenges players to answer a set of riddles within a specified time limit. The game utilizes JavaScript, XAMPP, and browser storage
to provide an interactive and engaging user experience. Players can track their progress and play the game directly in a web browser.

TECHNOLOGIES USED
The Riddle Game is built using the following technologies:
- JavaScript: The primary programming language used for the game logic and interactivity.
- XAMPP: A web server solution that includes Apache, MySQL, PHP, and Perl. XAMPP is used to host and run the project locally.
- Browser Storage: The game utilizes browser storage, such as Local Storage or Session Storage, to store and retrieve player data, including progress and game settings.

FEATURES
- User Registration and Login: Players can create an account or log in to access the game and track their progress.
- Difficulty Levels: The game offers multiple difficulty levels, providing varying challenges for players.
- Time-limited Questions: Players must answer riddles within the specified time limit to progress in the game.
- Browser Storage: Player progress and settings are stored in the browser's storage, allowing for seamless gameplay across sessions.

GETTING STARTED
To set up the Riddle Game locally using XAMPP, follow these steps:
1. Install XAMPP by following the instructions specific to your operating system (Windows, macOS, or Linux).
2. Download the project from the drive.
3. Open the XAMPP control panel and start the Apache and MySQL services.
4. Copy the project files into the appropriate directory within the XAMPP web server. For example, if XAMPP is installed in C:\xampp, copy the project into C:\xampp\htdocs\riddle-game.
5. Open a web browser and access the game by entering the local server URL (e.g., http://localhost/riddle-game).
6. Create an account or log in to start playing the game.

CONTRIBUTORS
Stephen Onyait