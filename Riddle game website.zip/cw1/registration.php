<?php
    include 'reccuring.php';
    outputheader("Registration","game_registration_styling.css","REGISTRATION","index.php","LOG IN","regis","");
?>
                    <div class="registration_form">
                        <!-- This is where the user will register --> 
                        <div class="item1">
                            <b>USERNAME</b>
                        </div>
                        <div class="item5">
                            <input id="user"></input>
                        </div>
                        <div class="item2">
                            <b>EMAIL</b>
                        </div>
                        <div class="item3">
                            <input id="mail"></input>
                        </div>
                        <div class="item4">
                            <b>PASSWORD</b>
                        </div>
                        <div class="item5">
                            <input type="password" id="passcheck"></input>
                        </div>
                        <div class="item6" >
                            <b>ADDRESS</b>
                        </div>
                        <div class="item5">
                            <input id="addr"></input>
                        </div>
                        <div class="item6">
                            <b>PHONE</b>
                        </div>
                        <div class="item5">
                            <input id="phone"></input>
                        </div>
                        <div class="item8">
                            <!-- After we enter it links us to the login page -->
                                <button onclick=usersinput()>Enter</button>
                        </div>
                        <div class="item8">
                            <!-- After we enter it links us to the login page -->
                            <h1 id="error"></h1>
                        </div>
                    </div>
            </div>
        </div>
    </body>
    <!-- To dynamically generate a footer -->
    <?php
        page_footer();
    ?>
</html>