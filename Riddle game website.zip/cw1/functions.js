//The usersinput() is used to register the user to the game
function usersinput()
{
     let score = 0
     let UsersAverageTime = 0
     let email = document.getElementById("mail").value
     let userName = document.getElementById("user").value
     let Passwordof = document.getElementById("passcheck").value
     let Address = document.getElementById("addr").value
     let PhoneNumber = document.getElementById("phone").value
     let temp=""
     let theError= document.getElementById("error")
    
     let userslist = []
     let present = ""
     
     //This for loop is used to see if the email which the user typed exists
     for(var i=0;i<localStorage.length;i++)
          {
               if(email==localStorage.key(i))
               {
                    temp="EXISTANT"
               }    
          }
     //This for loop is used to add the usernames of the users into an array.
     for(let x=0;x<localStorage.length;x++)
     {
          usersnow =JSON.parse(localStorage[localStorage.key(x)])
          userslist.push(usersnow.userName)
     }
     /*The array is now used to see if the username the username has already been taken.
     If the username has been taken an error message is displayed.
     */
     for(let i=0;i<localStorage.length;i++)
     {
          if(userName==userslist[i])
          {
               
               present="USER_EXISTANT"
          }
     }
     //The if statement below helps us to see if a username exists.
     if(present == "USER_EXISTANT")
     {
          theError.innerHTML = "USER EXISTS"
     }

     //The else if statement below helps us to see if an email exists.
     else if(temp =="EXISTANT")
     {
          theError.innerHTML ="Email Exists"
     }
     /*The code from line 57 to line 84 is used to see if the user has not typed
     their username,email,password,address or phone number. If they don't 
     an error message is displayed
     */
     else if(userName =="")
     {
          theError.innerHTML = "Username required"
          
     }

     else if(email =="")
     {
          theError.innerHTML = "Email required"
          
     }
     else if(Passwordof =="")
     {
          theError.innerHTML = "Password required"
          
     }

     else if(Address =="")
     {
          theError.innerHTML = "Address required"
          
     }

     else if(PhoneNumber =="")
     {
          theError.innerHTML = "Phone Number required"
          
     }

     //This else if statement below helps is used to see if the email has an "@" and a dot
     else if((!email.includes("@")) || (!email.includes(".")))
     {
          theError.innerHTML ="Invalid email"
     }
     //The else if staement below is used to see if the users input is a number
     else if(isNaN(PhoneNumber)== true)
     {
          theError.innerHTML ="Invalid number"
     }
     //The else if staement below is used to see if the users entered 10 digits
     else if(PhoneNumber.length<10 ||PhoneNumber.length>10)
     {
          theError.innerHTML ="Enter 10 digits"
     }

     else
     {
          /*If there are no errors in the users registration we register the user and
          add the user to localstorage after we clear the input text areas and give a message showing that
          Their registration was successful.The user is then taken to the login page
          */
          let Errornon= document.getElementById("error")
          Errornon.innerHTML="SUCCESSFULLY REGISTERD"

          localStorage[email] = JSON.stringify({email,userName,Passwordof,score,UsersAverageTime,Address,PhoneNumber})      
          document.getElementById("mail").value = ""
          document.getElementById("user").value = ""
          document.getElementById("passcheck").value = ""
          document.getElementById("addr").value = ""
          document.getElementById("phone").value = ""
          window.location.href="index.php"
     }
}


function loginEvaluation()
{
     let score = 0
     let loginEmail = document.getElementById("mail").value
     let loginPassword = document.getElementById("passwordCheck").value
     let theError= document.getElementById("error")
     //The if statement below is used to see if an email has been typed in 
     if(loginEmail =="")
     {
          theError.innerHTML = "Email required"
          
     }
     //The else if statement below is used to see if a passwordl has been typed in 
     else if(loginPassword =="")
     {
          theError.innerHTML = "Password required"
          
     }
     //The else if statement below is used to see if the email typed in exists in our database
     else if(localStorage[loginEmail] == undefined)
     {
          theError.innerHTML ="Nonexistant email"
     }
      
     else
     {
          let userData = JSON.parse(localStorage[loginEmail])
          //This if statement below is used to see if the user has entered the wrong password
          if(loginPassword != userData.Passwordof)
          {
               theError.innerHTML = "Incorrect Password"
          }
          //If everything is okay the users email and score are stored in sessionStorage and the user is sent to the game page
          else
          {
               theError.innerHTML = "Successfully Logged in"
               sessionStorage[loginEmail] = JSON.stringify({loginEmail,score})
               document.getElementById("mail").value = ""
               document.getElementById("passwordCheck").value = ""
               window.location.href="game.php"
          }
     }
}
/*logOut() is used to log out the user and clear the session storage 
which automatically logs the user in
*/
function logOut()
{
     sessionStorage.clear()
     window.location.href="index.php"
}

/*checklogged() is used to see if the user is already signed in if they are we 
automatically sign them in.
*/
function checklogged()
{
     if(sessionStorage.length!=0){
          window.location.href="game.php"
     }
}
