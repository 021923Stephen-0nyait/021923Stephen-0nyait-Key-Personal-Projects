
let confirmationNumber
let time=30
let TimeSum =0
let score=0
let counter =1
//array of questions
let questions =
    [
        "What kind of apples do computers prefer?",
        "I am a bird, a person, and a fruit. What am I?",
        "What do you call a cat who loves to swim?",
        "I am the father of fruits. What am I?",
        "What has hands but does not clap?",
        "I have legs but cannot walk. What am I?",
        "I can fill up a room without taking any space what am I?",
        "What cannot talk but will reply when spoken to?",
        "The more of this there is, the less you see. What am I?",
        "What is full of holes but still holds water?",
        "What goes up but never comes down?",
        "I have branches, but no fruit, trunk or leaves. What am I?",
        "What has many keys but can’t open a single lock?",
        "What has lots of eyes, but can’t see?",
        "What has one eye, but can’t see?",
        "What is so fragile that saying its name breaks it?",
        "What goes through cities and fields, but never moves?",
        "The more you take, the more you leave behind. What are they?",
        "People make me, save me, change me, raise me. What am I?",
        "What is the end of everything?",
        "What has a bottom at the top?",
        "What kind of coat is best put on wet?",
        "What has a thumb and four fingers, but is not a hand?",
        "What is cut on a table, but is never eaten?",
        "What has many teeth, but can’t bite?",
        "What has one head, one foot and four legs?",
        "What has words, but never speaks?",
        "What goes up and down but doesn’t move?",
        "Where does today come before yesterday?",
        "What invention lets you look right through a wall?",
        "What can you break, even if you never pick it up or touch it?",
        "What has to be broken before you can use it?",
        "You bought me for dinner but never eat me. What am I?",
        "What has a neck but no head and arms but no hands?"
    ]
//array of answers
let answers =
[
    "macintosh",
    "kiwi",
    "catfish",
    "papaya",
    "clock",
    "chair",
    "light",
    "echo",
    "darkness",
    "sponge",
    "age",
    "bank",
    "piano",
    "potato",
    "needle",
    "silence",
    "roads",
    "footsteps",
    "money",
    "g",
    "legs",
    "paint",
    "gloves",
    "cards",
    "comb",
    "bed",
    "books",
    "stairs",
    "dictionary",
    "windows",
    "promises",
    "eggs",
    "cutlery",
    "shirts"
]

function gameplay()
{  
    let OutputQuestion = document.getElementById("Question")
    clickedit()
    //This part below helps us to select a random question
    let randomizer = Math.floor(Math.random()*34)
    confirmationNumber=randomizer
    let questionGiven = questions[randomizer]
    OutputQuestion.innerHTML = questionGiven

}

//Take answer gets the users input and validates it
function TakeAnswer()
{
    let CurrentGameMode = document.getElementById("GameMode")
    let QuestionNumber = document.getElementById("questionNumber")
    let UsersAnswer = document.getElementById("AnswerGiven").value
    /*The code below helps us to see if the users answer matches the right answer by 
    checking wether thier index numbers are the same
    */
    if(answers.indexOf(UsersAnswer)==confirmationNumber)
    {
        counter+=1
        score +=1
        if(score==18)
        {
            //this stops the game when we reach question 18
            return EndGame()
        }
        /*The if and else if statements in the section below help us to change the time 
        and game mode depending on our score it also stops the time and resets it based on the score
        */
        if(score>=5 && score<11)
        { 
            CurrentGameMode.innerHTML= "Medium Mode"
            QuestionNumber.innerHTML=counter
            clearInterval(starttime)
            TimeSum += (20-time)
            time =20
        }
        else if(score>=11)
        {
            CurrentGameMode.innerHTML= "Hard Mode"
            QuestionNumber.innerHTML=counter
            clearInterval(starttime)
            TimeSum += (10-time)
            time=10
        }

        else
        {
            CurrentGameMode.innerHTML= "Easy Mode"
            QuestionNumber.innerHTML=counter
            clearInterval(starttime)
            TimeSum += (30-time)
            time=30
            
        }
        document.getElementById("AnswerGiven").value = ""
        return gameplay()
     
    }
    

    else
    {
        //the code within this statement ends the game if the answer is wrong
        clearInterval(starttime)
        EndGame() 
    }

}

/*clicked() it helps us to keep decreasing the time by 1 second by calling to updateTime()
every second which subtracts the start time by one every second
*/
function clickedit()
{
    starttime =setInterval(updateTime,1000)
}


function updateTime()
{
    let countdowntime = document.getElementById('ourtimer')
    
    
    time=time-1
    if(time <=0)
    {
    
        clearInterval(starttime)
        EndGame()
    }

    countdowntime.innerHTML = time
}

function EndGame()
{
    //The code below is used to get the users average time and store it in the session storage  after it links us to the gameover page
    let AverageTime = (TimeSum/score)
    window.location.href="gameover.php"
    theusername = JSON.parse(sessionStorage[sessionStorage.key(0)])
    let email =JSON.parse(sessionStorage[sessionStorage.key(0)])
    let loginEmail = email.loginEmail
    sessionStorage[sessionStorage.key(0)] = JSON.stringify({loginEmail,score,AverageTime})
    
}