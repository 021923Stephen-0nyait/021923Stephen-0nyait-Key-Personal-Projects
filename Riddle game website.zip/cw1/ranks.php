<?php
    include 'common.php';
    outputheader("Ranks","ranks_styling.css","RANKS","");
?>
                    <div class="body"> 
                        
                        <div class="USERNAME"><b>USERNAME</b></div>
                        <div class="QUESTION"><b>QUESTION</b></div>
                        <div class="TIME"><b>AVERAGE TIME</b></div>
                        <div id="ranksName" class="lb"></div>
                        <div id="ranksScore" class="lb"></div>
                        <div id="ranksTime" class="lb"></div>
                        <script>
                            //the script here is used to dynamically put out the users scores
                            for(let x=0;x<localStorage.length;x++)
                            {
                                let usersrankdata = localStorage.key(x)
                                let UsersUsername = JSON.parse(localStorage[localStorage.key(x)]).userName
                                let AverageTimeOfUser = JSON.parse(localStorage[localStorage.key(x)]).UsersAverageTime
                                let UserScore = JSON.parse(localStorage[localStorage.key(x)]).score
                                document.getElementById("ranksName").innerHTML+='<div class="lb">'+UsersUsername +"</b></div>"
                                document.getElementById("ranksScore").innerHTML+='<div class="lb">'+UserScore+"</b></div>"
                                document.getElementById("ranksTime").innerHTML+='<div class="lb">'+AverageTimeOfUser+"</b></div>"

                            }
            
                        </script>
                    </div>
            </div>
        </div>
    </body>
    <?php
        page_footer();
    ?>
</html>