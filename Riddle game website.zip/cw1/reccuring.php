<?php
function outputheader($title,$stylesheet,$pagetitle,$nav,$btn,$icon,$javascript){
    echo'
    <!DOCTYPE html>
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="stylesheet/'.$stylesheet.'">
        <link rel="stylesheet" href="stylesheet/recurring_style.css">
        <script language="javascript" src="functions.js"></script>
        <script language="javascript" src="'.$javascript.'"></script>
        <title>'.$title.' Page</title>
    </head>
    <body>
        <div class="container">
            <div class="main">
                    <div class="header">
                        <h1 id="game_name">THE RIDDLER</h1>
                    </div>
                    <div class="btns">
                    <!-We use the nav variable to put the page which we are navigating to -->
                        <nav>
                        <a href="'.$nav.'">
                        <!-- Bellow we use icon to put the appropriate icon and btn to put the appropriate button name -->
                            <button id='.$icon.'>'.$btn.'</button>
                        </a>
                        </nav>
                
                    </div>
                    <div class="title">
                    <!-- This cariable is to generate the name of the page below the nav bar -->
                        <h1 class="page_title"> '.$pagetitle.'<h1>
                    </div>
                    ';
}

function page_footer(){
    echo'
    <!-- This section is used to generate a footer -->
    <footer>Created By:Stephen Onyait</footer>
    ';
}
?>