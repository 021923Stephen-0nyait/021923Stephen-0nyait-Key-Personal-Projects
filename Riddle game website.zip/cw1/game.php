<?php
    include 'common.php';
    outputheader("Game","game_style.css","GAME","gamescript.js");
?>
                    <div class="innerbody">
                        <div class="game"> 
                            <!-- This is where the user will play the game -->
                            <div class="item1">
                                <button id="flag" onclick="gameplay()">START</button>
                            </div>
                            <div class="mode" id="GameMode"><b>Easy Mode</b></div>
                            <div class="item2" ><b>Question</b></div>
                            <div class="item3"><b>Time</b></div>
                            <div class="item4" id="questionNumber"><b>1</b></div>
                            <div class="item5" id="ourtimer"><b>30</b></div>
                            <div class="item6" id="Question"><b></b></div>
                            <div class="item7">
                                <input id="AnswerGiven"></input>
                            </div>
                            <div class="item8">
                                <!-- validates answer and increments progress bar -->
                                <button onclick="TakeAnswer();frame()">Enter</button>
                            
                            </div>
                        </div>
                        <div id="myProgress">
                            <div id="myBar">1</div>
                        </div>
                        <script>
                            //This script is used to keep filling the progress bar when we reach a higher question
                            let i = 0;
                            let elem = document.getElementById("myBar");
                            let height = 5.567;
                            let question = 1
                            function frame() {
                                if (height >= 100) {
                                    i = 0;
                                } else {
                                    height+=5.575;
                                    question++
                                    elem.style.height = height + "%";
                                    elem.innerHTML = question  
                                }
                            }         
                        </script>                 
                    </div>
            </div>
        </div>
    </body>
    <?php
        page_footer();
    ?>
</html>