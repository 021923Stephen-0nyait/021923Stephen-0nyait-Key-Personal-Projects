<?php
    include 'reccuring.php';
    outputheader("Login","game_login_style.css","LOGIN","registration.php","REGISTRATION","reg","");
?>
                    <script>checklogged()</script>
                    <div class="theform">
                        <!-- login Section --> 
                        <div class="item2">
                            <b>EMAIL</b>
                        </div>
                        <div class="item3">
                            <input id="mail"></input>
                        </div>
                        <div class="item2">
                            <b>PASSWORD</b>
                        </div>
                        <div class="item3">
                            <input type="password" id="passwordCheck"></input>
                        </div>
                        <div class="item8">
                            <!-- Button linking to game -->
                            <button onclick=loginEvaluation()>Enter</button>
                        </div>
                        <div class="item8">
                            <h1 id="error"></h1>
                        </div>
                    </div>
            </div>
        </div>
    </body>
    <!-- Dynamic Page Footer -->
    <?php
        page_footer();
    ?>
</html>