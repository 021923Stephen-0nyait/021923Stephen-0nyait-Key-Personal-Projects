function giveScore()
{
    //The variables below help us to get the users information
    let ScoreInfo = JSON.parse(sessionStorage[sessionStorage.key(0)])
    let usersscore = ScoreInfo.score
    let UsersAverageTime = ScoreInfo.AverageTime
    let email =JSON.parse(localStorage[sessionStorage.key(0)]).email
    let userName =JSON.parse(localStorage[sessionStorage.key(0)]).userName
    let Passwordof =JSON.parse(localStorage[sessionStorage.key(0)]).Passwordof
    let score =JSON.parse(localStorage[sessionStorage.key(0)]).score
    let Address =JSON.parse(localStorage[sessionStorage.key(0)]).Address
    let PhoneNumber =JSON.parse(localStorage[sessionStorage.key(0)]).PhoneNumber
    /*The if statement and the else statement below help us to update the score if the current score
    in session storage is more than the score in the local storage it also shows the user the score they go and their average
    time in the gameover page.
    */
    if(usersscore>score)
    {
        score=JSON.parse(localStorage[sessionStorage.key(0)]).score = usersscore
        document.getElementById("finalscore").innerHTML = usersscore 
        document.getElementById("finaltime").innerHTML =  UsersAverageTime
        return localStorage[email] = JSON.stringify({email,userName,Passwordof,score,UsersAverageTime,Address,PhoneNumber})
    }
    else
    {
        
        document.getElementById("finalscore").innerHTML = usersscore 
        document.getElementById("finaltime").innerHTML =  UsersAverageTime
        UsersAverageTime = JSON.parse(localStorage[sessionStorage.key(0)]).UsersAverageTime
        localStorage[email] = JSON.stringify({email,userName,Passwordof,score,UsersAverageTime,Address,PhoneNumber})
    }
    
}

