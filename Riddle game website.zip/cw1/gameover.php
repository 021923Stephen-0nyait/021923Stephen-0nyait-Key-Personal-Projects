<?php
    include 'common.php';
    outputheader("Game Over","gameover_styling.css","GAME OVER","endgame.js");
?>
                    <div class="bodygrid"> 
                        <!-- Gameover and score details -->
                        <div class="item1">
                            <b>QUESTION</b>
                        </div>
                        <div class="item2" id="finalscore">
                        </div>
                        <div class="item3">
                            <b>AVERAGE TIME:</b>
                        </div>
                        <div class="item4" id="finaltime">
                        </div>
                        <script>
                            giveScore()
                        </script>
                        <div class="item5">
                        <a href="game.php">
                            <button>BACK TO GAME</button>
                        </a>
                        </div>
                    </div>
            </div>
        </div>
    </body>
    <!-- Dynamic footer -->
    <?php
        page_footer();
    ?>
</html>