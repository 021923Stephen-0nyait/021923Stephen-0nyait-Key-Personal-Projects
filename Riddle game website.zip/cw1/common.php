<?php
function outputheader($title,$stylesheet,$pagetitle,$javascript){
    echo'
    <!-- This section of php is used to generate header and title details -->
    <!DOCTYPE html>
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="stylesheet/commonstyling.css">
        <link rel="stylesheet" href="stylesheet/'.$stylesheet.'">
        <script language="javascript" src="functions.js"></script>
        <script language="javascript" src="'.$javascript.'"></script>
        <title>'.$title.' Page</title>
    </head>
    <body>
        <div class="container">
            <div class="main">
                    <div class="header">
                        <h1 id="game_name">THE RIDDLER</h1>
                    </div>
                    <div class="btns">
                        <nav>
                            <div class="navigation">
                            <div>
                            <a href="game.php">
                                <button id="gicon">
                                    GAME
                                </button>
                            </a>
                            </div>
                            <a href="rules.php">
                                <button id="rul">RULES</button>
                            </a>
                            <a href="ranks.php">
                                <button id="ran">RANKING</button>
                            </a>
                            <button id="lout" onclick=logOut()>LOG OUT</button>
                            </div>
                        </nav>
                        
                    </div>
                    <div class="title">
                        <h1 class="page_title">'.$pagetitle.'<h1>
                    </div>
                    ';

}

function page_footer(){
    echo'
    <!-- This section is used to generate a footer -->
    <footer>Created By:Stephen Onyait</footer>
    ';
}
?>