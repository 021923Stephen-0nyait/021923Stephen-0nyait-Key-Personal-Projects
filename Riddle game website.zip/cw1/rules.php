<?php
    include 'common.php';
    outputheader("Rules","game_rules_styling.css","RULES","");
?>
                    <div class="game">
                        <!-- This is where we have the rules of the game -->

                        <div class="item1">
                            <b>1)You will have a maximum of 18 questions to answer.</b>
                        </div>

                        <div class="item2">
                            <b>2)The game will have three modes easy, medium and hard.</b>
                        </div>

                        <div class="item1">
                            <b>3)For the easy mode you will have 30 seconds to answer a question.</b>
                        </div>

                        <div class="item2">
                            <b>4)For the medium mode you will have 20 seconds to answer a question.</b>
                        </div>

                        <div class="item1">
                            <b>5)For the Hard mode you will have 15 seconds to answer a question.</b>
                        </div>

                        <div class="item2">
                            <b>6)The mode that you are on will be displayed below the start button.</b>
                        </div>
                        <div class="item1">
                            <b>7)To start the game press the start button.</b>
                        </div>
                        <div class="item2">
                            <b>8)Enter your answer in the input box to the right of the question.</b>
                        </div>
                        <div class="item1">
                            <b>9)To submit your answer press the enter button</b>
                        </div>

                        <div class="item2">
                            <b>10)Enter your answer in one word answers</b>
                        </div>
                        <div class="item3">
                            <b>Enjoy the game :)</b>
                        </div>
                        <div class="item3">
                            <a href="game.php">
                                <button>Back to Game</button>
                            </a>
                        </div>
                    
                    </div>
            </div>
        </div>
    </body>
    <!-- Dynamic footer -->
    <?php
        page_footer();
    ?>
</html>