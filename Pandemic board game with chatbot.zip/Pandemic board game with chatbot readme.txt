PANDEMIC BOARD GAME
This repository contains the coursework for developing a board game called Pandemic. The objective of the game is to stop a pandemic by finding the cure before
certain game-ending conditions are met.

GAME OVERVIEW
The aim of the game is to find a cure for all diseases and treat all cities before the game ends. Game over conditions: outbreak occurrence, depletion of disease cubes, or empty player deck.

TECHNOLOGIES USED
The following technology was used in the development of this project:
- Java: A general-purpose programming language used for developing applications, including machine learning algorithms.

FEATURES
- Chatbot Assistance: A chatbot helps players make decisions to improve their chances of winning the game.
- Decision-Making Algorithm: The chatbot uses a probability tree to evaluate the best decisions based on the likelihood of finding a cure and reducing the probability of outbreaks.
- Autonomous Agent: An agent plays the game independently, utilizing the same decision-making tree.

TWO ALGORITHMS USED
(i) PROBABILITY TREE ALGORITHM
A probability tree is used to determine the optimal decision at a given point in the game. The decision-making process involves the following steps:
1. Check if the probability of finding a cure is 1. If so, prioritize obtaining the cure in a city with a research station.
2. If the probability is not 1, check if the probability of finding a cure is 1 when players share cards of the same color. If yes, prioritize card sharing.
3. Determine the shortest path to reach the closest city with a research station using the Monte Carlo simulation.
4. If finding a cure or sharing cards does not guarantee success, prioritize reducing the probability of outbreaks.
5. Evaluate the region most likely to produce a chain outbreak and suggest treating the cities in that region based on a ranking list.

(ii) MONTE CARLO ALGORITHM
The Monte Carlo simulation algorithm is used to find the shortest path for finding a cure or sharing cards. The algorithm operates as follows:
1. Simulate distances from cities the player can start from to the target city using random numbers.
2. Explore neighboring cities while avoiding revisiting previous layers.
3. Backtrack from the target city to the starting node, storing the most optimal path in an array.
4. The distance represents the number of layers required to reach the target city.

GETTING STARTED
To get started with the project, follow these steps:
1. Download the project from the drive.
2. Make sure Java is installed on your system.
3. Set up the required development environment, such as an IDE or command line.
4. Import the project into your chosen development environment.
5. Run the project to execute the digit recognition algorithm.

CONTRIBUTORS
Stephen Onyait