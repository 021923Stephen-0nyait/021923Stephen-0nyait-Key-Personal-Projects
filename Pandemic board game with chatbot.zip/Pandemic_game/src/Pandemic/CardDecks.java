package Pandemic;

import java.util.ArrayList;
import java.util.Arrays;


public class CardDecks {
	private int NUMBER_OF_CARDS=48;
	private int NUMBER_OF_PLAYERS;
	private int CARDS_PER_PLAYER;
	private int DIFFICULTY_LEVEL;
	private ArrayList<Integer> INFECTION_DECK= new ArrayList<Integer>(48);
	private ArrayList<Integer> PLAYER_DECK= new ArrayList<Integer>(48);
	private ArrayList<Integer> INFECTION_DISCARD_DECK= new ArrayList<Integer>();
	private ArrayList<Integer> DISCARDED_CARDS= new ArrayList<Integer>();
	private ArrayList<Integer> AVAILABLE_INFECTION_CARDS= new ArrayList<Integer>();
	private ArrayList<Integer> PLAYER_DISCARD_DECK= new ArrayList<Integer>();
	private int playerCards[][]; 
	
	CardDecks(int players,int difficulty)
	{
		this.NUMBER_OF_PLAYERS = players;
		this.CARDS_PER_PLAYER = cardsPerPlayer(players);
		this.DIFFICULTY_LEVEL=difficulty;
		this.playerCards=new int[NUMBER_OF_PLAYERS][CARDS_PER_PLAYER];
		initializeDecks();
	}
	//Give each player cards
	public int[] initialDistribution() 
	{
		int playersHands[]= new int[CARDS_PER_PLAYER];
		for(int y=0;y<playersHands.length;y++) 
		{
			int upperBoud=PLAYER_DECK.size();
			int lowerBound=0;;
			String cardNumber=Double.toString(Math.floor(Math.random()*(upperBoud-lowerBound) + lowerBound));
			int substringEnd=cardNumber.indexOf(".");
			String randomNumber= cardNumber.substring(0,substringEnd);
			int randomCard= Integer.parseInt(randomNumber);
			int cardDetails= PLAYER_DECK.get(randomCard);
			playersHands[y]=cardDetails;
			PLAYER_DISCARD_DECK.add(playersHands[y]);
			PLAYER_DECK.remove(Integer.valueOf(cardDetails));
		}
		return playersHands;
	}
	
	//shows how many cards to give players
	private int cardsPerPlayer(int players) 
	{
		//Validate player number
		if(players==2) 
		{
			return 4;
		}
		if(players==3) 
		{
			return 3;
		}
		//Validate player number
		if(players==4) 
		{
			return 2;
		}
		
		return 0;
	}
	
	//shuffle and add epidemic cards
	public void setPlayerCards() 
	{
		int difficultyCards=-1;
		if(DIFFICULTY_LEVEL==1) 
		{
			difficultyCards=4;
		}
		if(DIFFICULTY_LEVEL==2) 
		{
			difficultyCards=5;
		}
		
		if(DIFFICULTY_LEVEL==3) 
		{
			difficultyCards=6;
		}
		double initialSections=PLAYER_DECK.size()/(difficultyCards*1.0);
		double minimumCards= Math.floor(initialSections);
		String transformDouble= String.format("%f", minimumCards);
		int decimalIndex = transformDouble.indexOf(".");
		String transformedDouble = transformDouble.substring(0,decimalIndex);
		int difficultyMultiples=Integer.parseInt(transformedDouble);
		int batchSize= difficultyMultiples+2;
		int cardBatches[][]=new int [difficultyCards][batchSize];
		int cityCardIndex=0;
		for(int x=0;x<cardBatches.length;x++) 
		{
			for(int y=0;y<batchSize;y++) 
			{
				if(y==0) 
				{
					cardBatches[x][y]=-1;
				}
				if(y!=0) 
				{
					if(cityCardIndex<PLAYER_DECK.size()) 
					{
						cardBatches[x][y]=PLAYER_DECK.get(cityCardIndex);
						cityCardIndex++;
					}

					
				}
			}
		}
		for(int x=0;x<cardBatches.length;x++) 
		{
			int currentArray[]=Arrays.copyOf(cardBatches[x], cardBatches[x].length);
			for(int i=0;i<currentArray.length;i++) 
			{
				int upperBound = currentArray.length;
				int lowerBound= 0;
				String cardNumber=Double.toString(Math.floor(Math.random()*(upperBound-lowerBound) + lowerBound));
				int substringEnd=cardNumber.indexOf(".");
				String randomNumber= cardNumber.substring(0,substringEnd);
				int randomCard= Integer.parseInt(randomNumber);
				
				int temp = currentArray[i];
				currentArray[i]=currentArray[randomCard];
				currentArray[randomCard]=temp;
			}
			cardBatches[x]=currentArray;
		}
		
		PLAYER_DECK.clear();
		
		
		for(int x=0;x<cardBatches.length;x++) 
		{
			for(int y=0;y<cardBatches[x].length;y++) 
			{
				if(cardBatches[x][y]!=0) 
				{
					PLAYER_DECK.add(cardBatches[x][y]);
				}
				
			}
		}
	}
	
	//The function below gives cards to the players from the player deck
	public int[] givePlayerCards(int numberOfCards) 
	{
		int playersCards[]= new int[numberOfCards];
		for(int i=0; i<numberOfCards;i++) 
		{
			playersCards[i] = PLAYER_DECK.get(0);
			PLAYER_DISCARD_DECK.add(playersCards[i]);
			PLAYER_DECK.remove(0);
		}
		return playersCards;
	} 
	
	//the function below shuffleInfectionDeck in beginning
	public void shuffleInfectedDeck() 
	{
		int tempArray[] = new int[INFECTION_DECK.size()];
		for(int i=0;i<INFECTION_DECK.size();i++) 
		{
			tempArray[i]=INFECTION_DECK.get(i);
		}
		for(int i=0;i<tempArray.length;i++) 
		{
			int upperBound = tempArray.length;
			int lowerBound= 0;
			String cardNumber=Double.toString(Math.floor(Math.random()*(upperBound-lowerBound) + lowerBound));
			int substringEnd=cardNumber.indexOf(".");
			String randomNumber= cardNumber.substring(0,substringEnd);
			int randomCard= Integer.parseInt(randomNumber);
			
			int temp = tempArray[i];
			tempArray[i]=tempArray[randomCard];
			tempArray[randomCard]=temp;
		}
		INFECTION_DECK.clear();
		for(int i=0;i<tempArray.length;i++) 
		{
			INFECTION_DECK.add(tempArray[i]);
			AVAILABLE_INFECTION_CARDS.add(tempArray[i]);
		}
	}
	
	//The function get cities to infect from the infection deck and sends them back
	public int[] infectCities(int numberOfCities) 
	{
		int citiesIndexes[]=new int[numberOfCities];
		for(int i=0;i<numberOfCities;i++) 
		{
			int currentCity=INFECTION_DECK.get(0);
			citiesIndexes[i]=currentCity;
			AVAILABLE_INFECTION_CARDS.remove(Integer.valueOf(currentCity));
			INFECTION_DISCARD_DECK.add(currentCity);
			DISCARDED_CARDS.add(currentCity);
			INFECTION_DECK.remove(Integer.valueOf(currentCity));
		}
		return citiesIndexes;
	} 
	
	//The function below is used to see the player cards.
	public void viewPlayerCards() 
	{
		for(int x=0;x<playerCards.length;x++) 
		{
			for(int y=0;y<playerCards[x].length;y++) 
			{
				System.out.print(playerCards[x][y]+" ");
			}
			System.out.println();
		}
	}
	
	/*The function below is used to create the player deck and the infection deck*/
	private void initializeDecks() 
	{
		for(int i=1;i<=NUMBER_OF_CARDS;i++) 
		{
			INFECTION_DECK.add(i);
			PLAYER_DECK.add(i);
		}
		
	}
	
	//The epidemic function shuffles the discarded cards and puts them on top
	public void epidemic() 
	{
		int tempArray[] = new int[INFECTION_DISCARD_DECK.size()];
		for(int i=0;i<INFECTION_DISCARD_DECK.size();i++) 
		{
			tempArray[i]=INFECTION_DISCARD_DECK.get(i);
		}
		for(int i=0;i<tempArray.length;i++) 
		{
			int upperBound = tempArray.length;
			int lowerBound= 0;
			double cardNumber=Math.floor(Math.random()*(upperBound-lowerBound) + lowerBound);
			int randomCard= (int)cardNumber;
			
			int temp = tempArray[i];
			tempArray[i]=tempArray[randomCard];
			tempArray[randomCard]=temp;
		}
		for(int i=0;i<tempArray.length;i++) 
		{
			int lastIndex = INFECTION_DECK.size();
			INFECTION_DECK.add(lastIndex,tempArray[i]);
		}
		INFECTION_DISCARD_DECK.clear();
	}
	//The function below adds cards to the player discard deck
	public void discardCity(int cityIndex)
	{
		PLAYER_DISCARD_DECK.add(cityIndex);
	}
	
	/*The function below is used to check if the game is over*/
	public int gameOver() 
	{
		int deckSize=PLAYER_DECK.size();
		int remaingCards=deckSize-2;
		if(remaingCards<=0) 
		{
			return 1;
		}
		return 0;
	}
	
	//Below shows all the getters and setters
	public ArrayList<Integer> getDISCARDED_CARDS() {
		return DISCARDED_CARDS;
	}
	public void setDISCARDED_CARDS(ArrayList<Integer> dISCARDED_CARDS) {
		DISCARDED_CARDS = dISCARDED_CARDS;
	}
	public ArrayList<Integer> getPLAYER_DISCARD_DECK() {
		return PLAYER_DISCARD_DECK;
	}
	public void setPLAYER_DISCARD_DECK(ArrayList<Integer> pLAYER_DISCARD_DECK) {
		PLAYER_DISCARD_DECK = pLAYER_DISCARD_DECK;
	}
	public ArrayList<Integer> getPLAYER_DECK() {
		return PLAYER_DECK;
	}
	public void setPLAYER_DECK(ArrayList<Integer> pLAYER_DECK) {
		PLAYER_DECK = pLAYER_DECK;
	}
	
	
	
}
