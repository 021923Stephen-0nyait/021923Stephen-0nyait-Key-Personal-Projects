package Pandemic;

import java.util.ArrayList;

public class MonteCarloAlgoritm 
{
	public int layerNumber=0;
	ArrayList<Integer> visitedNodes= new ArrayList<Integer>();
	
	int directions[];
	
	/*The function below is used to return the shortest path*/
	public int[] getDirections(Node nextNodes[],int expectedValue) 
	{
		createTree(nextNodes,expectedValue);
		return directions;
	}

	/*The function below is used to simulate different moves until the target is found*/
	private void createTree(Node nextNodes[],int expectedValue) 
	{
		Board board = new Board();
		board.readFileData();
		board.handleFileData();
		board.cityConnectionsList();
		int found=0;
		int nodesLayer=nextNodes[0].layer;
		layerNumber=nodesLayer+1;
		int nodesPerLayer=0;
		Node nextLayer[]= {};
		for(int i=0;i<nextNodes.length;i++) 
		{
			int cityIndex= nextNodes[i].value;
			visitedNodes.add(cityIndex);
		}
		
		for(int x=0;x<nextNodes.length;x++) 
		{
			int cityIndex= nextNodes[x].value;
			int neighbours[]=board.getNeighboursIndex(cityIndex);
			for(int y=0;y<neighbours.length;y++)
			{
				if(visitedNodes.indexOf(Integer.valueOf(neighbours[y]))==-1 )
				{
					nodesPerLayer++;
				}
			}	
		}
		
		nextLayer=new Node[nodesPerLayer];
		int nextLayerIndex=0;
		for(int x=0;x<nextNodes.length;x++) 
		{
			int cityIndex= nextNodes[x].value;
			if(cityIndex==expectedValue) 
			{
				found=1;
				backtrack(nextNodes[x]);
				break;
			}
		}
		
		if(found==0)
		{
			for(int x=0;x<nextNodes.length;x++) 
			{
				int cityIndex= nextNodes[x].value;
				int neighbours[]=board.getNeighboursIndex(cityIndex);
				
				for(int y=0;y<neighbours.length;y++) 
				{
					if(visitedNodes.indexOf(Integer.valueOf(neighbours[y]))==-1)
					{
						Node node=new Node(neighbours[y],layerNumber, nextNodes[x]);
						nextLayer[nextLayerIndex]=node;
						nextLayerIndex++;
					}
				}
			}
			createTree(nextLayer,expectedValue);
		}
	}
	
	/*The function below is used to back track and find the shortest path to the targeted node*/
	private int[] backtrack(Node lastNode) 
	{
		Node currentNode = lastNode;
		int LayerNumber=lastNode.layer;
		ArrayList<Integer> initialRoute = new ArrayList<Integer>();
		for(int i=0;i<LayerNumber;i++) 
		{
			currentNode=currentNode.previousNode;
			initialRoute.add(currentNode.value);
		}
		int routeLength =initialRoute.size()-1;
		int route[]={};
		if(initialRoute.size()!=0) 
		{
			route= new int[routeLength];
		}
		int start=route.length;
		if(route.length!=0)
		{
			for(int i=start-1;i>-1;i--) 
			{
				route[(route.length-1)-i]=initialRoute.get(i);
			}
		}
		directions= route;
		return route;
	}
	
}
