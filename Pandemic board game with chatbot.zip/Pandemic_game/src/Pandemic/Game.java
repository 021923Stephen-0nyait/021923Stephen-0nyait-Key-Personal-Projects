package Pandemic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Game {
	private int NUMBER_OF_PLAYERS;
	private int DIFFICULTY;
	Board setBoard;
	CardDecks cards;
	public Player allPlayers[];
	double BLUE_CHANCE;
	double YELLOW_CHANCE;
	double GREY_CHANCE;
	double RED_CHANCE;
	
	double BLUE_PLAYER_CARD_CHANCE;
	double YELLOW_PLAYER_CARD_CHANCE;
	double GREY_PLAYER_CARD_CHANCE;
	double RED_PLAYER_CARD_CHANCE;
	
	double PROBABILITY_MATRIX[][] = new double[2][49];
	double REGION_MATRIX[][] = new double[3][49];
	String CITY_COLORS_NAME[] = {"BLUE","YELLOW","GREY","RED"};
	int CITY_COLORS_CHANCE[] = new int[4];
	double RANKED_PROBABILITY_MATRIX[][] = new double[2][49];
	int BLUE_REGIONS[] = {1,2,3,4,5,6,7,8,9,10,11,12};
	ArrayList<Integer> BLUE_REGION_STATION_RANKS=new ArrayList<Integer>();
	ArrayList<Integer> YELLOW_REGION_STATION_RANKS=new ArrayList<Integer>();
	ArrayList<Integer> GREY_REGION_STATION_RANKS=new ArrayList<Integer>();
	ArrayList<Integer> RED_REGION_STATION_RANKS=new ArrayList<Integer>();
	int YELLOW_REGIONS[] = {13,14,15,16,17,18,19,20,21,22,23,24};
	int GREY_REGIONS[] = {25,26,27,28,29,30,31,32,33,34,35,36};
	int RED_REGIONS[] = {37,38,39,40,41,42,43,44,45,46,47,48};
	double RANKED_REGION_MATRIX[][] = new double[3][49];
	ArrayList<Integer> INFECTED_CITY_RANKINGS= new ArrayList<Integer>();
	boolean EXCESS_CARDS=false; 
	ArrayList<Integer> REGIONAL_RANKINGS= new ArrayList<Integer>();
	
	Game(int numberOfPlayers,int difficulty)
	{
		this.NUMBER_OF_PLAYERS=numberOfPlayers;
		this.DIFFICULTY=difficulty;
		setBoard = new Board();
		
		cards = new CardDecks(numberOfPlayers,difficulty);
		allPlayers= new Player[numberOfPlayers];
		intitializePlayers();
		cards.setPlayerCards();
		cards.shuffleInfectedDeck();
		
		setBoard.readFileData();
		setBoard.handleFileData();
		setBoard.setDiseaseIndexes();
		int firstInfectedCities[] = cards.infectCities(9);
		setBoard.cityConnectionsList();
		setBoard.initialInfection(firstInfectedCities);
		BuildStationGuide();
	}
	
	//The function below named epidemic() is used to handle an epidemic and an out break when the player draws a epidemic card
	public void epidemic() 
	{
		int numberOfCards=setBoard.getInfectionNumber();
		int cities[]=cards.infectCities(numberOfCards);
		setBoard.infectCities(cities);//infecting a city
		setBoard.clearOutbreakQueue();
		cards.epidemic();
	}
	
	/*The function colorProbability() below is used to check the most likely card color that can be drawn.
	 * The probabilities found will help to prevent chain out breaks*/
	private void colorProbability() 
	{
		ArrayList<Integer> discarded=cards.getDISCARDED_CARDS();
		int blue=0;
		int yellow=0;
		int grey=0;
		int red=0;
		//Finding number of cards of each color in infection discard deck
		for(int i=0;i<discarded.size();i++) 
		{
			int colorOf = setBoard.colorGroup(discarded.get(i));
			if(colorOf==1) 
			{
				blue++;
			}
			if(colorOf==2) 
			{
				yellow++;
			}
			if(colorOf==3) 
			{
				grey++;
			}
			if(colorOf==4) 
			{
				red++;
			}
		}
		//Subtracting to find number of cards of a certain color in infection deck
		blue=12-blue;
		yellow=12-yellow;
		grey=12-grey;
		red=12-red;
		double deckSize= cards.getPLAYER_DECK().size()*1.0;
		//Finding probabilities
		BLUE_CHANCE=blue/deckSize;
		YELLOW_CHANCE=yellow/deckSize;
		GREY_CHANCE=grey/deckSize;
		RED_CHANCE=red/deckSize;
		
	}
	
	/*The function playerCardProbability() is used to get the probability of a player card of a
	 * certain color occuring which helps in finding the cure*/
	private void playerCardProbability() 
	{
		ArrayList<Integer> discarded=cards.getPLAYER_DISCARD_DECK();
		int blue=0;
		int yellow=0;
		int grey=0;
		int red=0;
		//Finding number of cards of each color in player discard deck
		for(int i=0;i<discarded.size();i++) 
		{
			int colorOf = setBoard.colorGroup(discarded.get(i));
			if(colorOf==1) 
			{
				blue++;
			}
			if(colorOf==2) 
			{
				yellow++;
			}
			if(colorOf==3) 
			{
				grey++;
			}
			if(colorOf==4) 
			{
				red++;
			}
		}
		//Subtracting to find number of cards of a certain color in player deck
		blue=12-blue;
		yellow=12-yellow;
		grey=12-grey;
		red=12-red;
		double deckSize= cards.getPLAYER_DECK().size()*1.0;
		int cured[]= setBoard.getCURE_MARKER();
		//Finding probabilities
		BLUE_PLAYER_CARD_CHANCE=blue/deckSize;
		YELLOW_PLAYER_CARD_CHANCE=yellow/deckSize;
		GREY_PLAYER_CARD_CHANCE=grey/deckSize;
		RED_PLAYER_CARD_CHANCE=red/deckSize;
		if(cured[0]==1) 
		{
			BLUE_PLAYER_CARD_CHANCE=0;
		}
		if(cured[1]==1) 
		{
			YELLOW_PLAYER_CARD_CHANCE=0;
		}
		if(cured[2]==1) 
		{
			GREY_PLAYER_CARD_CHANCE=0;
		}
		if(cured[3]==1) 
		{
			RED_PLAYER_CARD_CHANCE=0;
		}
		
	}
	
	/*The function below is used to evaluate whether or not it's effective to share cards.
	 * It does saw by checking if the sum of all the players probabilities is greater than one
	 * If the sum of the players probabilities is greater than 1 the function either suggests that the player
	 * moves closer to the next player or shares cards if the players are in the same city*/
	private int[][] cureByShare(int playerIndex) 
	{
		updateAllRankings();
		int nextPlayerIndex=0;
		if(playerIndex==0) 
		{
			nextPlayerIndex=1;
		}
		cureChance(playerIndex);
		cureChance(nextPlayerIndex);
		double playerCards[]=allPlayers[playerIndex].CURRENT_CURE_PROBABILITY;
		int chartterFlight=evaluateCharterFlight(playerIndex);
		int findCureProbabilities[]=new int[4];
		//calculating sum of probabilities for each color
		for(int x=0;x<playerCards.length;x++) 
		{
			double totalProbability=0;
			for(int y=0;y<allPlayers.length;y++) 
			{
				double currentProbability=allPlayers[y].CURRENT_CURE_PROBABILITY[x];
				totalProbability+=currentProbability;
			}
			if(totalProbability>=1.0) 
			{
				findCureProbabilities[x]=1;
			}
		}
		double largetNumber=0;
		int cureIndex=-1;
		//Gets the cure index of the player card color most likely to get a cure if a cure for a color has not been found
		for(int i=0;i<findCureProbabilities.length;i++) 
		{
			if(findCureProbabilities[i]==1)
			{
				double potentialLargest=0;
				if(i==0) 
				{
					potentialLargest=BLUE_PLAYER_CARD_CHANCE;
				}
				if(i==1) 
				{
					potentialLargest=YELLOW_PLAYER_CARD_CHANCE;
				}
				if(i==2) 
				{
					potentialLargest=GREY_PLAYER_CARD_CHANCE;
				}
				if(i==3) 
				{
					potentialLargest=RED_PLAYER_CARD_CHANCE;
				}
				int marker[]=setBoard.getCURE_MARKER();
				if(marker[i]!=1) 
				{
					cureIndex=i;
				}
				
				if(largetNumber<=potentialLargest && marker[i]!=1) 
				{
					largetNumber=potentialLargest;
					cureIndex=i;
				}
			}
		}
		//Stops if none of the cards can get a cure
		if(cureIndex==-1) 
		{
			int shareZero[][]= {{2},{0}};
			return shareZero;
		}
		//Getting shortest distance for driving
		MonteCarloAlgoritm monteCarlo = new MonteCarloAlgoritm();
		Node startNode=new Node(allPlayers[nextPlayerIndex].CURRENT_CITY,0, null);
		Node initializeNode[]= {startNode};
		int directions[] =monteCarlo.getDirections(initializeNode,allPlayers[playerIndex].CURRENT_CITY);
		int driveDistance=directions.length;
		String movementMethod="DRIVE";
		int flying[] =evaluateFlightdistance(playerIndex);
		int flyingDistance= flying[1];
		int choosenArray[]= Arrays.copyOf(directions, directions.length);
		
		int neighbours[]=setBoard.getNeighboursIndex(allPlayers[playerIndex].CURRENT_CITY);
		int sameCity=0;
		//share cards if players are in the same city
		if(allPlayers[playerIndex].CURRENT_CITY==allPlayers[nextPlayerIndex].CURRENT_CITY) 
		{
			System.out.println("");
			System.out.println("");
			System.out.println("___________________________");
			System.out.println("");
			System.out.println("AI SUGGESTION: SHARE "+CITY_COLORS_NAME[cureIndex]+" CARDS.");
			System.out.println("");
			System.out.println("___________________________");
			System.out.println("");
			System.out.println("");
			sameCity=1;
			int shareOne[][]= {{2},{1}};
			return shareOne;
		}
		int distanceChecker=0;
		if(sameCity==0)
		{
			for(int i=0;i<neighbours.length;i++) 
			{
				//Move to next city if players are in next city
				if(neighbours[i]==allPlayers[nextPlayerIndex].CURRENT_CITY) 
				{
					int neighbourArray[]= {neighbours[i]};
					String cityName[]= setBoard.getCityNames(neighbourArray);
					String cityDetails[]= cityName[0].split(",");
					String city[]= cityDetails[0].split(" ");
					System.out.println("___________________________");
					System.out.println("");
					System.out.println("|AI SUGGESTION:"+movementMethod+" TO "+city[2].toUpperCase()+" TO MOVE CLOSER TO NEXT PLAYER IN ORDER TO SHARE "+CITY_COLORS_NAME[cureIndex]+" CARDS|");
					System.out.println("");
					System.out.println("___________________________");
					distanceChecker=1;
					int shareTwo[][]= {{2},{2},neighbourArray};
					return shareTwo;
					
				}
			}
		}
		if(distanceChecker==0)
		{
			//Fly to players city if the distance from the city that the player flies to is shorter than the driving distance
			if(flyingDistance<driveDistance) 
			{
				movementMethod="FLY";
				int flyingArray[]={flying[0]};
				choosenArray= flyingArray;
			}
			//Chatter flight if charter flight is available
			if(chartterFlight!=0) 
			{
				movementMethod="CHATTER FLIGHT";
				int playerPosition[]= {allPlayers[nextPlayerIndex].CURRENT_CITY};
				choosenArray= playerPosition;
			}
			
			if(directions.length!=0) 
			{
				String cityName[]= setBoard.getCityNames(choosenArray);
				String cityDetails[]= cityName[0].split(",");
				String city[]= cityDetails[0].split(" ");
				
				System.out.println("_______________________");
				System.out.println("				 ");
				System.out.println("|AI SUGGESTION:"+movementMethod+" TO "+city[2].toUpperCase()+" TO MOVE CLOSER TO NEXT PLAYER IN ORDER TO SHARE "+CITY_COLORS_NAME[cureIndex]+" CARDS|");
				System.out.println("");
				System.out.println("___________________________");
				if(chartterFlight==0) 
				{
					int shareThree[][]= {{2},{3},choosenArray};
					return shareThree;
				}
				if(chartterFlight!=0) 
				{
					int shareFour[][]= {{2},{4},choosenArray};
					return shareFour;
				}
			}
		}
		
		
		int defaultCure[][]= {};
		return defaultCure;
	}
	
	/*The function cureChance() is used to get the probability of of a player getting player cards of a certain color
	 * from the player deck*/
	private void cureChance(int playerIndex) 
	{
		updateAllRankings();
		int playerCards[]=allPlayers[playerIndex].PLAYER_CARDS;
		int blue=0;
		int yellow=0;
		int grey=0;
		int red=0;
		for(int i=0;i<playerCards.length;i++) 
		{
			int colorOf = setBoard.colorGroup(playerCards[i]);
			if(colorOf==1) 
			{
				blue++;
			}
			if(colorOf==2) 
			{
				yellow++;
			}
			if(colorOf==3) 
			{
				grey++;
			}
			if(colorOf==4) 
			{
				red++;
			}
		}
		double blueCureChance=blue/5.0;
		double yellowCureChance=yellow/5.0;
		double greyCureChance=grey/5.0;
		double redCureChance=red/5.0;
		double cureProbability[]= {blueCureChance,yellowCureChance,greyCureChance,redCureChance};
		allPlayers[playerIndex].CURRENT_CURE_PROBABILITY= cureProbability;
		int deckSize= cards.getPLAYER_DECK().size();
		if(blueCureChance<1.0) 
		{
			int notBlue=5-blue;
			double notBlueChance=notBlue/5.0;
			int combination=calculateCombination(deckSize, notBlue);
			double cureChance=combination*(Math.pow(blueCureChance, notBlue))*(Math.pow(notBlueChance,(deckSize-notBlue)));
			blueCureChance=cureChance;
		}
		
		
		if(yellowCureChance<1.0) 
		{
			int notYellow=5-yellow;
			double notYellowChance=notYellow/5.0;
			int combination=calculateCombination(deckSize, notYellow);
			double cureChance=combination*(Math.pow(yellowCureChance, notYellow))*(Math.pow(notYellowChance,(deckSize-notYellow)));
			yellowCureChance=cureChance;
		}
		if(greyCureChance<1.0) 
		{
			int notGrey=5-grey;
			double notGreyChance=notGrey/5.0;
			int combination=calculateCombination(deckSize, notGrey);
			double cureChance=combination*(Math.pow(greyCureChance, notGrey))*(Math.pow(notGreyChance,(deckSize-notGrey)));
			greyCureChance=cureChance;
			
		}
		if(redCureChance<1.0) 
		{
			int notRed=5-red;
			double notRedChance=notRed/5.0;
			int combination=calculateCombination(deckSize, notRed);
			double cureChance=combination*(Math.pow(redCureChance, notRed))*(Math.pow(notRedChance,(deckSize-notRed)));
			redCureChance=cureChance;
		}
		
		double ForecastedProbability[]= {blueCureChance,yellowCureChance,greyCureChance,redCureChance};
		allPlayers[playerIndex].CURE_FORECASTED_PROBABILITY= ForecastedProbability;
	}
	
	/*The function below is used to rank the colors most likely to appear from the player deck based on the player color*/
	private void rankColorChance() 
	{
		
		double regions[]= {BLUE_PLAYER_CARD_CHANCE,YELLOW_PLAYER_CARD_CHANCE,GREY_PLAYER_CARD_CHANCE,RED_PLAYER_CARD_CHANCE};
		int regionIndexes[]= {1,2,3,4};
		for(int x=0;x<regions.length;x++) 
		{
			
			for(int y=0;y<regions.length;y++) 
			{				
				if(regions[x]<regions[y]) 
				{
					int temp=regionIndexes[x];
					double tempHighest = regions[x];
					regionIndexes[x]=regionIndexes[y];
					regions[x]=regions[y];
					regionIndexes[y]=temp;
					regions[y]=tempHighest;
					
				}	
			}
		}
		CITY_COLORS_CHANCE=Arrays.copyOf(regionIndexes, regionIndexes.length);
		
	}
	
	
	/*The function below is used to evaluate whether or not a player should treat a given city.
	 * The output is based on the likelihood of the city and its neighbors causing a chain outbreak*/
	private int[][] evaluateTreating(int playerIndex) 
	{
		updateAllRankings();
		String ranked[]=evaluateMoves(playerIndex);
		String highestRanked=ranked[ranked.length-1];
		String cityDetails[]=highestRanked.split(",");
		int chartterFlight=evaluateCharterFlight(playerIndex);
		int cityIndex = Integer.parseInt(cityDetails[0]);
		String action="DRIVE";
		String transportMode = cityDetails[1];
		if(transportMode.indexOf("f")==0) 
		{
			action="FLY";
		}
		if(chartterFlight!=0) 
		{
			action="CHATTER FLIGHT";
		}
		int mostLikely=(int)REGION_MATRIX[2][cityIndex];
		if(allPlayers[playerIndex].CURRENT_CITY==mostLikely) 
		{
			System.out.println("");
			System.out.println("");
			System.out.println("___________________________");
			System.out.println("");
			System.out.println("AI SUGGESTION: TREAT THIS CITY");
			System.out.println("");
			System.out.println("___________________________");
			System.out.println("");
			System.out.println("");
			int treatingOne[][]= {{3},{1},{mostLikely}};
			return treatingOne;
		}
		if(allPlayers[playerIndex].CURRENT_CITY!=mostLikely) 
		{
			int cityArray[]= {cityIndex,mostLikely};
			String cityName[]= setBoard.getCityNames(cityArray);
			String details[]= cityName[0].split(",");
			String detailsTwo[]= cityName[1].split(",");
			String city= details[0].toUpperCase();
			String treat=detailsTwo[0].toUpperCase();
			System.out.println("");
			System.out.println("");
			System.out.println("___________________________");
			System.out.println("");
			System.out.println("AI SUGGESTION: "+action+" to "+city+" THEN MOVE NEIGHBOURING CITY "+treat+" AND TREAT IT.");
			System.out.println("");
			System.out.println("___________________________");
			System.out.println("");
			System.out.println("");
			
			if(chartterFlight==0) 
			{
				int treatingTwo[][]= {{3},{2},cityArray};
				return treatingTwo;
			}
			if(chartterFlight!=0) 
			{
				int treatingThree[][]= {{3},{3},{chartterFlight}};
				return treatingThree;
			}
			
		}
		int defaultPath[][]= {};
		return defaultPath;
		
	}
	
	/*Evaluate moves is used to evaluate whether it's better for a user to drive to a certain city or fly to a certain city.*/
	private String[] evaluateMoves(int playerIndex) 
	{
		updateAllRankings();
		int playerCity=allPlayers[playerIndex].CURRENT_CITY;
		int neighbouringCities[]= setBoard.getNeighboursIndex(playerCity);
		int flights[]= evaluateFlight(playerIndex);
		
		int nextStart=0;
		ArrayList<Integer> driveMoves=new ArrayList<Integer>();
		ArrayList<Integer> flightMoves=new ArrayList<Integer>();
		driveMoves.add(playerCity);
		for(int i=0;i<neighbouringCities.length;i++) 
		{
			driveMoves.add(neighbouringCities[i]);
		}
		for(int i=0;i<flights.length;i++) 
		{
			if(driveMoves.indexOf(flights[i])==-1) 
			{
				flightMoves.add(flights[i]);
			}
		}
		String allMovesClassified[]=new String[driveMoves.size()+flightMoves.size()];
		int allMoves[]=new int[driveMoves.size()+flightMoves.size()];
		for(int i=0;i<driveMoves.size();i++) 
		{
			
			allMoves[nextStart]=driveMoves.get(i);
			nextStart++;
		}
		for(int i=0;i<flightMoves.size();i++) 
		{
			
			allMoves[nextStart]=flightMoves.get(i);
			nextStart++;
		}
		
		int sorted[]=sortIndividualColorCards(allMoves);
		for(int i=0;i<sorted.length;i++) 
		{
			allMovesClassified[i]=sorted[i]+","+"d";
			if(driveMoves.indexOf(sorted[i])==-1) 
			{
				allMovesClassified[i]=sorted[i]+","+"f";
			}
		}
		return allMovesClassified;
	}
	
	/*The function below is used to find the cards that are least likely to get a cure*/
	private int[] LessLikelyCards(int playerIndex) 
	{
		int playerCards[]=allPlayers[playerIndex].PLAYER_CARDS;
		int leastLikely=CITY_COLORS_CHANCE[0];
		
		ArrayList<Integer> cardsSelected= new ArrayList<Integer>();
		for(int i=0;i<playerCards.length;i++) 
		{
			int cardColor = setBoard.colorGroup(playerCards[i]);
			if(cardColor==leastLikely) 
			{
				cardsSelected.add(playerCards[i]);
			}
		}
		
		int chardsSelected[]=new int [cardsSelected.size()];
		for(int i=0;i<cardsSelected.size();i++) 
		{
			chardsSelected[i]=cardsSelected.get(i);
		}
		
		return chardsSelected;
	}
	
	/*The function below is used to check if it is best for a user to charter a flight from a given city.
	 * It does this by seeing if the color of the city is the least likely to get a cure*/
	private int evaluateCharterFlight(int playerIndex) 
	{
		int charterCards[]=LessLikelyCards(playerIndex);
		for(int i=0;i<charterCards.length;i++) 
		{
			if(charterCards[i]==allPlayers[playerIndex].CURRENT_CITY) 
			{
				return charterCards[i];
			}
		}
		
		return 0;
	}
	
	/*The function below is gets the players cards and returns the best city to fly to.
	 * This is based of of which of the players cards is most likely to contribute to an outbreak*/
	private int[] evaluateFlightdistance(int playerIndex) 
	{
		int flights[]= evaluateFlight(playerIndex);
		int flightsDistance[]=new int[flights.length];
		int nextPlayerIndex=0;
		if(playerIndex==0) 
		{
			nextPlayerIndex=1;
		}
		for(int i=0;i<flights.length;i++) 
		{
			int distance=distanceFinder(flights[i],allPlayers[nextPlayerIndex].CURRENT_CITY).length;
			flightsDistance[i]=distance;
		}
		int smallestDistance=flightsDistance[0];
		int smallestIndex=0;
		for(int i=0;i<flights.length;i++) 
		{
			if(smallestDistance>flightsDistance[i]) 
			{
				smallestDistance=flightsDistance[i];
				smallestIndex=i;
			}
		}
		int suggestedFlight=flights[smallestIndex];
		int distance[]= {suggestedFlight,flightsDistance[smallestIndex]};
		return distance;
		
	}
	
	/*The function below is used to get the city with the shortest distance from one of the stations*/
	private int[] evaluateStationFlight(int playerIndex) 
	{
		int flights[]= evaluateFlight(playerIndex);
		int flightsDistance[]=new int[flights.length];
		int stations[]= setBoard.getResearchStations();
		ArrayList<Integer> check= new ArrayList<Integer>();
		ArrayList<Integer> checkt= new ArrayList<Integer>();
		int smallestDistance=Integer.MAX_VALUE;
		int smallestIndex=0;
		int stationNumber=0;
		for(int x=0;x<stations.length;x++) 
		{
			for(int y=0;y<flights.length;y++) 
			{
				int distance=distanceFinder(flights[y],stations[x]).length;
				
				check.add(distance);
				checkt.add(flights[y]);
				if(distance<smallestDistance) 
				{
					smallestDistance=distance;
					smallestIndex=y;
					stationNumber=stations[x];
				}
			}
		}
		int distance[]= {flights[smallestIndex],flightsDistance[smallestIndex],stationNumber};
		return distance;
	}
	
	/*The function below is used to find the shortest route that a player would take if they were to drive to a certain city*/
	private int[] evaluateStationDrive(int playerIndex) 
	{
		
		int players_city=allPlayers[playerIndex].CURRENT_CITY;
		int stations[]= setBoard.getResearchStations();
		ArrayList<Integer> check= new ArrayList<Integer>();
		int smallestDistance=Integer.MAX_VALUE;
		int stationNumber=0;
		int suggestedMove=0;
		for(int x=0;x<stations.length;x++) 
		{
			if(stations[x]!=players_city)
			{
				int route[]=distanceFinder(players_city,stations[x]);
				if(route.length!=0)
				{
					int distance=route.length;
					
					check.add(distance);
					if(distance<smallestDistance) 
					{
						suggestedMove=route[0];
						smallestDistance=distance;
						stationNumber=stations[x];
					}
				}
			}
			
			
		}
		int distance[]= {suggestedMove,smallestDistance,stationNumber};
		return distance;
	}
	
	/*The function below is used to evaluate if it is best to build a station in a given city.
	 * This is based on if the city makes it has the smallest distance from all cities in that region*/
	private int[] evaluateBuildStation(int cities[]) 
	{
		int region[]=Arrays.copyOf(cities, cities.length);
		int cityDistances[]= new int[12];
		for(int x=0;x<region.length;x++) 
		{
			int largestDistance=-1;
			for(int y=0;y<region.length;y++) 
			{
				int movements[]=distanceFinder(region[x], region[y]);
				int currentDistance=movements.length;
				if(currentDistance>largestDistance) 
				{
					largestDistance=currentDistance;
				}
			}
			cityDistances[x]=largestDistance;
		}
		for(int x=0;x<cityDistances.length;x++) 
		{
			for(int y=0;y<cityDistances.length;y++) 
			{
				if(cityDistances[x]<cityDistances[y]) 
				{
					
					int tempDistance = cityDistances[x];
					int tempIndex = region[x];
					cityDistances[x]=cityDistances[y];
					region[x]=region[y];
					cityDistances[y]=tempDistance;
					region[y]=tempIndex;
				}
			}
		}
		return region;
		
		
	}
	
	/*The function build station guide ranks the most optimal places to build a research station for each color.
	 * It ranks them based on the city withe the shortest largest distance.*/
	private void BuildStationGuide()
	{
		
		int blueRanks[]=evaluateBuildStation(BLUE_REGIONS);
		for(int i=0;i<blueRanks.length;i++) 
		{
			BLUE_REGION_STATION_RANKS.add(blueRanks[i]);	
		}
		
		int yellowRanks[]=evaluateBuildStation(YELLOW_REGIONS);
		for(int i=0;i<yellowRanks.length;i++) 
		{
			YELLOW_REGION_STATION_RANKS.add(yellowRanks[i]);
		}
		
		int greyRanks[]=evaluateBuildStation(GREY_REGIONS);
		for(int i=0;i<greyRanks.length;i++) 
		{
			GREY_REGION_STATION_RANKS.add(greyRanks[i]);
		}
		
		int redRanks[]=evaluateBuildStation(RED_REGIONS);
		for(int i=0;i<redRanks.length;i++) 
		{
			RED_REGION_STATION_RANKS.add(redRanks[i]);
		}
		updateStationRanks();
	}
	
	/*the function below updates the station rankings after a card is discarded*/
	private void updateStationRanks() 
	{
		ArrayList<Integer> discarded=cards.getDISCARDED_CARDS();
		
		for(int i=0;i<BLUE_REGION_STATION_RANKS.size();i++) 
		{
			int value=BLUE_REGION_STATION_RANKS.get(i);
			if(discarded.indexOf(Integer.valueOf(value))!=-1) 
			{
				BLUE_REGION_STATION_RANKS.remove(Integer.valueOf(value));
			}
		}
		
		for(int i=0;i<YELLOW_REGION_STATION_RANKS.size();i++) 
		{
			int value=YELLOW_REGION_STATION_RANKS.get(i);
			if(discarded.indexOf(Integer.valueOf(value))!=-1) 
			{
				YELLOW_REGION_STATION_RANKS.remove(Integer.valueOf(value));
			}
		}
		
		for(int i=0;i<GREY_REGION_STATION_RANKS.size();i++) 
		{
			int value=GREY_REGION_STATION_RANKS.get(i);
			if(discarded.indexOf(Integer.valueOf(value))!=-1) 
			{
				GREY_REGION_STATION_RANKS.remove(Integer.valueOf(value));
			}
		}
		
		for(int i=0;i<RED_REGION_STATION_RANKS.size();i++) 
		{
			int value=RED_REGION_STATION_RANKS.get(i);
			if(discarded.indexOf(Integer.valueOf(value))!=-1) 
			{
				RED_REGION_STATION_RANKS.remove(Integer.valueOf(value));
			}
		}
	}
	
	/*The function below is used to evaluate if a player can get a cure*/
	private int curePossible(int playerIndex) 
	{
		int blue=0;
		int yellow=0;
		int grey=0;
		int red=0;
		int CURE_MARKER[]=setBoard.getCURE_MARKER();
		int cards[]= allPlayers[playerIndex].PLAYER_CARDS;
		for(int i=0;i<cards.length;i++) 
		{
			int colorindex= setBoard.colorGroup(cards[i]);
			if(colorindex==1) 
			{
				blue++;
			}
			if(colorindex==2) 
			{
				yellow++;
			}
			if(colorindex==3) 
			{
				grey++;
			}
			if(colorindex==4) 
			{
				red++;
			}
		
		}
		if(blue>=5 && CURE_MARKER[0]==0) 
		{
			return 1;
		}
		if(yellow>=5 && CURE_MARKER[1]==0) 
		{
			return 2;
		}
		if(grey>=5 && CURE_MARKER[2]==0) 
		{
			return 3;
		}
		if(red>=5 && CURE_MARKER[3]==0) 
		{
			return 4;
		}
		return 0;
	}
	
	/*The function below checks if it is best for a user to build a station in a given city*/
	private int buildStationSuggestion(int playerIndex) 
	{
		int playerCards[]= allPlayers[playerIndex].PLAYER_CARDS;
		int stations[]=setBoard.getResearchStations();
		ArrayList<Integer> stationColors = new ArrayList<Integer>();
		for(int i=0;i<stations.length;i++) 
		{
			int colorStation= setBoard.colorGroup(stations[i]);
			stationColors.add(colorStation);
		}
		if(stations.length<=4) 
		{
			for(int i=0;i<playerCards.length;i++) 
			{
				int colorindex= setBoard.colorGroup(playerCards[i]);
				if(stationColors.indexOf(Integer.valueOf(colorindex))==-1)
				{
					if(colorindex==1) 
					{
						int currentCard=BLUE_REGION_STATION_RANKS.get(0);
						if(currentCard==playerCards[i]) 
						{
							return playerCards[i];
						}
					}
					if(colorindex==2) 
					{
						int currentCard=YELLOW_REGION_STATION_RANKS.get(0);
						if(currentCard==playerCards[i]) 
						{
							return playerCards[i];
						}
					}
					if(colorindex==3) 
					{
						int currentCard=GREY_REGION_STATION_RANKS.get(0);
						if(currentCard==playerCards[i]) 
						{
							return playerCards[i];
						}
					}
					if(colorindex==4) 
					{
						int currentCard=RED_REGION_STATION_RANKS.get(0);
						if(currentCard==playerCards[i]) 
						{
							return playerCards[i];
						}
					}
				}
			}
		}
		return 0;
	}
	
	/*The function below is used to have a conversation with the user. The function gets the best action to take and suggests is to the user*/
	public int[][] evaluateDescisions(int playerIndex) 
	{
		int cureHit=0;
		int shareHit=0;
		int stationHit=0;
		int cureAvailable=curePossible(playerIndex);
		int buildingStation=buildStationSuggestion(playerIndex);
		
		checkPlayerCards(playerIndex);
		if(EXCESS_CARDS==true) 
		{
			int[]suggestion=discardSuggestion(playerIndex);
			int discardDetails[][]= {{4},suggestion};
			return discardDetails;
		}
		else {
			if(cureAvailable!=0) 
			{
				cureHit=1;
				return getCure(playerIndex);
				
			}
			if(cureHit==0)
			{
				int shareCure[][]= cureByShare(playerIndex);
				if(shareCure.length!=0) 
				{
					if(shareCure[1][0]!=0) 
					{
						shareHit=1;
						return shareCure;
					}
				}
			}
			
			if(buildingStation!=0) 
			{
				if(allPlayers[playerIndex].CURRENT_CITY==buildingStation)
				{
					int stationDetails[][]= {{5}};
					stationHit=1;
					int city[]= {buildingStation};
					String cityDetails[]= setBoard.getCityNames(city)[0].split(",");
					String cityName=cityDetails[0].toUpperCase();
					System.out.println();
					System.out.println("____________________________");
					System.out.println();
					System.out.println("AI SUGGESTION: BUILD A RESEARCH STATION AT: "+cityName);
					System.out.println();
					System.out.println("____________________________");
					System.out.println();
					return stationDetails;
				}
			}
			if(cureHit==0 && shareHit==0 && stationHit==0 ) 
			{
				
				return evaluateTreating(playerIndex);
			}
		}
		
		int defaultDecision[][] = {};
		return defaultDecision;
		
	}
	
	/*The function below is used to evaluate whether or not it's best for a player to cure a disease.
	 * If a player is in the same city as a station it suggests that the player cures a disease 
	 * if a player is not in a city with a research station is suggest the best way to travel to a station*/
	private int[][] getCure(int playerIndex) 
	{
		int driving[]=evaluateStationDrive(playerIndex);
		int flying[]=this.evaluateStationFlight(playerIndex);
		int chartterFlight=evaluateCharterFlight(playerIndex);
		int stations[]=setBoard.getResearchStations();
		int nextPlayerIndex=0;
		if(playerIndex==0) 
		{
			nextPlayerIndex=1;
		}
		ArrayList<Integer> stationsIndexes=new ArrayList<Integer>();
		for(int i=0;i<stations.length;i++) 
		{
			stationsIndexes.add(stations[i]);
		}
		String movementMethod="DRIVE";
		int nextMove=driving[0];
		if(driving[1]>flying[1]) 
		{
			
			nextMove=flying[0];
			movementMethod="FLY ";
		}
		if(chartterFlight!=0) 
		{
			movementMethod="CHATTER FLIGHT ";
		}
		
		
		int neighbours[]=setBoard.getNeighboursIndex(allPlayers[playerIndex].CURRENT_CITY);
		int sameCity=0;
		if(stationsIndexes.indexOf(Integer.valueOf(allPlayers[playerIndex].CURRENT_CITY))!=-1) 
		{
			System.out.println("___________________________");
			System.out.println("");
			System.out.println("AI SUGGESTION: CURE DISEASE");
			System.out.println("");
			System.out.println("___________________________");
			sameCity=1;
			int cureOne[][]={{1},{1}};
			return cureOne;
		}
		int distanceChecker=0;
		if(sameCity==0)
		{
			for(int i=0;i<neighbours.length;i++) 
			{
				if(stationsIndexes.indexOf(Integer.valueOf(neighbours[i]))!=-1) 
				{
					movementMethod="DRIVE";
					int neighbourArray[]= {neighbours[i]};
					String cityName[]= setBoard.getCityNames(neighbourArray);
					String cityDetails[]= cityName[0].split(",");
					String city[]= cityDetails[0].split(" ");
					System.out.println("___________________________");
					System.out.println("");
					System.out.println("|AI SUGGESTION:"+movementMethod+" TO "+city[2].toUpperCase()+" TO MOVE CLOSER TO STATION IN ORDER TO CURE DISEASE|");
					System.out.println("");
					System.out.println("___________________________");
					distanceChecker=1;
					int cureTwo[][]={{1},{2},{neighbours[i]}};
					return cureTwo;
					
				}
			}
		
			if(distanceChecker==0)
			{
				int choosenArray[]= {nextMove};
				String cityName[]= setBoard.getCityNames(choosenArray);
				String cityDetails[]= cityName[0].split(",");
				String city[]= cityDetails[0].split(" ");
				
				System.out.println("_______________________");
				System.out.println("				 ");
				System.out.println("|AI SUGGESTION:"+movementMethod+" TO "+city[2].toUpperCase()+" TO MOVE CLOSER TO STATION IN ORDER TO CURE DISEASE");
				System.out.println("");
				System.out.println("___________________________");
				if(chartterFlight==0) 
				{
					int cureThree[][]={{1},{3},choosenArray};
					return cureThree;
				}
				if(chartterFlight!=0) 
				{
					int nextCity[]= {allPlayers[nextPlayerIndex].CURRENT_CITY};
					int cureThree[][]={{1},{4},nextCity};
					return cureThree;
				}
			}
		}
		int defaultCure[][]= {};
		return defaultCure;
		
	}
	
	/*The function below uses the Monte Carlo Algorithmn to find distances between two cities.*/
	private int[] distanceFinder(int start,int end) 
	{
		MonteCarloAlgoritm monteCarlo = new MonteCarloAlgoritm();
		Node startNode=new Node(start,0, null);
		Node initializeNode[]= {startNode};
		int directions[] =monteCarlo.getDirections(initializeNode,end);
		return directions;
	}
	
	/*The function below is used to get the best city to fly to from the players cards*/
	private int[] evaluateFlight(int playerIndex) 
	{
		int cards[]=Arrays.copyOf(allPlayers[playerIndex].PLAYER_CARDS,allPlayers[playerIndex].PLAYER_CARDS.length);
		updateAllRankings();
		int lowestChance = CITY_COLORS_CHANCE[0];
		ArrayList<Integer> lowestCities = new ArrayList<Integer>();
		for(int i=0;i<cards.length;i++) 
		{
			int currentColor = setBoard.colorGroup(cards[i]);
			if(currentColor==lowestChance) 
			{
				lowestCities.add(cards[i]);
			}
		}
		int cities[]=new int [lowestCities.size()];
		for(int i=0;i<lowestCities.size();i++) 
		{
			cities[i]=lowestCities.get(i);
		}
		
		return cities;
	}
	
	/*The function below suggests the cards that a player should discard when the player has excess cards.
	 * It is based on the chance of a cards getting a cure*/
	private int[] discardSuggestion(int playerIndex) 
	{
		int cards[]=Arrays.copyOf(allPlayers[playerIndex].PLAYER_CARDS,allPlayers[playerIndex].PLAYER_CARDS.length);
		double cardsProbabilities[]= new double[cards.length];
		ArrayList<Integer> bluesAvailable=new ArrayList<Integer>();
		ArrayList<Integer> yellowAvailable=new ArrayList<Integer>();
		ArrayList<Integer> greyAvailable=new ArrayList<Integer>();
		ArrayList<Integer> redAvailable=new ArrayList<Integer>();
		
		for(int i=0;i<cardsProbabilities.length;i++) 
		{
			cardsProbabilities[i]=playerCardColor(cards[i]);
			if(setBoard.colorGroup(cards[i])==1) 
			{
				bluesAvailable.add(cards[i]);
			}
			if(setBoard.colorGroup(cards[i])==2) 
			{
				yellowAvailable.add(cards[i]);
			}
			if(setBoard.colorGroup(cards[i])==3) 
			{
				greyAvailable.add(cards[i]);
			}
			if(setBoard.colorGroup(cards[i])==4) 
			{
				redAvailable.add(cards[i]);
			}
		}
		int blueCards[]=new int[bluesAvailable.size()];
		int redCards[]=new int[redAvailable.size()];
		int yellowCards[]=new int[yellowAvailable.size()];
		int greyCards[]=new int[greyAvailable.size()];
		for(int i=0;i<bluesAvailable.size();i++) 
		{
			blueCards[i]=bluesAvailable.get(i);
		}
		for(int i=0;i<yellowAvailable.size();i++) 
		{
			yellowCards[i]=yellowAvailable.get(i);
		}
		for(int i=0;i<greyAvailable.size();i++) 
		{
			greyCards[i]=greyAvailable.get(i);
		}
		for(int i=0;i<redAvailable.size();i++) 
		{
			redCards[i]=redAvailable.get(i);
		}
		blueCards=Arrays.copyOf(sortIndividualColorCards(Arrays.copyOf(blueCards, blueCards.length)),blueCards.length);
		yellowCards=Arrays.copyOf(sortIndividualColorCards(Arrays.copyOf(yellowCards, yellowCards.length)),yellowCards.length);
		greyCards=Arrays.copyOf(sortIndividualColorCards(Arrays.copyOf(greyCards, greyCards.length)),greyCards.length);
		redCards=Arrays.copyOf(sortIndividualColorCards(Arrays.copyOf(redCards, redCards.length)),redCards.length);
		
		
		ArrayList<Integer> tempCards=new ArrayList<Integer>(cards.length);
		for(int i=0;i<CITY_COLORS_CHANCE.length;i++) 
		{
			if(CITY_COLORS_CHANCE[i]==1) 
			{
				for(int j=0;j<blueCards.length;j++)
				{
					tempCards.add(blueCards[j]);
				}
				
			}
			if(CITY_COLORS_CHANCE[i]==2) 
			{
				for(int j=0;j<yellowCards.length;j++)
				{
					tempCards.add(yellowCards[j]);
				}
				
			}
			if(CITY_COLORS_CHANCE[i]==3) 
			{
				for(int j=0;j<greyCards.length;j++)
				{
					tempCards.add(greyCards[j]);
				}
				
			}
			if(CITY_COLORS_CHANCE[i]==4) 
			{
				for(int j=0;j<redCards.length;j++)
				{
					tempCards.add(redCards[j]);
				}
				
			}
		}
		for(int i=0;i<tempCards.size();i++) 
		{
			cards[i]=tempCards.get(i);
		}
		return cards;
		
	}
	
	/*The function below sorts cars of a given color based on the cards chance of getting a chain outbreak*/
	private int[] sortIndividualColorCards(int cards[]) 
	{
		updateAllRankings();
		for(int x=0;x<cards.length;x++) 
		{
			if(REGIONAL_RANKINGS.indexOf(Integer.valueOf(cards[x]))==-1) 
			{
				int temp[]=new int[cards.length-1];
				int cardsDuplicate[]= Arrays.copyOf(cards, cards.length);
				int tempIndex=0;
				for(int i=0;i<cardsDuplicate.length;i++) 
				{
					if(i!=x) 
					{
						temp[tempIndex]=cardsDuplicate[i];
						tempIndex++;
					}
				}
				
				cards[0]=cards[x];
				for(int i=1;i<cards.length;i++) 
				{
					cards[i]=temp[i-1];
				}
			}
			if(REGIONAL_RANKINGS.indexOf(Integer.valueOf(cards[x]))!=-1){
				for(int y=0;y<cards.length;y++) 
				{
					if(REGIONAL_RANKINGS.indexOf(Integer.valueOf(cards[x]))>REGIONAL_RANKINGS.indexOf(Integer.valueOf(cards[y]))&&REGIONAL_RANKINGS.indexOf(Integer.valueOf(cards[y]))!=-1) 
					{
						int tempHighest = cards[x];
						cards[x]=cards[y];
						cards[y]=tempHighest;
					}
				}
			}
			
		}
		return cards;
	}
	
	/*The function below is used to check if a player has excess cards*/
	private void checkPlayerCards(int playerIndex) 
	{
		if(allPlayers[playerIndex].PLAYER_CARDS.length>7) 
		{
			EXCESS_CARDS=true;
		}
	}
	
	/*The function below is used to discard players cards when a player has excess cards*/
	public void discardPlayerCard(int playerIndex) 
	{	
		while(allPlayers[playerIndex].PLAYER_CARDS.length>7)
		{
			updateAllRankings();
			int discardRankings[]=this.discardSuggestion(playerIndex);
			int toCity[]= {discardRankings[0]};
			String returnedName[]=setBoard.getCityNames(toCity);
			String suggestedName=returnedName[0];
			int playerCards[]=allPlayers[playerIndex].PLAYER_CARDS;
			String currentPlayerCards[]=setBoard.getCityNames(playerCards);
			System.out.println("_____________________________________");
			System.out.println();
			System.out.println("TO MANY CARDS PICK CARD TO REMOVE: ");
			System.out.println();
			System.out.println("_____________________________________");
			System.out.println();
			String suggestedData[] = suggestedName.split(",");
			System.out.println("|  AI SUGGESTION: REMOVE PLAYER CARD WITH CITY NAMED "+suggestedData[0].toUpperCase());
			System.out.println();
			System.out.println("_____________________________________");
			System.out.println();
			System.out.println();
			viewPlayerCards(playerIndex);
			System.out.println("_____________________________________");
			System.out.println();
			System.out.println("ENTER ONE OF THE CITY INDEX NUMBERS TO THE RIGHT OF EACH NUMBER: ");
			System.out.println();
			System.out.println("_____________________________________");
			System.out.println();
			for(int i=0;i<currentPlayerCards.length;i++) 
			{
				String cityData[] = currentPlayerCards[i].split(",");
			}
			Scanner userInput= new Scanner(System.in);
			int userSelection =userInput.nextInt();
			
			
			if(userSelection>-1) 
			{
				System.out.println();
				
				int cityCardIndex=-1;
				//Getting card index from player cards
				for(int i=0;i<playerCards.length;i++) 
				{
					if(playerCards[i]==userSelection) 
					{
						cityCardIndex=i;
					}
				}
				//Removing cards from player and storing cards in discard deck
				allPlayers[playerIndex].discardCity(cityCardIndex,currentPlayerCards.length-1);
				cards.discardCity(allPlayers[playerIndex].PLAYER_CARDS[cityCardIndex]);
				discardRegionCard(allPlayers[playerIndex].PLAYER_CARDS[cityCardIndex]);
				
			}
			else {
				System.out.println("Invalid input");
			}
		}
		EXCESS_CARDS=false;
		System.out.println();
	}
	
	/*This function below discardRegionCard() named is used to update the ranks of the most optimal city to build
	 * a research station for each color. It finds the color of the research station then removes it from the rankings
	 * */
	private void discardRegionCard(int cardNumber) 
	{
		int colorIndex=setBoard.colorGroup(cardNumber);
		if(colorIndex==1) 
		{
			BLUE_REGION_STATION_RANKS.remove(Integer.valueOf(cardNumber));
		}
		if(colorIndex==2) 
		{
			YELLOW_REGION_STATION_RANKS.remove(Integer.valueOf(cardNumber));
		}
		if(colorIndex==3) 
		{
			GREY_REGION_STATION_RANKS.remove(Integer.valueOf(cardNumber));
		}
		if(colorIndex==4) 
		{
			RED_REGION_STATION_RANKS.remove(Integer.valueOf(cardNumber));
		}
		
	}
	
	/*The function below returns the chance of a player card being drawn from the player deck.*/
	private double playerCardColor(int cardIndex) 
	{
		int colorIndex=setBoard.colorGroup(cardIndex);
		if(colorIndex==1) 
		{
			return BLUE_PLAYER_CARD_CHANCE;
		}
		if(colorIndex==2) 
		{
			return YELLOW_PLAYER_CARD_CHANCE;
		}
		if(colorIndex==3) 
		{
			return GREY_PLAYER_CARD_CHANCE;
		}
		if(colorIndex==4) 
		{
			return RED_PLAYER_CARD_CHANCE;
		}
		
		return -1.0;
	}
	
	/*The function gets the probability of each city causing an outbreak*/
	private void rankCities() 
	{
		setBoard.indexInfectionProbability(DIFFICULTY);
		for(int i=1;i<=48;i++) 
		{
			double outbreakProbability=setBoard.indexInfectionProbability(i);
			double overallProbability=0.0;
			if(i<=12) 
			{
				overallProbability=outbreakProbability*BLUE_CHANCE;
			}
			if(i>12 && i<=24) 
			{
				overallProbability=outbreakProbability*YELLOW_CHANCE;
			}
			if(i>24 && i<=36) 
			{
				overallProbability=outbreakProbability*GREY_CHANCE;
			}
			if(i>36) 
			{
				overallProbability=outbreakProbability*RED_CHANCE;
			}
			PROBABILITY_MATRIX[0][i]=i;
			RANKED_PROBABILITY_MATRIX[0][i]=i;
			PROBABILITY_MATRIX[1][i]=overallProbability;
			RANKED_PROBABILITY_MATRIX[1][i]=overallProbability;
		}
	}
	
	/*The function below is used to rank the cities most likely to get a chain outbreak*/
	private void sortProbabilityMatrix() 
	{
		for(int x=1;x<RANKED_PROBABILITY_MATRIX[0].length;x++) 
		{
			for(int y=1;y<RANKED_PROBABILITY_MATRIX[0].length;y++) 
			{
				if(RANKED_PROBABILITY_MATRIX[1][x]>RANKED_PROBABILITY_MATRIX[1][y]) 
				{
					
					double tempValue = RANKED_PROBABILITY_MATRIX[1][x];
					double tempLabel = RANKED_PROBABILITY_MATRIX[0][x];
					RANKED_PROBABILITY_MATRIX[1][x]=RANKED_PROBABILITY_MATRIX[1][y];
					RANKED_PROBABILITY_MATRIX[0][x]=RANKED_PROBABILITY_MATRIX[0][y];
					RANKED_PROBABILITY_MATRIX[1][y]=tempValue;
					RANKED_PROBABILITY_MATRIX[0][y]=tempLabel;
				}
			}
		}
	}
	
	/*The function below is used to rank the regions most likely to get a chain outbreak */
	private void sortRegionsMatrix() 
	{
		for(int x=1;x<RANKED_REGION_MATRIX[0].length;x++) 
		{
			for(int y=1;y<RANKED_REGION_MATRIX[0].length;y++) 
			{
				if(RANKED_REGION_MATRIX[1][x]>RANKED_REGION_MATRIX[1][y]) 
				{
					double tempHighest = RANKED_REGION_MATRIX[2][x];
					double tempValue = RANKED_REGION_MATRIX[1][x];
					double tempLabel = RANKED_REGION_MATRIX[0][x];
					RANKED_REGION_MATRIX[2][x]=RANKED_REGION_MATRIX[2][y];
					RANKED_REGION_MATRIX[1][x]=RANKED_REGION_MATRIX[1][y];
					RANKED_REGION_MATRIX[0][x]=RANKED_REGION_MATRIX[0][y];
					RANKED_REGION_MATRIX[2][y]=tempHighest;
					RANKED_REGION_MATRIX[1][y]=tempValue;
					RANKED_REGION_MATRIX[0][y]=tempLabel;
				}
			}
		}
	}
	
	/*The function below is used to see if a player does not have excess cards*/
	public void checkDiscard(int playerIndex) 
	{
		int playerCards[]=allPlayers[playerIndex].PLAYER_CARDS;
		if(playerCards.length<7) 
		{
			EXCESS_CARDS=false;
		}
	}
	
	//Rank diseased cities
	private void updateRankings() 
	{
		INFECTED_CITY_RANKINGS.clear();
		for(int y=1;y<RANKED_PROBABILITY_MATRIX[0].length;y++) 
		{
			if(RANKED_PROBABILITY_MATRIX[1][y]==0.0) 
			{
				break;
			}
			int cityIndex = (int)RANKED_PROBABILITY_MATRIX[0][y];
			INFECTED_CITY_RANKINGS.add(cityIndex);
		}
	}
	
	/*The function below is used to list the region rankings*/
	private void updateRegionRanks() 
	{
		REGIONAL_RANKINGS.clear();
		for(int y=1;y<RANKED_REGION_MATRIX[0].length;y++) 
		{
			if(RANKED_REGION_MATRIX[1][y]==0.0) 
			{
				break;
			}
			int cityIndex = (int)RANKED_REGION_MATRIX[0][y];
			REGIONAL_RANKINGS.add(cityIndex);
		}
	}
	
	/*The function below is used is used to get the probability of each region getting a chain outbreak*/
	private void createRegionMatrix() 
	{
		for(int x=1;x<=48;x++) 
		{
			double outbreakProbability = PROBABILITY_MATRIX[1][x];
			int neighbours[]=setBoard.getNeighboursIndex(x);
			int mostLikelyCity= x;
			for(int y=0;y<neighbours.length;y++) 
			{
				int cityIndex = neighbours[y];
				outbreakProbability+=PROBABILITY_MATRIX[1][cityIndex];
				if(PROBABILITY_MATRIX[1][mostLikelyCity]<PROBABILITY_MATRIX[1][cityIndex]) 
				{
					mostLikelyCity=cityIndex;
				}
			}
			//RANKED_REGION_MATRIX
			REGION_MATRIX[0][x]=x;
			REGION_MATRIX[1][x]=outbreakProbability;
			REGION_MATRIX[2][x]=mostLikelyCity;
			RANKED_REGION_MATRIX[0][x]=x;
			RANKED_REGION_MATRIX[1][x]=outbreakProbability;
			RANKED_REGION_MATRIX[2][x]=mostLikelyCity;
		}
	}
	
	/*The function below is used to drive to a certain neighboring city*/
	public void drivePlayer(int playerIndex) 
	{
		int city=allPlayers[playerIndex].CURRENT_CITY;
		String getCities[]=setBoard.getNeighbours(city);
		allPlayers[playerIndex].drive(getCities);
		System.out.println("CURRENT CITY: "+allPlayers[playerIndex].CURRENT_CITY);
	}
	
	/*The function below is used to charter a flight from a city*/
	public void charterFlight(int playerIndex)
	{
		int matchFound= allPlayers[playerIndex].findMatchingCity();
		if(matchFound>-1) 
		{
			int findCity[] = {matchFound};
			String cityDetails[]=setBoard.getCityNames(findCity);
			int flightDetails=allPlayers[playerIndex].charterFlight(cityDetails[0]);
			if(flightDetails>0) 
			{
				cards.discardCity(flightDetails);
				discardRegionCard(flightDetails);
				setBoard.showCities();
				System.out.println();
				System.out.println("________________________");
				System.out.println();
				System.out.println("CHOOSE NEXT CITY: ");
				System.out.println();
				System.out.println("________________________");
				System.out.println();
				Scanner citySelection = new Scanner(System.in);
				int nextCity = citySelection.nextInt();
				if(nextCity<49 &&nextCity>0) 
				{
					allPlayers[playerIndex].CURRENT_CITY=nextCity;
				}
				else {
					System.out.println();
					System.out.println("________________________");
					System.out.println();
					System.out.println("INVALID INPUT!!!!");
					System.out.println();
					System.out.println("________________________");
					System.out.println();
				}
			}
		}
		else {
			System.out.println("No matching cities");
		}
	}
	
	/*The function below is used for the agent to charter a flight from a city*/
	public void botCharterTreat(int playerIndex)
	{
		cards.discardCity(allPlayers[playerIndex].CURRENT_CITY);
		discardRegionCard(allPlayers[playerIndex].CURRENT_CITY);
		int nextCity = INFECTED_CITY_RANKINGS.get(0);
		allPlayers[playerIndex].CURRENT_CITY=nextCity;
	}
	
	/*The function below is used for the agent to share a card */
	public void botCharterShare(int playerIndex)
	{
		int nextPlayerIndex=0;
		if(playerIndex==0) 
		{
			nextPlayerIndex=1;
		}
		cards.discardCity(allPlayers[playerIndex].CURRENT_CITY);
		discardRegionCard(allPlayers[playerIndex].CURRENT_CITY);
		int nextCity = allPlayers[nextPlayerIndex].CURRENT_CITY;
		allPlayers[playerIndex].CURRENT_CITY=nextCity;
	}
	
	/*The function below is for the agent to chater a flight and cure a disease.*/
	public void botCharterCure(int playerIndex)
	{
		int cureMarker[]= setBoard.getCURE_MARKER();
		cards.discardCity(allPlayers[playerIndex].CURRENT_CITY);
		discardRegionCard(allPlayers[playerIndex].CURRENT_CITY);
		int nextCity = cureMarker[0];
		allPlayers[playerIndex].CURRENT_CITY=nextCity;
	}
	
	
	/*The function below is used to shuttle a flight to another research station*/
	public void shuttleFlight(int playerIndex)
	{
		int stations[]=setBoard.getResearchStations();
		String stationsCities[]=setBoard.getCityNames(stations);
		allPlayers[playerIndex].shuttleFlight(stationsCities);
	}
	
	/*The function below is used to have a direct flight to a given city*/
	public void directFlight(int playerIndex)
	{
		String currentPlayerCards[]=setBoard.getCityNames(allPlayers[playerIndex].PLAYER_CARDS);
		allPlayers[playerIndex].directFlight(currentPlayerCards);
		cards.discardCity(allPlayers[playerIndex].CURRENT_CITY);
		discardRegionCard(allPlayers[playerIndex].CURRENT_CITY);
	}
	
	/*The function below is used share cards with other players*/
	public void shareKnowledge(int playerIndex)
	{
		int usersCitys[]= new int[NUMBER_OF_PLAYERS];
		for(int i=0;i<allPlayers.length;i++) 
		{
			usersCitys[i]=allPlayers[i].CURRENT_CITY;
			
		}
		int usersAround[]=allPlayers[playerIndex].usersPresent(usersCitys);
		
		if(usersAround.length!=0)
		{
			for(int user=0;user<usersAround.length;user++) 
			{
				int usersNumber= usersAround[user];
				int userCards[]=allPlayers[usersNumber].PLAYER_CARDS;
				String cardsCities[]=setBoard.getCityNames(userCards);
				int userTwoCity =allPlayers[playerIndex].shareKnowledge(cardsCities);
				int userTwoIndex=-1;
				for(int j=0;j<allPlayers[usersNumber].PLAYER_CARDS.length;j++) 
				{
					if(userTwoCity==allPlayers[usersNumber].PLAYER_CARDS[j]) 
					{
						userTwoIndex=j;
					}
				}
				allPlayers[usersNumber].discardCity(userTwoIndex, allPlayers[usersNumber].PLAYER_CARDS.length-1);
				cards.discardCity(userTwoCity);
				discardRegionCard(userTwoCity);
						
			}
		}
		else {
			System.out.println("No players Present");
		}
	}
	
	/*The function below is used for a the agent to cure a disease*/
	public void getCureCards(int playerIndex) 
	{
		int nextPlayerIndex=0;
		if(playerIndex==0) 
		{
			nextPlayerIndex=1;
		}
		int cureMarker[]= setBoard.getCURE_MARKER();
		int cardColor=-1;
		int nextPlayer[]=allPlayers[nextPlayerIndex].PLAYER_CARDS;
		for(int x=0;x<4;x++) 
		{
			double totalProbability=0;
			for(int y=0;y<allPlayers.length;y++) 
			{
				double currentProbability=allPlayers[y].CURRENT_CURE_PROBABILITY[x];
				totalProbability+=currentProbability;
			}
			if(totalProbability>=1.0 &&cureMarker[x]==0) 
			{
				cardColor=x+1;
			}
		}
		for(int i=0;i<nextPlayer.length;i++) 
		{
			int potentialMatch=setBoard.colorGroup(nextPlayer[i]);
			if(potentialMatch==cardColor) 
			{
				allPlayers[playerIndex].botShareKnowledge(nextPlayer[i]);
				allPlayers[nextPlayerIndex].discardCity(i, allPlayers[nextPlayerIndex].PLAYER_CARDS.length-1);
				cards.discardCity(nextPlayer[i]);
				discardRegionCard(nextPlayer[i]);
				break;
			}
		}
		
	}

	/*The function below is used for a player to treat a disease*/
	public void treatDisease(int playerIndex)
	{
		int diseaseData[]=setBoard.getDiseases(allPlayers[playerIndex].CURRENT_CITY);
		int validate=0;
		for(int i=1;i<diseaseData.length;i++) 
		{
			if(diseaseData[i]>0) 
			{
				validate=1;
			}
		}
		if(validate==1) 
		{
			int treatingData[]=allPlayers[playerIndex].treatDisease(diseaseData);
			setBoard.treatCity(treatingData);
		}
		if(validate!=1) 
		{
			System.out.println("No diseases");
		}
	}
	
	/*The function below is used for a bot to treat a disease */
	public void botTreatDisease(int playerIndex)
	{
		int cityColorGroup = setBoard.colorGroup(allPlayers[playerIndex].CURRENT_CITY);
		int treatingData[]= {allPlayers[playerIndex].CURRENT_CITY,cityColorGroup};
		setBoard.treatCity(treatingData);
	}
	
	/*The function below is used to build a research station*/
	public void buildResearchStation(int playerIndex)
	{
		int findMatch= allPlayers[playerIndex].findMatchingCity();
		if(findMatch>-1) 
		{
			int findCity[] = {findMatch};
			String cityDetails[]=setBoard.getCityNames(findCity);
			int flightDetails=allPlayers[playerIndex].buildStation(cityDetails[0]);
			if(flightDetails>0) 
			{
				setBoard.setResearchStation(findMatch); 
				cards.discardCity(findMatch);
				discardRegionCard(findMatch);
			}
		}
	}
	
	/*The function below is used for a bot to build a research station*/
	public void botBuildStation(int playerIndex)
	{
		int cityIndex=buildStationSuggestion(playerIndex);
		setBoard.setResearchStation(cityIndex); 
		cards.discardCity(cityIndex);
		discardRegionCard(cityIndex);
	}
	
	/*The function below is used to cure a disease*/
	public int cureDisease(int playerIndex)
	{
		int usersCards[]=allPlayers[playerIndex].PLAYER_CARDS;
		
		return setBoard.discoverCure(usersCards);
	}
	
	/*The function below is used for a agent to cure a disease*/
	public void botCureDisease(int playerIndex)
	{
		int diseaseColor= curePossible(playerIndex);
		setBoard.botDiscoverCure(diseaseColor);
	}
	
	/*The function below is used to distribute player cards*/
	public void getCards(int playerIndex) 
	{
		int cardsLength =2;
		int cardsHanded[]=cards.givePlayerCards(2);
		
		int checkOne=0;
		int checkTwo=0;
		if(cardsHanded[0]==-1) 
		{
			System.out.println("EPIDEMIC !!!");
			epidemic();
			cardsLength--;
			
		}
		
		if(cardsHanded[1]==-1) 
		{
			System.out.println("EPIDEMIC !!!");
			epidemic();
			cardsLength--;
		}
		if(cardsLength==2)
		{
			allPlayers[playerIndex].addCards(cardsHanded);
		}
		if(cardsLength==1) 
		{
			if(checkOne==0) 
			{
				int handCards[]= {cardsHanded[0]};
				allPlayers[playerIndex].addCards(handCards);
			}
			if(checkTwo==0) 
			{
				int handCards[]= {cardsHanded[1]};
				allPlayers[playerIndex].addCards(handCards);
			}
		}
	}
	
	/*The function below is used configure the player information when the game begins*/
	private void intitializePlayers()
	{
		String playerType="PLAYER";
		for(int i=1;i<=NUMBER_OF_PLAYERS;i++) 
		{
			if(i==1) 
			{
				playerType="BOT";
			}
			int playersCards[]=cards.initialDistribution();
			Player newPlayer = new Player(i,playersCards,playerType);
			allPlayers[i-1]=newPlayer;
			playerType="PLAYER";
		}
	}
	
	/*The function below is used to update all the different rankings*/
	public void updateAllRankings()
	{
		colorProbability();
		setBoard.probabilityOfInfection();
		rankCities();
		sortProbabilityMatrix();
		updateRankings();
		createRegionMatrix();
		sortRegionsMatrix();
		updateRegionRanks();
		playerCardProbability();
		rankColorChance();
		updateStationRanks();
	}
	
	/*The function below is used for a player to view their cards*/
	public void viewPlayerCards(int playerIndex) 
	{
		int playerCards[]=allPlayers[playerIndex].PLAYER_CARDS;
		String cities[]=setBoard.getCityNames(playerCards);
		System.out.println("Player "+allPlayers[playerIndex].PLAYER_NUMBER+" cards:");
		for(int i=0;i<cities.length;i++)
		{
			String cityData[] = cities[i].split(",");
			System.out.println(cityData[0]+" | CITY INDEX: "+cityData[1]);
		}
	}
	
	/*The function below is used for a player to view their current city*/
	public String viewCurrentCity(int playerIndex) 
	{
		int playerCity[]= {allPlayers[playerIndex].CURRENT_CITY};
		String city[]=setBoard.getCityNames(playerCity);
		String cityData[] = city[0].split(",");
		String cityName=cityData[0];
		
		return cityName;
	}	
	
	/*The function below is used to check if the game is over*/
	public int gameOver() 
	{
		int board = setBoard.gameOver();
		int deck = cards.gameOver();
		if(board==1 ||deck==1) 
		{
			System.out.println("BREAKING NEWS|:( GAME OVER  PANDEMIC OCCURED:(|");
			return 1;
		}
		return 0;
	}
	
	/*The function implements the combination formula*/
	private int calculateCombination(int n, int r) {
	    if (n < r) {
	        return 0;
	    }

	    int numerator = 1;
	    int denominator = 1;

	    for (int i = 1; i <= r; i++) {
	        numerator *= n - i + 1;
	        denominator *= i;
	    }

	    return numerator / denominator;
	}
}
