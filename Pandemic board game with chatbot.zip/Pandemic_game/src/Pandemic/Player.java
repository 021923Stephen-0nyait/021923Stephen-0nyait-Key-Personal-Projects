package Pandemic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

//Class containing player details
public class Player {
	public int CURRENT_CITY=1;
	public int PLAYER_NUMBER;
	public int PLAYER_CARDS[];
	public String PLAYER_TYPE;
	public double CURRENT_CURE_PROBABILITY[]={0,0,0,0};
	public double CURE_FORECASTED_PROBABILITY[]= {0,0,0,0};
	
	Player(int number,int cards[],String playerType)
	{
		this.PLAYER_NUMBER=number;
		this.PLAYER_CARDS = cards;
		this.PLAYER_TYPE=playerType;
	}
	
	/*The function below is used to dive to a neighboring city*/
	public void drive(String[] neighbours) 
	{
		System.out.println("Current city: "+CURRENT_CITY);
		System.out.println("Enter one of the numbers to select a city to drive to:");
		for(int i=0;i<neighbours.length;i++) 
		{
			String cityData[] = neighbours[i].split(",");
			System.out.println(i+": "+cityData[0]);
		}
		
		Scanner userInput= new Scanner(System.in);
		int userSelection =userInput.nextInt();
		System.out.println("Selected: "+userSelection);
		if(userSelection<neighbours.length && userSelection>-1) 
		{
			System.out.println();
			String cityData[] = neighbours[userSelection].split(",");
			int cityIndex = Integer.parseInt(cityData[1]);
			
			CURRENT_CITY=cityIndex;
			
			System.out.println("Moved to "+cityData[0]);
		}
		else {
			System.out.println("Invalid input");
		}
		
		System.out.println("Current city: "+CURRENT_CITY);
		
	}
	
	/*The function below is used to take a direct flight to a given city*/
	public void directFlight(String cities[]) 
	{
		for(int i=0;i<cities.length;i++) 
		{
			String cityData[] = cities[i].split(",");
			System.out.println(i+": "+cityData[0]);
			
		}
		Scanner userInput= new Scanner(System.in);
		int userSelection =userInput.nextInt();
		System.out.println("Selected: "+userSelection);
		if(userSelection<cities.length && userSelection>-1) 
		{
			System.out.println();
			String cityData[] = cities[userSelection].split(",");
			int cityIndex = Integer.parseInt(cityData[1]);
			
			CURRENT_CITY=cityIndex;
			discardCity(userSelection,cities.length-1);
			System.out.println("Moved to "+cityData[0]);
		}
		else {
			System.out.println("Invalid input");
		}
		
		System.out.println("Current city: "+CURRENT_CITY);
	}
	
	/*The function below is used to see if the user has a card that matches the city*/
	public int findMatchingCity() 
	{
		int matchingCity=-1;
		for(int i=0;i<PLAYER_CARDS.length;i++) 
		{
			if(PLAYER_CARDS[i]==CURRENT_CITY) 
			{
				System.out.println("Charter Flight to: ");
				matchingCity=PLAYER_CARDS[i];
				System.out.println("MATCH: "+matchingCity);
			}
		}
		return matchingCity;
	}
	
	/*The function below is used to charter a flight from a city*/
	public int charterFlight(String city) 
	{
		String cityData[]=city.split(",");
		System.out.println("Charter Flight from: "+cityData[0]);
		int cityIndex = Integer.parseInt(cityData[1]);
		System.out.println("0: Yes");
		System.out.println("1: No ");
		Scanner userInput = new Scanner(System.in);
		int userSelection = userInput.nextInt();
		if(userSelection>1 || userSelection<0) 
		{
			System.out.println("Invalid input");
		}
		else {
			if(userSelection==0) 
			{
				CURRENT_CITY=cityIndex;
				System.out.println("Now in "+ cityData[0]);
				for(int i=0;i<PLAYER_CARDS.length;i++) 
				{
					if(PLAYER_CARDS[i]==cityIndex) 
					{
						discardCity(i,PLAYER_CARDS.length-1);
						break;
					}
				}
				return cityIndex;
			}
			
			if(userSelection==1) 
			{
				System.out.println("Charter flight not taken");
				return 0;
			}
		}
		
		return 0;	
	}
	
	//The function below is used for a player to discard a given card.
	public void discardCity(int cityIndex,int newLength) 
	{
		int tempArray[]=new int[newLength];
		int tempIndex=0;
		for(int i=0;i<PLAYER_CARDS.length;i++) 
		{
			
			if(i!=cityIndex)
			{
				tempArray[tempIndex]=PLAYER_CARDS[i];
				tempIndex++;
			}
		}
		
		PLAYER_CARDS=tempArray;
		
	}
	
	//The function below is used to carry out the shuttleFlight action it 
	public void shuttleFlight(String cities[]) 
	{
		int verifyCity=0;
		for(int i=0;i<cities.length;i++) 
		{
			String cityData[] = cities[i].split(",");
		}
		Scanner userInput = new Scanner(System.in);
		int userSelection=userInput.nextInt();
		
		for(int i=0;i<cities.length;i++) 
		{
			String cityData[] = cities[i].split(",");
			if(CURRENT_CITY==Integer.parseInt(cityData[1])) 
			{
				verifyCity=1;
			}
		}
		
		if(userSelection<cities.length && userSelection>-1 &&verifyCity==1) 
		{
			String stationData[]= cities[userSelection].split(",");
			int cityIndex= Integer.parseInt(stationData[1]);
			CURRENT_CITY=cityIndex;
			System.out.println("At station in: "+stationData[0]);
		}
		else 
		{
			System.out.println("Not in a station");
		}
	}
	
	//The function below is used for a player to treat a disease
	public int[] treatDisease(int diseaesPresent[]) 
	{
		ArrayList<Integer> diseases= new ArrayList<Integer>();
		if(diseaesPresent[1]!=0)
		{
			System.out.println("1: BLUE| "+diseaesPresent[1]);
			diseases.add(1);
		}
		if(diseaesPresent[2]!=0)
		{
			System.out.println("2: YELLOW| "+diseaesPresent[2]);
			diseases.add(2);
		}
		if(diseaesPresent[3]!=0)
		{
			System.out.println("3: GREY| "+diseaesPresent[3]);
			diseases.add(3);
		}
		if(diseaesPresent[4]!=0) 
		{
			System.out.println("4: RED| "+diseaesPresent[4]);
			diseases.add(4);
		}
		Scanner userInput = new Scanner(System.in);
		int userSelection = userInput.nextInt();
		if(diseases.indexOf(Integer.valueOf(userSelection))>-1) 
		{
			int cityIndex=diseaesPresent[0];
			int cityToTreat[]= {cityIndex,userSelection};
			return cityToTreat;
		}
		else 
		{
			System.out.println("Invalid input");
		}
			
		int defaultData[]= {-2};
		return defaultData;
	}
	
	//The function below is used for a player to build a research station
	public int buildStation(String city) 
	{
		String cityData[]=city.split(",");
		System.out.println("Build station at: "+cityData[0]);
		int cityIndex = Integer.parseInt(cityData[1]);
		System.out.println("0: Yes");
		System.out.println("1: No ");
		Scanner userInput = new Scanner(System.in);
		int userSelection = userInput.nextInt();
		if(userSelection>1 || userSelection<0) 
		{
			System.out.println("Invalid input");
		}
		else {
			if(userSelection==0) 
			{
				
				System.out.println("Station built in: "+ cityData[0]);
				for(int i=0;i<PLAYER_CARDS.length;i++) 
				{
					if(PLAYER_CARDS[i]==cityIndex) 
					{
						discardCity(i,PLAYER_CARDS.length-1);
						break;
					}
				}
				return cityIndex;
			}
			
			if(userSelection==1) 
			{
				System.out.println("Station not built");
				return 0;
			}
		}
		return 0;
		
	}
	
	//The function below checks if users are present in a city
	public int[] usersPresent(int playersCitys[]) 
	{
		int inCity[]= {};
		for(int i=0;i<playersCitys.length;i++) 
		{
			if(i!=PLAYER_NUMBER-1) 
			{
				
				if(playersCitys[i]==CURRENT_CITY) 
				{
					
					int tempArraySize=inCity.length+1;
					int tempArray[]=new int[tempArraySize];
					for(int x=0;x<inCity.length;x++) 
					{
						tempArray[x]=inCity[x];
					}
					tempArray[tempArraySize-1]=i;
					inCity=tempArray;
				}
			}
		}
		
		return inCity;
		
	}
	
	/*The function below is used for a user to share cards*/
	public int shareKnowledge(String playersCards[]) 
	{
		for(int i=0;i<playersCards.length;i++) 
		{
			String cityData[] = playersCards[i].split(",");
			System.out.println(i+": "+cityData[0]);
		}
		Scanner userInput= new Scanner(System.in);
		int userSelection =userInput.nextInt();
		System.out.println("Selected: "+userSelection);
		if(userSelection<playersCards.length && userSelection>-1) 
		{
			System.out.println();
			String cardData[] = playersCards[userSelection].split(",");
			int cityIndex = Integer.parseInt(cardData[1]);
			
			int tempArraySize=PLAYER_CARDS.length+1;
			int tempArray[]=new int[tempArraySize];
			for(int x=0;x<PLAYER_CARDS.length;x++) 
			{
				tempArray[x]=PLAYER_CARDS[x];
			}
			
			tempArray[tempArraySize-1]=cityIndex;
			PLAYER_CARDS=tempArray;
			
			
			System.out.println("Given card number: "+cardData[0]);
			return cityIndex;
		}
		else {
			System.out.println("Invalid input");
		}
		return 0;
		
	}
	
	/*The function below is used add cards to the cards that the users cards.*/
	public void addCards(int cities[]) 
	{
		int tempArraySize=PLAYER_CARDS.length+cities.length;
		int tempArray[]=new int[tempArraySize];
		for(int x=0;x<PLAYER_CARDS.length;x++) 
		{
			tempArray[x]=PLAYER_CARDS[x];
		}
		int citiesLeft = PLAYER_CARDS.length+cities.length;
		int cityIndex=0;
		for(int i=PLAYER_CARDS.length;i<tempArraySize;i++) 
		{
			tempArray[i]=cities[cityIndex];
			cityIndex++;
		}
		PLAYER_CARDS=tempArray;
	}
	
	/*The function below is used to determine the movements that the agent will take.
	 * It uses the best decision made from the probability decision tree*/
	public int botMovements(int nextMove[][]) 
	{
		int botMove=nextMove[0][0];
		if(botMove==1) 
		{
			System.out.println("BOT MOVE: cure");
			if(nextMove[1][0]==1) 
			{
				System.out.println("BOT MOVE: Cure this city");
				return 1;
				
			}
			if(nextMove[1][0]==2) 
			{
				System.out.println("BOT MOVE: drive to neighbour city");
				botDrive(nextMove[2][0]);
				return 2;
				
			}
			if(nextMove[1][0]==3) 
			{
				System.out.println("BOT MOVE: fly to city");
				botDrive(nextMove[2][0]);
				return 3;
			}
			if(nextMove[1][0]==4) 
			{
				System.out.println("BOT MOVE: chatter flight to city");
				botDrive(nextMove[2][0]);
				return 3;
			}
		}
		if(botMove==2) 
		{
			System.out.println("BOT MOVE: share");
			if(nextMove[1][0]==1) 
			{
				System.out.println("BOT MOVE: Share this city");
				return 4;
			}
			if(nextMove[1][0]==2) 
			{
				System.out.println("BOT MOVE: drive to neighbour city to share");
				botDrive(nextMove[2][0]);
				return 5;
				
			}
			if(nextMove[1][0]==3) 
			{
				System.out.println("BOT MOVE: fly to city to share");
				botDrive(nextMove[2][0]);
				return 6;
			}
			if(nextMove[1][0]==4) 
			{
				System.out.println("BOT MOVE: chatter flight to city to share");
				botDrive(nextMove[2][0]);
				return 12;
			}
			
		}
		if(botMove==3) 
		{
			if(nextMove[1][0]==1) 
			{
				System.out.println("BOT MOVE: treating this city");
				return 7;
			}
			if(nextMove[1][0]==2) 
			{
				botDrive(nextMove[2][0]);
				System.out.println("BOT MOVE: moved to city");
				botDrive(nextMove[2][1]);
				System.out.println("BOT MOVE: treating this city");
				return 8;
			}
			if(nextMove[1][0]==3) 
			{
				System.out.println("BOT MOVE: chattering flight to treat city");
				botDrive(nextMove[2][0]);
				return 11;
			}
			
		}
		if(botMove==4) 
		{
			System.out.println("BOT MOVE: discard");
			int cityIndex=nextMove[1][0];
			int cardIndex =-1;
			for(int i=0;i<PLAYER_CARDS.length;i++) 
			{
				if(cityIndex==PLAYER_CARDS[i]) 
				{
					cardIndex=i;
				}
			}
			System.out.println("BOT MOVE: cityIndex: "+cityIndex);
			discardCity(cardIndex, PLAYER_CARDS.length-1);
			
			return 9;
		}
		if(botMove==5) 
		{
			System.out.println("BOT MOVE: BUILD STATION");
			return 10;
		}
		return 0;
	}
	
	/*The function below is used to move the agent to another city.*/
	private void botDrive(int city) 
	{
		CURRENT_CITY=city;
	}
	
	/*The function below is used for the agent to fly to another city*/
	public void botDirectFlight(int city) 
	{
		int cityIndex=-1;
		for(int i=0;i<PLAYER_CARDS.length;i++) 
		{
			if(PLAYER_CARDS[i]==city) 
			{
				cityIndex=i;
			}
		}
		CURRENT_CITY=city;
		discardCity(cityIndex,PLAYER_CARDS.length-1);		
		System.out.println("Current city: "+CURRENT_CITY);
	}
	
	/*The function below is used for the agent to share cards*/
	public void botShareKnowledge(int city) 
	{
		int tempArraySize=PLAYER_CARDS.length+1;
		int tempArray[]=new int[tempArraySize];
		for(int x=0;x<PLAYER_CARDS.length;x++) 
		{
			tempArray[x]=PLAYER_CARDS[x];
		}
		tempArray[tempArraySize-1]=city;
		PLAYER_CARDS=tempArray;
	}
	
	/*The function below is used for the agent to charter a flight*/
	public int botCharterFlight(int city) 
	{
		CURRENT_CITY=city;
		for(int i=0;i<PLAYER_CARDS.length;i++) 
		{
			if(PLAYER_CARDS[i]==city) 
			{
				discardCity(i,PLAYER_CARDS.length-1);
				break;
			}
		}
		return 0;	
	}
}
