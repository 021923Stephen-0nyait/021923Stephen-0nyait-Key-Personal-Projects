package Pandemic;

public class Node {
	public int value;
	public int layer;
	public Node previousNode;
	//This class contains data about the nodes in the monte carlo algorithim
	Node(int nodeValue,int nodeLayer, Node priorNode)
	{
		this.value=nodeValue;
		this.layer = nodeLayer;
		this.previousNode=priorNode;
	}
}
