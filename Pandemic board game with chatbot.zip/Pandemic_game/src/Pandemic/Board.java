package Pandemic;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Board {
	private int NUMBER_OF_CITIES = 48;
	private int CITY_MATRIX_DIMENSIONS = NUMBER_OF_CITIES+1;
	private int CITIES_MATRIX[][]= new int[CITY_MATRIX_DIMENSIONS][CITY_MATRIX_DIMENSIONS];
	private String CITIES_FILE = "src\\Map\\fullMap.txt";
	private int NUMBER_OF_LINES;
	private int BLUE_INDEX=0;
	private int YELLOW_INDEX=1;
	private int GREY_INDEX=2;
	private int RED_INDEX=3;
	private int EPIDEMIC_INDEX;
	private int OUTBREAK_LEVEL;//From 0 to 8
	private int CITIES_DISEASE_CUBES[][]=new int[5][49];
	public int YELLOW_CUBES;
	public int RED_CUBES;
	public int GREY_CUBES;
	public int BLUE_CUBES;
	private int EPIDEMIC_RATE[]= {2,2,2,3,3,4,4};
	private int CURE_MARKER[]= {0,0,0,0};
	private int RESEARCH_STATIONS[]= {1,0,0,0,0,0};
	private String CITY_COLORS[][] = new String[4][12];
	private String CITIES_INDEXES[][];
	private int CITY_CONNECTIONS_LIST[][]= new int[8][49];
	public ArrayList<String> CITIES_LIST;
	private String FILE_DATA[];
	ArrayList<Integer> outbreakHit=new ArrayList<Integer>();
	public  
	
	Board() 
	{
		this.NUMBER_OF_LINES=this.numberOfLines();
		this.FILE_DATA= new String[NUMBER_OF_LINES];
		this.EPIDEMIC_INDEX=0;
		this.OUTBREAK_LEVEL=0;
		this.BLUE_CUBES=24;
		this.RED_CUBES=24;
		this.YELLOW_CUBES=24;
		this.GREY_CUBES=24;
		this.CITIES_LIST = new ArrayList<String>(CITY_MATRIX_DIMENSIONS);
		this.CITIES_INDEXES = new String[1][CITY_MATRIX_DIMENSIONS];
	}
	/*The function below is used to read information about the cities from the file.*/
	public void readFileData() 
	{
		try {
			File cityFile = new File(CITIES_FILE);
			Scanner fileDetails = new Scanner(cityFile);
			int lineNumber = 0;
			while(fileDetails.hasNext()) 
			{
				FILE_DATA[lineNumber]=fileDetails.nextLine();
				lineNumber++;
			}
		      fileDetails.close();
		    } 
		 
		 catch (FileNotFoundException e) {
		      System.out.println("An error occurred reading the city graph.");
		      e.printStackTrace();
		    }
		
	}
	/*The function below is used to handle the data read from the file*/
	public void handleFileData() 
	{
		for(int i=1;i<=NUMBER_OF_CITIES;i++) 
		{
			int cityFileIndex=i+1;
			CITIES_LIST.add(FILE_DATA[cityFileIndex]);
		}
		
		for(int i=50;i<FILE_DATA.length;i++) 
		{
			String cityConnections[]= FILE_DATA[i].split(";");
			String cityOne= cityConnections[0];
			String cityTwo= cityConnections[1];
			
			int xAxis= CITIES_LIST.indexOf(String.valueOf(cityOne))+1;
			int yAxis= CITIES_LIST.indexOf(String.valueOf(cityTwo))+1;
			
			CITIES_MATRIX[xAxis][yAxis]=1;
			CITIES_MATRIX[yAxis][xAxis]=1;
		}	
		
	}
	/*The function below is used to get the color group of a given city that will be infected*/
	public int groupColors(int index) 
	{
		if(index<=12) 
		{
			BLUE_CUBES--;
			return 1;
		}
		if(index>12 && index<=24) 
		{
			YELLOW_CUBES--;
			return 2;
		}
		if(index>24 && index<=36) 
		{
			GREY_CUBES--;
			return 3;
		}
		if(index>36) 
		{
			RED_CUBES--;
			return 4;
		}
		return -1;
	}
	
	/*The function below is used to get the color group of a given city */
	public int colorGroup(int index) 
	{
		if(index<=12) 
		{
			return 1;
		}
		if(index>12 && index<=24) 
		{
			return 2;
		}
		if(index>24 && index<=36) 
		{
			return 3;
		}
		if(index>36) 
		{
			return 4;
		}
		return -1;
	}
	/*The function below is used to show the connection matrix of the cities*/
	public void showConnections() 
	{
		for(int x=1;x<CITIES_MATRIX.length;x++) 
		{
			for(int y=1;y<CITIES_MATRIX.length;y++) 
			{
				System.out.print(CITIES_MATRIX[y][x]);
				System.out.print(" ");
			}
			System.out.println();
		}
	}
	
	/*The function below is used to get all the neighboring cities connected to a city*/
	public void cityConnectionsList() 
	{
		int cityIndex= 1;
		for(int x=1;x<CITIES_MATRIX[0].length;x++) 
		{
			int currentNumber = 0;
			int connectionIndex=1;
			CITY_CONNECTIONS_LIST[0][x]=x;
			for(int y=1;y<CITIES_MATRIX[0].length;y++) 
			{
				if(CITIES_MATRIX[x][y]==1) 
				{
					CITY_CONNECTIONS_LIST[connectionIndex][x]=y;
					connectionIndex++;			
				}
			}
			cityIndex++;
		}
	}
	
	/*The function below is used to infect cities with a disease based on the infection cards passed into the function*/
	public void infectCities(int cities[]) 
	{
		for(int i=0 ; i<cities.length;i++) 
		{
			int currentCity=cities[i];
			int colorGroup=groupColors(currentCity);
			if(CITIES_DISEASE_CUBES[colorGroup][currentCity]<3) 
			{
				CITIES_DISEASE_CUBES[colorGroup][currentCity]=3;
			}
			
			if(CITIES_DISEASE_CUBES[colorGroup][currentCity]==3)
			{
				outbreakHit.add(currentCity);
				int outbreakNeighbours[];
				for(int j=1;j<CITY_CONNECTIONS_LIST[0].length;j++) 
				{
					if(CITY_CONNECTIONS_LIST[j][currentCity]==0) 
					{
						outbreakNeighbours=new int[j-1];
						for(int a=0;a<outbreakNeighbours.length;a++) 
						{
							outbreakNeighbours[a]=CITY_CONNECTIONS_LIST[a+1][currentCity];
						}
						handleOutbreak(outbreakNeighbours,colorGroup);
						j=CITY_CONNECTIONS_LIST[0].length-1;
					}
				}	
			}
		}
	}
	
	/*The function below is used distribute diseases and check for chain outbreaks when an outbreak occurs*/
	public void handleOutbreak(int cities[],int colorGroup) 
	{
		OUTBREAK_LEVEL++;
		for(int city=0;city<cities.length;city++) 
		{
				int currentConnectedCity=cities[city];
				int checker =outbreakHit.indexOf(Integer.valueOf(currentConnectedCity));
				int lessThanThree=0;
				if(CITIES_DISEASE_CUBES[colorGroup][currentConnectedCity]<3)
				{
					lessThanThree=1;
					CITIES_DISEASE_CUBES[colorGroup][currentConnectedCity]=CITIES_DISEASE_CUBES[colorGroup][currentConnectedCity]+1;
				}
				if(CITIES_DISEASE_CUBES[colorGroup][currentConnectedCity]==3 && checker==-1 &&lessThanThree==0)
				{
					
					outbreakHit.add(currentConnectedCity);
					int outbreakNeighbours[];
					for(int j=1;j<CITY_CONNECTIONS_LIST[0].length;j++) 
					{
						if(CITY_CONNECTIONS_LIST[j][currentConnectedCity]==0) 
						{
							
							outbreakNeighbours=new int[j-1];
							System.out.println(outbreakNeighbours.length);
							for(int a=0;a<outbreakNeighbours.length;a++) 
							{
								outbreakNeighbours[a]=CITY_CONNECTIONS_LIST[a+1][currentConnectedCity];
							}
							Arrays.toString(outbreakNeighbours);
							handleOutbreak(outbreakNeighbours,colorGroup);
							j=CITY_CONNECTIONS_LIST[0].length-1;
						}
					}
				}
		}
	}
	/*The function below is use to clear the outbreak queue when the disease cubes have been distributed*/
	public void clearOutbreakQueue() 
	{
		outbreakHit.clear();
	}
	
	/*The function below is used to handle the initial infection of of certain cities when the game begins*/
	public void initialInfection(int cities[]) 
	{
		for(int i=0;i<cities.length;i++) 
		{
			
			int currentCity=cities[i];
			if(i<=2) 
			{
				int colorGroup=groupColors(currentCity);
				CITIES_DISEASE_CUBES[colorGroup][currentCity]=3;
				
				
			}
			if(i>=3&&i<6) 
			{
				int colorGroup=groupColors(currentCity);
				CITIES_DISEASE_CUBES[colorGroup][currentCity]=2;
			}
			if(i>=6) 
			{
				int colorGroup=groupColors(currentCity);
				CITIES_DISEASE_CUBES[colorGroup][currentCity]=1;
			}
		}
	}
	
	/*The function below is used to add the cities index number to the disease cube matrix*/
	public void setDiseaseIndexes() 
	{
		for(int i=1;i<NUMBER_OF_CITIES;i++) 
		{
			CITIES_DISEASE_CUBES[0][i]=i;
		}
	}
	/*The function below is used to increase the infection rate*/
	public void increaseInfectionRate() 
	{
		EPIDEMIC_INDEX++;
	}
	
	/*The function below is used to get a neighboring cities name*/
	public String[] getNeighbours(int city) 
	{
		String neighbouringCities[]= {};
		for(int i=1;i<CITY_CONNECTIONS_LIST.length;i++) 
		{
			if(CITY_CONNECTIONS_LIST[i][city]==0) 
			{
				neighbouringCities= new String[i-1];
				i=CITY_CONNECTIONS_LIST.length-1;
			}
		}
		for(int j=0;j<neighbouringCities.length;j++) 
		{
			int cityIndex = CITY_CONNECTIONS_LIST[j+1][city];
			neighbouringCities[j] = CITIES_LIST.get(cityIndex-1)+","+cityIndex;
		}
		
		return neighbouringCities;
	}
	
	/*The function below is used to get the indexes of neighboring cities*/
	public int[] getNeighboursIndex(int city) 
	{
		int neighbouringCities[]= {};
		for(int i=1;i<CITY_CONNECTIONS_LIST.length;i++) 
		{
			if(CITY_CONNECTIONS_LIST[i][city]==0) 
			{
				neighbouringCities= new int[i-1];
				i=CITY_CONNECTIONS_LIST.length-1;
			}
		}
		for(int j=0;j<neighbouringCities.length;j++) 
		{
			int cityIndex = CITY_CONNECTIONS_LIST[j+1][city];
			neighbouringCities[j] = cityIndex;
		}
		
		return neighbouringCities;
	}
	
	/*The function below is used to return the names of cities*/
	public String[] getCityNames(int playerCards[]) 
	{
		String cities[]= new String[playerCards.length];
		for(int j=0;j<cities.length;j++) 
		{
			int city =playerCards[j];
			int cityColor= colorGroup(city);
			String cardColor="";
			if(cityColor==1) 
			{
				cardColor="COLOR: BLUE| ";
			}
			if(cityColor==2) 
			{
				cardColor="COLOR: YELLOW| ";
			}
			if(cityColor==3) 
			{
				cardColor="COLOR: GREY| ";
			}
			if(cityColor==4) 
			{
				cardColor="COLOR: RED| ";
			}
			cities[j] = cardColor+CITIES_LIST.get(city-1)+","+playerCards[j];
			
			
		}
		
		return cities;
	}
	/*The function below is used to show all the cities*/
	public void showCities() 
	{
		System.out.println("_____________________________");
		System.out.println("        ALL CARDS: ");
		System.out.println("_____________________________");
		int cityIndexes[]=new int[48];
		for(int i=1;i<=cityIndexes.length;i++) 
		{
			cityIndexes[i-1]=i;
		}
		String cityNames[]=getCityNames(cityIndexes);
		for(int i=0;i<cityNames.length;i++) 
		{
			String neighbouringCities[]=getNeighbours(i+1);
			String neighbours="| ADJACENT CITIES: ";
			for(int x=0;x<neighbouringCities.length;x++) 
			{
				String cityData[] = neighbouringCities[x].split(",");
				neighbours+=cityData[0]+", ";
			}
			
			String cityData[] = cityNames[i].split(",");
			int cityNumber=i+1;
			System.out.println(cityNumber+": "+cityData[0]+neighbours);
		}
	}
	/*The function below is used to see the diseases present in each city*/
	public void showDiseases()
	{
		System.out.println("_____________________________");
		System.out.println("____DISEASES_CUBES_PRESENT___");
		System.out.println("_____________________________");
		System.out.println("KEY:\nI = Index\nB = Blue\nY = Yellow\nG = Grey\nR = Red\n");
		System.out.println("I B Y G R");
		for(int x=0;x<NUMBER_OF_CITIES;x++) 
		{
			for(int y=0;y<CITIES_DISEASE_CUBES.length;y++)
			{
				System.out.print(CITIES_DISEASE_CUBES[y][x]+" ");
			}
			System.out.println();
		}
	}
	//Get number of lines in file
	private int numberOfLines() 
	{
		int lineNumber = 0;
		try {
			File cityFile = new File(CITIES_FILE);
			Scanner fileDetails = new Scanner(cityFile);
			
			while(fileDetails.hasNext()) 
			{
				
				lineNumber++;
				fileDetails.nextLine();
			}
		      fileDetails.close();
		    } 
		 
		 catch (FileNotFoundException e) {
		      System.out.println("An error occurred reading the city graph.");
		      e.printStackTrace();
		    }
		
		return lineNumber;
		
	}
	/*The function below is used to get the disease cubes present in a city*/
	public int[] getDiseases(int city) 
	{
		int diseaseCubes[]=new int[5];
		for(int i=0;i<CITIES_DISEASE_CUBES.length;i++) 
		{
			diseaseCubes[i]=CITIES_DISEASE_CUBES[i][city];
		}
		
		return diseaseCubes;
	}
	/*The function below is used to get the research stations built*/
	public int[] getResearchStations() 
	{
		int allResearchStations[]= {};
		for(int i=0;i<RESEARCH_STATIONS.length;i++) 
		{
			if(RESEARCH_STATIONS[i]==0) 
			{
				allResearchStations= new int[i];
				break;
			}
		}
		
		for(int i=0;i<allResearchStations.length;i++) 
		{
			allResearchStations[i]=RESEARCH_STATIONS[i];
		}
		
		return allResearchStations;
	}
	/*The function below is used to add research stations*/
	public void setResearchStation(int stationIndex) 
	{
		int allResearchStations[]= {};
		for(int i=0;i<RESEARCH_STATIONS.length;i++) 
		{
			if(RESEARCH_STATIONS[i]==0) 
			{
				RESEARCH_STATIONS[i]=stationIndex;
				
				break;
			}
		}
	}
	
	/*The function below is used to treat a city*/
	public void treatCity(int cityDetails[]) 
	{
		int cityIndex=cityDetails[0];
		int disease=cityDetails[1];
		CITIES_DISEASE_CUBES[disease][cityIndex]=CITIES_DISEASE_CUBES[disease][cityIndex]-1;
	}
	/*The function below is used to cure a disease*/
	public int discoverCure(int cards[]) 
	{
		int blue=0;
		int yellow=0;
		int grey=0;
		int red=0;
		for(int i=0;i<cards.length;i++) 
		{
			int colorindex= this.colorGroup(cards[i]);
			if(colorindex==1) 
			{
				blue++;
			}
			if(colorindex==2) 
			{
				yellow++;
			}
			if(colorindex==3) 
			{
				grey++;
			}
			if(colorindex==4) 
			{
				red++;
			}
		
		}
		ArrayList<Integer> diseases= new ArrayList<Integer>();
		int cureChecker=0;
		if(blue>=5 && CURE_MARKER[0]==0) 
		{
			System.out.println("1: CURE BLUE\n0:GO BACK"); 
			diseases.add(1);
			cureChecker=1;
		}
		if(yellow>=5 && CURE_MARKER[1]==0) 
		{
			System.out.println("2: CURE YELLOW\n0:GO BACK"); 
			diseases.add(2);
			cureChecker=1;
		}
		if(grey>=5 && CURE_MARKER[2]==0) 
		{
			System.out.println("3: CURE GREY\n0:GO BACK"); 
			diseases.add(3);
			cureChecker=1;
		}
		if(red>=5 && CURE_MARKER[3]==0) 
		{
			System.out.println("4: CURE RED\n0:GO BACK"); 
			diseases.add(4);
			cureChecker=1;
		}
		if(blue<5&&yellow<5&&grey<5&&red<5) 
		{
			System.out.println("NO CURES");
			return 0;
		}
		if(cureChecker==1)
		{
			Scanner userInput = new Scanner(System.in);
			int userSelection = userInput.nextInt();
			if(diseases.indexOf(Integer.valueOf(userSelection))>-1 && CURE_MARKER[userSelection-1]==0) 
			{
				CURE_MARKER[userSelection-1]=1;
				System.out.println(":) Disease Cured");
				System.out.println("CM: "+Arrays.toString(CURE_MARKER));
				
			}
			else 
			{
				System.out.println("No action taken");
			}
		}
		if(cureChecker!=1)
		{
			System.out.println("NO CURES");
			return 0;
		}
		return 1;
		
		
	}
	/*The function below is used to enable an agent to cure a disease*/
	public void botDiscoverCure(int regionColor) 
	{
		CURE_MARKER[regionColor-1]=1;
		System.out.println(":) Disease Cured");
		System.out.println("CM: "+Arrays.toString(CURE_MARKER));		
	}
	
	
	public void probabilityOfInfection() 
	{
		for(int i=1;i<=48;i++) 
		{
			int neighbours[] =getNeighboursIndex(i);
			indexInfectionProbability(i);
			
		}
	}
	public double indexInfectionProbability(int cityIndex) 
	{
		double totalInfection=0;
		for(int x=1;x<CITIES_DISEASE_CUBES.length;x++) 
		{
			int diseaseIndex=CITIES_DISEASE_CUBES[x][cityIndex];
			
			totalInfection+=(diseaseIndex/3.0);
		}
		return totalInfection;
	}
	
	/*The function below is used to check if the game is over*/
	public int gameOver() 
	{
		
		if(YELLOW_CUBES<=0||RED_CUBES<=0||GREY_CUBES<=0||BLUE_CUBES<=0) 
		{
			return 1;
		}
		if(this.OUTBREAK_LEVEL>=8) 
		{
			return 1;
		}
		
		return 0;
	}
	
	/*The function below is used to check if the user has won the game*/
	public int winGame() 
	{
		int fullyCured=1;
		for(int i=0;i<CURE_MARKER.length;i++) 
		{
			if(CURE_MARKER[i]==0) 
			{
				fullyCured=0;
			}
		}
		for(int x=0;x<NUMBER_OF_CITIES;x++) 
		{
			for(int y=1;y<CITIES_DISEASE_CUBES.length;y++)
			{
				if(CITIES_DISEASE_CUBES[y][x]>0) 
				{
					fullyCured=0;
				}
			}
		}
		if(fullyCured==1) 
		{
			System.out.println();
			System.out.println("________________________");
			System.out.println();
			System.out.println(":) CONGRADULATIONS YOU HAVE STOPPED THE PANDEMIC AND WON THE GAME. ");
			System.out.println();
			System.out.println("________________________");
			System.out.println();
			return 1;
		}
		return 0;
		
	}
	
	//Getters and setters are shown below
	public int getInfectionNumber() 
	{
		return EPIDEMIC_RATE[EPIDEMIC_INDEX];
	}

	public int[] getCURE_MARKER() {
		return CURE_MARKER;
	}

	public void setCURE_MARKER(int[] cURE_MARKER) {
		CURE_MARKER = cURE_MARKER;
	}
	
	
	
	
	
	
	
	
}
