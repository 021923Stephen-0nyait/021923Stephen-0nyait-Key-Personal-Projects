package Pandemic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
	public static void main(String args[]) 
	{
		int numberOfPlayers=2;
		int difficulty=1;
		int firstPlay=0;
		//Configuring and running the game until the player wins or the game ends
		Game pandemicGame = new Game(numberOfPlayers,difficulty);
		while(pandemicGame.gameOver()==0)
		{
			if(pandemicGame.setBoard.winGame()==1)
			{
				break;
			}
			if(pandemicGame.gameOver()!=0)
			{
				break;
			}
			
			pandemicGame.updateAllRankings();
			for(int i=0;i<pandemicGame.allPlayers.length;i++)
			{
				System.out.println(firstPlay);
				if(firstPlay>=numberOfPlayers) 
				{
					pandemicGame.getCards(i);
				}
				
				int actions=0;
				while(actions<4)
				{
					if(pandemicGame.setBoard.winGame()==1)
					{
						break;
					}
					if(pandemicGame.gameOver()!=0)
					{
						break;
					}
					pandemicGame.checkDiscard(i);
					pandemicGame.updateAllRankings();
					int decisionSuggested[][]=pandemicGame.evaluateDescisions(i);
					//If a player is a bot the agent will carry out different functions based on the best choice found
					if(pandemicGame.allPlayers[i].PLAYER_TYPE=="BOT") 
					{
						int outcome=pandemicGame.allPlayers[i].botMovements(decisionSuggested);
						if(outcome==1) 
						{
							pandemicGame.botCureDisease(i);
							actions++;
						}
						
						if(outcome==4) 
						{
							
							pandemicGame.getCureCards(i);
							actions++;
						}
						
						if(outcome==7) 
						{
							
							pandemicGame.botTreatDisease(i);
							actions++;
						}
						if(outcome==8) 
						{
							
							pandemicGame.botTreatDisease(i);
							actions++;
							actions++;
						}
						if(outcome==10) 
						{
							pandemicGame.botBuildStation(0);
							actions++;
						}
						if(outcome==11) 
						{
							
							pandemicGame.botCharterTreat(0);
							pandemicGame.botTreatDisease(i);
							actions++;
							actions++;
						}
						if(outcome==12) 
						{
							
							pandemicGame.botCharterShare(0);
							actions++;
						}
						if(outcome==13) 
						{
							pandemicGame.botCharterCure(0);
							actions++;
						}
						if(outcome>0 && outcome!=9) 
						{
							actions++;
						}
					

					}
					//If the user is a player the player will perform certain functions
					if(pandemicGame.allPlayers[i].PLAYER_TYPE=="PLAYER")
					{
						pandemicGame.discardPlayerCard(i);
						pandemicGame.evaluateDescisions(i);
						String currentCityName= pandemicGame.viewCurrentCity(i);
						System.out.println("Current Player: Player number "+(i+1)+"\n|Current City| "+currentCityName+"\nAction done: "+actions);
						System.out.println("1: View cities");
						System.out.println("2: View disease cubes");
						System.out.println("3: View player cards");
						System.out.println("4: Drive");
						System.out.println("5: Direct flight");
						System.out.println("6: Chatter flight");
						System.out.println("7: Shuttle flight");
						System.out.println("8: Treat disease");
						System.out.println("9: Build research station");
						System.out.println("10: Share knowledge");
						System.out.println("11: Discover cure");
						
						
						Scanner optionInputed= new Scanner(System.in);
						int usersOption = optionInputed.nextInt();
						
						if(usersOption==1) 
						{
							pandemicGame.setBoard.showCities();
						}
						
						else if(usersOption==2) 
						{
							pandemicGame.setBoard.showDiseases();
						}
						
						else if(usersOption==3) 
						{
							pandemicGame.viewPlayerCards(i);
						}
						
						else if(usersOption==4) 
						{
							pandemicGame.drivePlayer(i);
							actions++;
						}
						
						else if(usersOption==5) 
						{
							pandemicGame.directFlight(i);
							actions++;
						}
						
						else if(usersOption==6) 
						{
							pandemicGame.charterFlight(i);
							actions++;
						}
						
						else if(usersOption==7) 
						{
							pandemicGame.shuttleFlight(i);
							actions++;
						}
						
						else if(usersOption==8) 
						{
							pandemicGame.treatDisease(i);
							actions++;
						}
						
						else if(usersOption==9) 
						{
							pandemicGame.buildResearchStation(i);
							actions++;
						}
						
						else if(usersOption==10) 
						{
							pandemicGame.shareKnowledge(i);
							actions++;
						}
						
						else if(usersOption==11) 
						{
							int currentPlayerCards[]=pandemicGame.allPlayers[i].PLAYER_CARDS;
							pandemicGame.setBoard.discoverCure(currentPlayerCards);
							actions++;
						}
						
						else 
						{
							System.out.println("Invalid input");
						}
					}
				}
				firstPlay++;
				
			}
		}
	}
}
