package PrimsAlgorithim;

//This class is used to calculate the distances between two cities using the cities coordinates
public class EuclideanDistance {
	//The euclidean distance formula is used to calculate this distance
	public double CalculateEuclideanDistance(double x1,double y1,double x2,double y2)
	{
		double xSquared = ((x1)-(x2))*((x1)-(x2));
		double ySquared = ((y1)-(y2))*((y1)-(y2));
		double distance= Math.sqrt(xSquared+ySquared);
		
		return distance;
	}
}
