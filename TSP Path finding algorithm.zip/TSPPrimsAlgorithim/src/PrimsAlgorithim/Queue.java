package PrimsAlgorithim;

public class Queue {
	int size=0;
	int queue[];
	int front;
	int back;
	
	/*The resize function is used to resize the queue.
	 * Resizing the queue will make it possible to add values to the queue */
	public void resize() {
		int newLength = size+1;
		int newQueue[] = new int[newLength];
		/*The values in the queue are added to a temporary array which as one more space for a new value.
		 * all the values in the temporary array then replace the values in the queue the extra space
		 * is also added to the queue*/
		if(size>0)
		{
			for(int i=0;i<queue.length;i++) {
				newQueue[i] = queue[i];
			}
		}
		queue = newQueue;
	}
	/*Enque is used to put new values at the end of the queue*/
	public void enque(int index)
	{
		if(size>0) {
			resize();
			queue[size] = index;
			this.size=size+1;
			return;
		}
		else {
			resize();
			queue[0]= index;
			this.size=size+1;
			return;
		}
	}
	/*deque is used to remove the first value in the queue*/
	public void deque()
	{
		int arraySize =size-1;
		int smallerArray[] = new int[arraySize];
		/*all values are loaded into a temporary array excluding the first value in the queue
		 * the values in the temporary array replace the values in the queue after*/
		for(int i=0;i<smallerArray.length;i++)
		{
			int queueIndex = i+1;
			smallerArray[i]=queue[queueIndex];
		}
		this.queue = smallerArray;
	}
	
	/*peek() shows the value at the front of the queue*/
	public int peek() 
	{
		return queue[queue.length-1];
	}
	
	/*getQueue() returns all the values in the queue*/
	public int[] getQueue()
	{
		return this.queue;
	}

}
