package PrimsAlgorithim;

import java.util.Arrays;

/*The 'priorityQueue' class is used to order the distances for all vertices*/
public class PriorityQueue {
	int numberOfValues;
	int PriorityQueueMatrix[][];
	double distances[][];
	int queueNumbers[];
	
	PriorityQueue(int total,double matrix[][],int indexes[])
	{
		this.numberOfValues =total;
		this.PriorityQueueMatrix= new int [total+1][total+1];
		this.distances=new double [total][total];
		this.distances = matrix;
		this.queueNumbers= indexes;
	}
	
	/*The 'makePriorityQueue' method takes in the distances between each node and other nodes
	 * these distances are then ordered in ascending order*/
	public int[][] makePriorityQueue()
	{
		double currentQueue[]=new double[numberOfValues];
		int newQueue[]=new int[numberOfValues];
		//Copys of the index array are used to so that the values in the original index array can be reused
		int indexArray[] =Arrays.copyOf(queueNumbers,queueNumbers.length);
		for(int x=1;x<=numberOfValues;x++)
		{
			for(int y=1;y<=numberOfValues;y++) 
			{
				int currentIndex=y-1;
				currentQueue[currentIndex]=distances[x][y];
			}
			/*The quick sort algorithm is used to order the distances between the current node we are
			 * sorting and other nodes in ascending order then return the sorted array.*/
			QuickSortAlgorithim sortQueue = new QuickSortAlgorithim(currentQueue,indexArray,numberOfValues);
			newQueue = sortQueue.sortDistances();
			for(int i=1;i<numberOfValues+1;i++) 
			{
				PriorityQueueMatrix[x][i]=newQueue[i-1];
			}
			indexArray= Arrays.copyOf(queueNumbers,queueNumbers.length);
		}
		return PriorityQueueMatrix;
	}
	

}
