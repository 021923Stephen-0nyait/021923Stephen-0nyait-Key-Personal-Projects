package PrimsAlgorithim;

import java.util.Scanner;

/*This is the main class were the algorithms will be implemented*/
public class Main {
	public static void main(String[] args)
	{
		String fileName;
		double adjacencyMatrix [][] ;
		Scanner getInput = new Scanner(System.in);
		System.out.println("Enter the name of the File:");
		fileName =getInput.nextLine();
		/*Below we get the file of coordinates that the would like to use then use this file
		 *to calculate the distances between these cities and create a graph.
		*/
		FileHandler fileNow = new FileHandler(fileName);	
		getInput.close();
		int matrixSize =fileNow.arraySize;
		adjacencyMatrix=new double [matrixSize][matrixSize];
		adjacencyMatrix=fileNow.getValues();
		long startTime = System.nanoTime();

		/*If the number of cities is less than 10 a brute force algorithm
		 * is used to find the optimal distance since it gives a more optimal
		 * solution than a minimum spanning tree*/
		if(matrixSize<=9) 
		{
			BruteForceAlgorithm bruteForceMethod = new BruteForceAlgorithm(matrixSize);
			/*The string bellow takes the cities distances to the brute force algorithm
			 * where it will evaluate all the routes and show the shortest route*/
			String shortestDistance=bruteForceMethod.permute(bruteForceMethod.getCopy(), adjacencyMatrix, 0, bruteForceMethod.numberOfValues);
			long finishTime = System.nanoTime();
			long timeTaken = finishTime-startTime;
			System.out.println(shortestDistance);
			System.out.println("Time Taken in nanoseconds: "+ timeTaken);
		} 
		
		/*If the number of cities is greater than 10 prims algorithm
		 * is used to find the optimal distance since the brute force algorithm will take more time
		 * the distance for prims algorithm is less than 2 times the optimal distance*/
		if(matrixSize>9) 
		{
			int pickingOrder[][];
			/*First we make an array of all the indexes present in the graph this will be used to arrange
			 *how the cities will be ordered in the for all the vertices in the priority queue.*/
			int queueNumbers[] = new int[matrixSize];
			for(int i=0;i<matrixSize;i++)
			{
				queueNumbers[i]=i+1;
			}
			/*Below we are making the priority queue and using it to find cities faster in the 
			minimum spanning tree it makes us to loop through the array less. we then send the priority queue to
			the Prims class where it uses Prims algorithm to find the closes city*/
			PriorityQueue queue = new PriorityQueue(matrixSize,adjacencyMatrix,queueNumbers);		
			pickingOrder=queue.makePriorityQueue();
			Prims solveTSP = new Prims(pickingOrder,adjacencyMatrix,matrixSize);
			solveTSP.directions();
			long finishTime = System.nanoTime();
			long timeTaken = finishTime-startTime;
			System.out.println("");
			System.out.println("Time Taken in nanoseconds: "+ timeTaken);
		}
	}
}
