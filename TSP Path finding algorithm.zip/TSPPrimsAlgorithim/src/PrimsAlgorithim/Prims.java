package PrimsAlgorithim;

import java.util.Arrays;

public class Prims {
	int startingPoint[];
	double distances[][];
	int priorityQueue[][];
	int visitied[];
	int visitedQueue[];
	double totalDistance=0.0;
	int startingIndex[];
	double minimumNumber = Integer.MAX_VALUE;
	Queue queue = new Queue();
	
	Prims(int indexValues[][],double cities[][],int numberOfCities)
	{
		this.distances=cities;
		this.priorityQueue=indexValues;
		this.visitied = new int [numberOfCities+1];
		this.startingIndex=new int [numberOfCities+1];
		Arrays.fill(startingIndex, 2);
		visitied[1]=1;
		this.queue.enque(1);
	}
	/*The 'directions()' algorithm is used to create the minimum spanning tree it adds the unvisited city which has an edge with the lowest
	 * to the queue. it uses a priority queue to enhance it's performance.*/
	public void directions() 
	{
		this.visitedQueue = queue.getQueue();
		int citysDistance=0;
		double distanceToAdd=0;
		for(int i=0;i<visitedQueue.length;i++) 
		{
			int x = visitedQueue[i];
			
			int start=startingIndex[x];
			int  y=priorityQueue[x][start];

			if(visitied[y]==1) 
			{
				/*This if statement changes the starting point in the priority queue if the current starting point
				 * in the priority queue has been visited. it keeps changing the starting index in the priority queue until an index
				 * that has not been visited is found*/
				while(visitied[y]==1) 
				{
					if(startingIndex[x]+1<priorityQueue.length) 
					{
						startingIndex[x]=startingIndex[x]+1;
						start=startingIndex[x];
						y=priorityQueue[x][start];
					}
				}
			}
			
			double currentCity= distances[x][y];
			if(currentCity<minimumNumber) 
			{
				/*This if statement looks for the unvisited node connected to one of the visited nodes with the lowest weight*/
				this.minimumNumber=currentCity;
				citysDistance=y;
				distanceToAdd=currentCity;
				
			}
		}
		this.totalDistance +=distanceToAdd;
		this.queue.enque(citysDistance);
		this.visitied[citysDistance]=1;
		if(visitedQueue.length<priorityQueue.length-2) 
		{
			//The 'directions' function is called recursively until all the nodes are visited
			minimumNumber=Integer.MAX_VALUE;
			directions();
			
		}
		else {
			
			double distance = 0;
			int queueIndexes[]= this.queue.queue;
			//In the for loop below the distance is being calculated and the final distance is returned as well as the route that will be used
			for(int x=0;x<queueIndexes.length;x++)
			{
				int xAxis;
				int yAxis;
				if(x+1==queueIndexes.length) 
				{
					xAxis=queueIndexes[x];
					distance+= distances[xAxis][1];
				}
				else {
					xAxis=queueIndexes[x];
					yAxis=queueIndexes[x+1];
					
					distance+=distances[xAxis][yAxis];
				}
				
			}
			String finalCityOrder = Arrays.toString(queueIndexes);
			finalCityOrder=finalCityOrder.replace("[", "");
			finalCityOrder=finalCityOrder.replace("]", "");
			finalCityOrder=finalCityOrder.replace(", ", " -> ");
			finalCityOrder= finalCityOrder+" -> 1";
			System.out.print("Order of cities: "+finalCityOrder+ "\nTotal Distance: "+distance);
		}
		
	
	}
	
}
