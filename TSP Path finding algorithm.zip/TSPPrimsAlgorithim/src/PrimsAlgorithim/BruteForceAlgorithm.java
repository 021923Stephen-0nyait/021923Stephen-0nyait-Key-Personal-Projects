package PrimsAlgorithim;

import java.util.Arrays;
public class BruteForceAlgorithm {
	int numberOfValues;
	int permutationList[];
	double shortestDistance = Integer.MAX_VALUE;
	int permutationsNumber; 
	int currentIndex=0;
	String orderOfCities;
	BruteForceAlgorithm(int valuesSize)
	{
		this.numberOfValues = valuesSize;
		this.permutationList= new int [valuesSize];
		populateIndexes();
		
	}
	
	public void swap(int numOne, int numTwo) 
	{
		int temp = this.permutationList[numOne];
		this.permutationList[numOne]=this.permutationList[numTwo];
		this.permutationList[numTwo]=temp;
		
	}
	
	/*The permute function recursively calls itself to find all permutations when the queue starts with a certain value. This happens
	 * until all the permutations are found.*/
	public String permute(int indexArray[],double adjacencyMatrix[][],int left, int right) 
	{
		if(left==right) 
		{
			/* The distance of this route found is compared with the minimum distance found. If the new distance is shorter
			 * it is marked as the most optimal path*/
			double distance =0;
			for(int x=0;x<permutationList.length;x++)
			{
				int xAxis;
				int yAxis;
				if(x+1==permutationList.length) 
				{
					xAxis=permutationList[x];
					distance+=adjacencyMatrix[xAxis][1];
				}
				else {
					xAxis=permutationList[x];
					yAxis=permutationList[x+1];
					
					distance+=adjacencyMatrix[xAxis][yAxis];
				}
				
			}
			if(shortestDistance>distance && permutationList[0]==1 ) 
			{
				this.shortestDistance = distance;
				String finalCityOrder=Arrays.toString(permutationList);
				finalCityOrder=finalCityOrder.replace("[", "");
				finalCityOrder=finalCityOrder.replace("]", "");
				finalCityOrder=finalCityOrder.replace(", ", " -> ");
				finalCityOrder= finalCityOrder+" -> 1";
				this.orderOfCities = "Order of cities: "+finalCityOrder+ "\nTotal disatance: "+distance;
				
			}
			currentIndex+=1;
		}
		else 
		{
			for(int i=left;i<right;i++) 
			{
				//This recursive loop is used to find all the permutations when the program starts with each of the numbers in the array
				swap(0+left,i);
				permute(getCopy(),adjacencyMatrix,left+1,right);
				swap(0+left,i);
			}
			return this.orderOfCities;
		}
		return this.orderOfCities;
	}
	
	//the 'getCopy()' function is used to give the original array of indexes
	public int[]getCopy()
	{
		return Arrays.copyOf(permutationList,permutationList.length);
	}
	//populatIndexes adds the index numbers of the cities to an arrray
	public void populateIndexes() 
	{
		for(int i=0;i<numberOfValues;i++) 
		{
			this.permutationList[i]=i+1;
		}
		
	}
	
}
