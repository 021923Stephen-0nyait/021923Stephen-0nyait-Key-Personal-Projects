package PrimsAlgorithim;


public class QuickSortAlgorithim {
	int numberOfValues;
	int queueNumbers[];
	double citiesDistances[];
	
	public QuickSortAlgorithim(double cities[],int queueIndexes[],int total)
	{
		this.numberOfValues = total;
		this.queueNumbers = new int[total];
		this.queueNumbers = queueIndexes;
		this.citiesDistances = new double[total];
		this.citiesDistances = cities;
	}
	
	/*sortDistances is used to sort the array which has been passed to this class*/
	public int[] sortDistances()
	{
		int highest =citiesDistances.length-1;
		quickSort(citiesDistances,queueNumbers,0,highest);
		return queueNumbers;
	}
	
	public static void quickSort(double cityArray[],int changes[],int lowIndex, int highIndex)
	{
		/*This quick sort algorithm places values more than the pivot to the right of the pivot and values less than the pivot to
		 * the left of the pivot it does this recursively until the whole array is sorted.*/
		if(lowIndex>=highIndex)
		{
			return;
		}
		double pivot = cityArray[highIndex];
		int leftPointer = lowIndex;
		int rightPointer = highIndex;
		while(leftPointer<rightPointer)
		{
			while(cityArray[leftPointer]<=pivot && leftPointer<rightPointer)
			{
				leftPointer++;
			}
			while(cityArray[rightPointer]>=pivot && leftPointer<rightPointer)
			{
				rightPointer--;
			}
			swap(cityArray,changes,leftPointer,rightPointer);
		}
		swap(cityArray,changes,leftPointer,highIndex);
		quickSort(cityArray,changes,lowIndex,leftPointer-1);
		quickSort(cityArray,changes,leftPointer+1,highIndex);
	}
	//swap moves values before or after the pivot depending on whether or not the value is less than the pivot
	public static void swap(double cityArray[],int changes[],int index1,int index2)
	{
		double temp=cityArray[index1];
		cityArray[index1]=cityArray[index2];
		cityArray[index2]=temp;
		
		int temp2 = changes[index1];
		changes[index1] = changes[index2];
		changes[index2]=temp2;
	}
}

