package PrimsAlgorithim;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/*This is the File Handler class where we read the file with the 
 *coordinates and use these coordinates to make a graph*/
public class FileHandler {
	String fileLocation;
	int xAxis[];
	int yAxis[];
	double adjacencyMatrix[][];
	int arraySize;
	
	//In the constructor we pass in the file that has the coordinates
	FileHandler(String fileName)
	{
		this.fileLocation = "src\\citiesFile\\"+fileName;
		this.arraySize= getNumberOfValues();
	}
	
	/*get values will read each line in the file and get the x axis and y axis for all cities
	 * if the file is not found an error message is displayed*/
	public double[][] getValues()
	{
		this.xAxis= new int[arraySize];
		this.yAxis= new int[arraySize];
		int matrixSize = arraySize+1;
		this.adjacencyMatrix=new double[matrixSize][matrixSize];
		try {
			File file = new File(fileLocation);			
			Scanner fileDetails = new Scanner(file);
			int i=0;
			while(fileDetails.hasNextLine()){
				String[] valuesArray = fileDetails.nextLine().split("\\s+");
				this.xAxis[i]=Integer.parseInt(valuesArray[1]);
				this.yAxis[i]=Integer.parseInt(valuesArray[2]);
				i++;
			}
		
			fileDetails.close();
			
		}catch (FileNotFoundException fileNotFoundException) {
            System.out.println("File Is Missing");
            fileNotFoundException.printStackTrace();
        }
		makeAdjacencyMatrix();
		return adjacencyMatrix;
	}
	
	/*The function named 'getNumberOfValues' is used to find out how many coordinates are present.
	 *This will help to determine the size of the array matrix for the graph. It does this by counting
	 *the number of lines in the graph*/
	public int getNumberOfValues()
	{
		int numberOfNodes = 0;
		try {
			File file = new File(fileLocation);			
			Scanner fileDetails = new Scanner(file);
			while(fileDetails.hasNextLine()){
				fileDetails.nextLine();
				numberOfNodes++;
			}
			fileDetails.close();
		}catch (FileNotFoundException fileNotFoundException) {
            System.out.println("File Is Missing");
            fileNotFoundException.printStackTrace();
        }
		return numberOfNodes;	
	}
	
	/*the function 'makeAdjacencyMatrix' is used to get the distances and use the distances to make the
	 * adjacency matrix which represents the graph.*/
	public double[][] makeAdjacencyMatrix()
	{
		//The class 'EuclideanDistance' will be used to calculate the distances between two cities
		EuclideanDistance coordinates = new EuclideanDistance();
		//This loop adds the distances calculated to the adjacency matrix
		for(int x=0;x<xAxis.length;x++)
		{
			int x1 = xAxis[x];
			int y1 = yAxis[x];
			for(int y=0;y<yAxis.length;y++)
			{
				int x2= xAxis[y];
				int y2= yAxis[y];
				double distance=coordinates.CalculateEuclideanDistance(x1, y1, x2, y2);
				int xIndex = x+1;
				int yIndex = y+1;
				this.adjacencyMatrix[xIndex][yIndex]= distance;
			}
		}
		return this.adjacencyMatrix;
	}
}
