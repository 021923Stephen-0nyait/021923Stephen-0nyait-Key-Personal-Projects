TRAVELLING SALESMAN PROBLEM SOLVER
DESCRIPTION
This project solves the Travelling Salesman Problem, which involves finding the shortest path to visit a given set of points exactly once and return to the starting point.
The problem is considered NP-hard, and this project provides an implementation that utilizes Java.

TECHNOLOGIES USED
The following technology was used in the development of this project:
- Java: A general-purpose programming language used for developing applications, including machine learning algorithms.

ALGORITHMS USED
The project employs different algorithms based on the number of cities in the input file. For files with fewer than 10 cities, the exact brute force algorithm is used.
It compares all possible permutations of cities to find the shortest path. For files with 10 or more cities, the approximate Prim's algorithm is utilized. Prim's algorithm
is a greedy algorithm that finds a suboptimal solution by adding edges with the lowest weights to a growing tree.

TECHNOLOGIES USED
The following technology was used in the development of this project:
- Java: A general-purpose programming language used for developing applications, including machine learning algorithms.

TESTING
The testing was performed using Java and the implemented algorithms on the specified computer.

COMPUTER DETAILS
- Processor: Intel Core i5-4200M
- Installed RAM: 4 GB
- System Type: 64-bit Operating System
- Operating System: Windows 10

GETTING STARTED
To get started with the project, follow these steps:
1. Download the project from the drive.
2. Make sure Java is installed on your system.
3. Set up the required development environment, such as an IDE or command line.
4. Import the project into your chosen development environment.
5. Run the project to execute the digit recognition algorithm.
6. Follow the on-screen instructions to input the file name containing the cities.

CONTRIBUTORS
Stephen Onyait