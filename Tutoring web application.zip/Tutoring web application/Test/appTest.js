const server = require('../server')
let chai = require('chai');
let assert = chai.assert;

//Set up Chai for testing web service
let chaiHttp = require ('chai-http');
chai.use(chaiHttp);


describe('Email is correct but password is incorrect', () => {
  it('should return 1', (done) => {
    chai.request(server)
      .post('/login_user')
      .send({
        email: 'chem@mail.com',
        user_type: 'teacher',
        password: 'password123'
        
      })
      .end((err, response) => {
        // Check the status code
        response.should.have.status(200);
        // Convert returned JSON to JavaScript object
        let resObj = JSON.parse(response.text);
        // Get the error sign from the response object
        let error_sign = resObj.error;
        // Assert that the error sign is equal to 1
        assert.equal(1, error_sign);
        // Call the done() function to indicate that the test is complete
        done();
      });
  });
});

describe('Email is correct and password are incorrect', () => {
  it('should return 0', (done) => {
    chai.request(server)
      .post('/login_user')
      .send({
        email: 'chem@mail.com',
        user_type: 'teacher',
        password: '123'
        
      })
      .end((err, response) => {
        // Check the status code
        response.should.have.status(200);
        // Convert returned JSON to JavaScript object
        let resObj = JSON.parse(response.text);
        // Get the error sign from the response object
        let error_sign = resObj.error;
        // Assert that the error sign is equal to 1
        assert.equal(0, error_sign);
        // Call the done() function to indicate that the test is complete
        done();
      });
  });
});

describe('Email does not exist at all', () => {
  it('should return 2', (done) => {
    chai.request(server)
      .post('/login_user')
      .send({
        email: 'fjkasdhfasjkldfhe@mail.com',
        user_type: 'teacher',
        password: '123'
        
      })
      .end((err, response) => {
        // Check the status code
        response.should.have.status(200);
        // Convert returned JSON to JavaScript object
        let resObj = JSON.parse(response.text);
        // Get the error sign from the response object
        let error_sign = resObj.error;
        // Assert that the error sign is equal to 1
        assert.equal(2, error_sign);
        // Call the done() function to indicate that the test is complete
        done();
      });
  });
});

describe('User is a teacher', () => {
  it('Should return username, description, and rank', (done) => {
    chai.request(server)
      .post('/profile_details')
      .send({
        email: 'chem@mail.com',
        user_type: 'teacher'
        
      })
      .end((err, response) => {
        // Check the status code
        response.should.have.status(200);
        // Convert returned JSON to JavaScript object
        let resObj = JSON.parse(response.text);
        console.log(resObj);
        // Get the error sign from the response object
        resObj.should.have.property('user_name');
        resObj.should.have.property('description');
        resObj.should.have.property('ranking');
        // Call the done() function to indicate that the test is complete
        done();
      });
  });
});

describe('User is a student', () => {
  it('Should only return username', (done) => {
    chai.request(server)
      .post('/profile_details')
      .send({
        email: 'stude@mail.co',
        user_type: 'student'
        
      })
      .end((err, response) => {
        // Check the status code
        response.should.have.status(200);
        // Convert returned JSON to JavaScript object
        let resObj = JSON.parse(response.text);
        // Assert that the error sign is equal to 1
        resObj.should.have.property('user_name');
        // Call the done() function to indicate that the test is complete
        done();
      });
  });
});


describe('Testing if login works', () => {
  it('Should return 1 if the user is logged in', (done) => {
    chai.request(server)
      .post('/check_login')
      .send({
        email: 'chem@mail.com'
        
      })
      .end((err, response) => {
        // Check the status code
        response.should.have.status(200);
        // Convert returned JSON to JavaScript object
        let resObj = JSON.parse(response.text);
        let status = resObj.status;
        assert.equal(1, status);
        // Call the done() function to indicate that the test is complete
        done();
      });
  });
});

describe('Does not allow email that has already been used to register again', () => {
  it('Should return 1', (done) => {
    chai.request(server)
      .post('/register_teacher')
      .send({
        email: 'chem@mail.com',
        name: 'hjklhjk',
        name: '2221122211'
        
      })
      .end((err, response) => {
        // Check the status code
        response.should.have.status(200);
        // Convert returned JSON to JavaScript object
        let resObj = JSON.parse(response.text);
        let error=resObj.error
        assert.equal(1, error);
        // Call the done() function to indicate that the test is complete
        done();
      });
  });
});


describe('Does not allow user name that has already been used to register again', () => {
  it('Should return 2', (done) => {
    chai.request(server)
      .post('/register_teacher')
      .send({
        email: 'jkflsd;aff',
        name: 'chem',
        phone: '2221122211'
        
      })
      .end((err, response) => {
        // Check the status code
        response.should.have.status(200);
        // Convert returned JSON to JavaScript object
        let resObj = JSON.parse(response.text);
        let error=resObj.error
        assert.equal(2, error);
        // Call the done() function to indicate that the test is complete
        done();
      });
  });
});

describe('Does not allow user phone number that has already been used to be register again on the platform', () => {
  it('Should return 3', (done) => {
    chai.request(server)
      .post('/register_teacher')
      .send({
        email: 'jkflsd;aff',
        name: 'hjkjlh',
        phone: '87902329'
        
      })
      .end((err, response) => {
        // Check the status code
        response.should.have.status(200);
        // Convert returned JSON to JavaScript object
        let resObj = JSON.parse(response.text);
        let error=resObj.error
        assert.equal(3, error);
        // Call the done() function to indicate that the test is complete
        done();
      });
  });
});

describe('Does not allow students email that has already been used to be register again on the platform', () => {
  it('Should return 1', (done) => {
    chai.request(server)
      .post('/register_student')
      .send({
        email: 'stude@mail.co',
        name: 'hjkjlh',
        phone: '87902329'
        
      })
      .end((err, response) => {
        // Check the status code
        response.should.have.status(200);
        // Convert returned JSON to JavaScript object
        let resObj = JSON.parse(response.text);
        let error=resObj.error
        assert.equal(1, error);
        // Call the done() function to indicate that the test is complete
        done();
      });
  });
});

describe('Does not allow students username that has already been used to be register again on the platform', () => {
  it('Should return 2', (done) => {
    chai.request(server)
      .post('/register_student')
      .send({
        email: 'ghjgjkhghj',
        name: 'student',
        phone: '87902329'
        
      })
      .end((err, response) => {
        // Check the status code
        response.should.have.status(200);
        // Convert returned JSON to JavaScript object
        let resObj = JSON.parse(response.text);
        let error=resObj.error
        console.log(resObj)+" "+error;
        assert.equal(2, error);
        // Call the done() function to indicate that the test is complete
        done();
      });
  });
});
