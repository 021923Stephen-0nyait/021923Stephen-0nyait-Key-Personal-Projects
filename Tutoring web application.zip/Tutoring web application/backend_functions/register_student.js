/* This script is used to handle the handle the authenication of the students details.*/
//Link to AWS-SDK
const AWS = require("aws-sdk");

//Tell AWS about region
AWS.config.update({
    region: "us-east-1"
});

/* The function below is used to store a new student into the Student_profile dynamoDb database containing teachers data.*/
async function put_student_data(name,Phone,Email,password) {
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Student_profile",//change this
        Item: {
            "user_name": {S:name},
            "email": {S:Email},
            "phone": {N:Phone},
            "password": {S:password},
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.putItem(params).promise();
        console.log("Data uploaded successfully: " + JSON.stringify(result));
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to check if a specific students email exists in the Student_profile dynamoDb database.*/
async function find_student_email(email) {
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Student_profile",
        IndexName: "email-index",
        KeyConditionExpression: "email = :mail",
        ExpressionAttributeValues: {
            ":mail" : {S:email}
        }
    };
    //Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        let resuls_data=result
        return resuls_data.Count
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* The function below is used to see if there is a student with a certain user name in the Student_profile dynamoDb database.*/
async function find_student_name(name) {
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Student_profile",
        IndexName: "user_name-index",
        KeyConditionExpression: "user_name = :nom",
        ExpressionAttributeValues: {
            ":nom" : {S:name}
        }
    };
    //Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        let resuls_data=result
        return resuls_data.Count
        
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* The function below is used to see if there is a student with a certain phone number in the Student_profile dynamoDb database.*/
async function find_student_phone(phone) {
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Student_profile",
        IndexName: "phone-index",
        KeyConditionExpression: "phone = :number",
        ExpressionAttributeValues: {
            ":number" : {N:phone}
        }
    };
    //Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        let resuls_data=result
        return resuls_data.Count
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}


async function get_email(email) {
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Student_profile",
        IndexName: "email-index",
        KeyConditionExpression: "email = :mail",
        ExpressionAttributeValues: {
            ":mail" : {S:email}
        }
    };
    //Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        return JSON.stringify(result)
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* The function below is used to get a the details of a student with a given email from Student_profile dynamoDb database.*/
async function login_User(email,password)
{
    let existing_user= await find_email(email)
    if(existing_user>0)
    {
        let current_email=await get_email(email)
        let process_data= JSON.parse(current_email)
        let user_password=process_data["Items"][0]["password"]["S"]
        if(password==user_password)
        {
            return 1
        }
        if(password!=user_password)
        {
            return 2
        }
    }
    else{
        return 3
    }    
}

module.exports = {find_student_email,find_student_name,find_student_phone,put_student_data,login_User}