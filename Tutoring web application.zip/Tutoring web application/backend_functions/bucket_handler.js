let AWS = require('aws-sdk');

/* The function below is used to create a new folder for teachers when they create an account. This folder will store the
teachers videos and images.*/
function create_teacher_folder(email){
    // Set the region 
    AWS.config.update({
        region: 'us-east-1'
    });

    // Create S3 service object
    let s3 = new AWS.S3({apiVersion: '2006-03-01'});
    let uploadParams = {Bucket: 'cst3990-c0ursew0rk-2-tut0ringp1ug', Key: `users/teachers/${email}/`,Body:''};
    // call S3 to retrieve upload file to specified bucket
    s3.upload (uploadParams, function (err, data) {
    if (err) {
        console.log("Error", err);

    } if (data) {
        folder_paths(`users/teachers/${email}/profile_picture/`)
        folder_paths(`users/teachers/${email}/thumbnails/`)
        folder_paths(`users/teachers/${email}/videos/`)
    }
    });
}

/* The function below is used to create a new folder for students when they create an account. This folder will store the
students images.*/
function create_student_folder(email){
    // Create S3 service object
    let s3 = new AWS.S3({apiVersion: '2006-03-01'});
    let uploadParams = {Bucket: 'cst3990-c0ursew0rk-2-tut0ringp1ug', Key: `users/students/${email}/`,Body:''};
    // call S3 to retrieve upload file to specified bucket
    s3.upload (uploadParams, function (err, data) {
    if (err) {
        console.log("Error", err);

    } if (data) {
        folder_paths(`users/students/${email}/profile_picture/`)
    }
    });
}

/* The function below is used to create the folder paths in the S3 Bucket.*/
function folder_paths(email){
    // Create S3 service object
    let s3 = new AWS.S3({apiVersion: '2006-03-01'});
    let uploadParams = {Bucket: 'cst3990-c0ursew0rk-2-tut0ringp1ug', Key: `${email}`,Body:''};
    // call S3 to retrieve upload file to specified bucket
    s3.upload (uploadParams, function (err, data) {
    if (err) {
        console.log("Error", err);
    } if (data) {
        console.log("Upload Success", data.Location);
    }
    });
}

module.exports = {create_teacher_folder,create_student_folder}