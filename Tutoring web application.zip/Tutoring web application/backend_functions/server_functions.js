const fs = require('fs');
const AWS = require("aws-sdk");
const path = require('path');
const { v4: uuidv4 } = require('uuid');
AWS.config.update({
    region: "us-east-1"
});

/* the function below is used to authenicate users and sign the users in if the authenication is passed*/
async function handle_login(req,res)
{
    let user_data=JSON.stringify(req.body)
    let format_data=JSON.parse(user_data)
    let user_email=format_data.email
    let user_password=format_data.password
    let user_type=format_data.user_type
    let user_login_status= await login_User(user_email,user_password,user_type)
    if(user_login_status==1)
    {
        let ipAddress=req.ip
        await storeLogin(ipAddress,user_email,user_type)
        res.send(JSON.stringify({"error":0}))
    }
    if(user_login_status==2)
    {
        res.send(JSON.stringify({"error":1}))
    }
    if(user_login_status==3)
    {
        res.send(JSON.stringify({"error":2}))
    }
}

/* the function below is used to use a users email to get their details*/
async function get_email(email,user_type) {

    let database_type="Teachers_profile"
    if(user_type=="student")
    {
        database_type="Student_profile"
    }
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: database_type,
        IndexName: "email-index",
        KeyConditionExpression: "email = :mail",
        ExpressionAttributeValues: {
            ":mail" : {S:email}
        }
    };
    try{
        let result = await documentClient.query(params).promise();
        return JSON.stringify(result)
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}


/* The function below is used to sign in a user if the information which they sent is correct*/
async function login_User(email,password,user_type)
{
    let existing_user= await find_email(email,user_type)
    if(existing_user>0)
    {
        let current_email=await get_email(email,user_type)
        let process_data= JSON.parse(current_email)
        let user_password=process_data["Items"][0]["password"]["S"]
        if(password==user_password)
        {
            return 1
        }
        if(password!=user_password)
        {
            return 2
        }
    }
    else{
        return 3
    }    
}

/* the function below is used to store the users ip address into a dynamoDB database when they sign in*/
async function storeLogin(ipAddress,Email,user_type) {
    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Login_userpool",
        Item: {
            "Users_email": {S:Email},
            "Users_ip": {S:ipAddress},
            "User_type":{S:user_type}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.putItem(params).promise();
        console.log("Data uploaded successfully: " + JSON.stringify(result));
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* the function below is used to check if the users email is present in the databases storing the teachers details or the students details*/
async function find_email(email,user_type) {
    let database_type="Teachers_profile"
    if(user_type=="student")
    {
        database_type="Student_profile"
    }
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: database_type,
        IndexName: "email-index",
        KeyConditionExpression: "email = :mail",
        ExpressionAttributeValues: {
            ":mail" : {S:email}
        }
    };
    //Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        let resuls_data=result
        return resuls_data.Count
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* the function below is used to get the users email and ip address if the current device has an account signed into the platform*/
async function get_userpool(ipAddr) {

    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Login_userpool",
        KeyConditionExpression: "Users_ip=:ipAddr",
        ExpressionAttributeValues: {
            ":ipAddr" : {S:ipAddr}
        }
    };
//Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        return JSON.stringify(result)
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* the function below is used check if the current device accessing the platform has a user that has signed into the platform*/
async function check_login(ipAddr)
{
    let user_data=await get_userpool(ipAddr)
    let format_data=JSON.parse(user_data)
    let user_found =format_data.Count
    if(user_found>0)
    {
        let user_email=format_data.Items[0]["Users_email"]["S"]
        let user_type=format_data.Items[0]["User_type"]["S"]
        let user_logged=JSON.stringify({"status":1,"mail":user_email,"type":user_type})
        return user_logged
    }
    else{
        let user_logged=JSON.stringify({"status":0})
        return user_logged
    }
}

/* the function below is used to check if the user is already signed into the  platform*/
async function verify_login(req,res)
{
    let ipAddress=req.ip
    let current_status= await check_login(ipAddress)
    res.send(current_status)
}

/* the function below is used to handle the request which gets the users details for their profile*/
async function profile_details(req,res)
{
    let user_data=JSON.stringify(req.body)
    let format_data=JSON.parse(user_data)
    let user_email=format_data.email
    let user_type=format_data.user_type
    let user_details=await get_email(user_email,user_type)
    let details=JSON.parse(user_details)
    let details_found={}
    if(user_type=="teacher")
    {
        let name_found=details.Items[0]["users_name"]["S"]
        let picture_found=details.Items[0]["profile_picture"]["S"]
        let description_found=details.Items[0]["description"]["S"]
        let numer_of_ratings=Number(details.Items[0]["numer_of_ratings"]["N"])
        let total_ratings=Number(details.Items[0]["total_ratings"]["N"])
        let find_rating = total_ratings/numer_of_ratings
        let teachers_rating = find_rating.toFixed(1)
        let current_rating= `RATING: ${teachers_rating}`
        if(numer_of_ratings==0)
        {
            current_rating="RATING: No ratings"
        }
        details_found=JSON.stringify({"user_name":name_found,"description":description_found,"picture":picture_found,"ranking":current_rating})
    }
    if(user_type!="teacher")
    {
        let name_found=details.Items[0]["user_name"]["S"]
        details_found=JSON.stringify({"user_name":name_found})
    }

    res.send(details_found)
}

/* the function below is used to handle the request which logout the user*/
async function logout(req,res)
{
    let user_data=JSON.stringify(req.body)
    let format_data=JSON.parse(user_data)
    let user_email=format_data.email
    let ipAddress=req.ip
    await remove_user(user_email,ipAddress)
    res.send(JSON.stringify({"page":"logout"}))

}

/* the function below is used to remove a users ip address and email from the database containing the users logged into the platform when they log out*/
async function remove_user(email,ipAddr){
    //Table name and data for table
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    let params = {
        TableName: "Login_userpool",
        Key: {

            "Users_email": {S:email},
            "Users_ip": {S:ipAddr}
        }
    }
    //Delete data from DynamoDB and handle errors
    try {
        let result = await documentClient.deleteItem(params).promise();
        console.log("Data deleted successfully: " + JSON.stringify(result));
    } catch (err) {
        console.error("ERROR deleting data: " + err);
    }
}

/* The function below is used to handle the request which uploads a video to a specific users S3 Bucket folder */
async function upload_media(req,res)
{
    const fileContent = fs.readFileSync(req.file.path);
    let files_name=req.file.originalname
    let user_data=await get_userpool(req.ip)
    let format_data=JSON.parse(user_data)
    let user_email=format_data.Items[0]["Users_email"]["S"]
    let files_key=`users/teachers/${user_email}/videos/${files_name}`
    let file_extension=path.extname(files_name)

    /*Checking if the file being uploaded is in the right format in this case mp4
    if it is in the right format it is uploaded to S3 Bucket and a success message is sent back to the user
    if it is in the wrong format it is not uploaded and an error message is sent back
    */
    if(file_extension==".mp4")
    {
        uploadFile(files_key,fileContent)
        res.send(JSON.stringify({"error":0}))
    }
    else{
        res.send(JSON.stringify({"error":1}))
    }
}

/* The function below is used to handle the request which uploads a video thumbnail to a specific users S3 Bucket folder */
async function upload_picture(req,res)
{
    const fileContent = fs.readFileSync(req.file.path);
    let files_name=req.file.originalname
    let user_data=await get_userpool(req.ip)
    let format_data=JSON.parse(user_data)
    let user_email=format_data.Items[0]["Users_email"]["S"]
    let files_key=`users/teachers/${user_email}/thumbnails/${files_name}`

    /*Checking if the file being uploaded is in the right format in this case png, jpeg or jpg
    if it is in the right format it is uploaded to S3 Bucket and a success message is sent back to the user
    if it is in the wrong format it is not uploaded and an error message is sent back
    */
    let file_extension=path.extname(files_name)
    if(file_extension==".png" || file_extension==".jpg" || file_extension==".jpeg")
    {
        uploadFile(files_key,fileContent)
        res.send(JSON.stringify({"error":0}))
    }
    else{
        res.send(JSON.stringify({"error":1}))
    }
    
}

/* The function below is used to upload a given file to a specific users S3 Bucket folder */
function uploadFile(files_key,fileContent) {
    const s3 = new AWS.S3();
    const params = {
        Bucket: 'cst3990-c0ursew0rk-2-tut0ringp1ug',
        Key: files_key,
        Body: fileContent
    };
    // Upload the file to the bucket
    s3.upload(params, function(err, data) {
        if (err) {
            console.log("Error uploading file: ", err);
        } else {
            console.log("File uploaded successfully. File location: ", data.Location);
        }
    })
}

/* The function below is used to handle the request which stores a the details of a video when a teacher uploads it*/
async function final_upload(req,res)
{
    let user_data=JSON.stringify(req.body)
    let format_data=JSON.parse(user_data)
    let description=format_data.description
    let title=format_data.title
    let vidoe_name=format_data.vidoe_name
    let image_name=format_data.image_name
    let email=format_data.email
    let format_email = email.replace("@", "%40")
    let video_key=`https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/users/teachers/${format_email}/videos/${vidoe_name}`
    let image_key=`https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/users/teachers/${format_email}/thumbnails/${image_name}`
    const uniqueId = () => uuidv4();
    storeVideo(title,description,video_key,image_key,uniqueId(),email)
    res.send(JSON.stringify({"status":"success"}))
}

/* The function below is used to store the videos details to dynamoDB*/
async function storeVideo(title,description,video_url,thumbnail_url,identification,owner_email)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Video_details",
        Item: {
            "Name": {S:title},
            "Video_id": {S:identification},
            "description":{S:description},
            "video_url":{S:video_url},
            "thumbnail_url":{S:thumbnail_url},
            "owner_email":{S:owner_email},
            "good_apples":{N:"0"},
            "bad_apples":{N:"0"}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.putItem(params).promise();
        console.log("Data uploaded successfully: " + JSON.stringify(result));
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to get a specific teachers videos. */
async function user_videos(userId)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    //Table name and data for table
    let params = {
        TableName: "Video_details",
        IndexName: "owner_email-index",
        KeyConditionExpression: "owner_email=:userId",
        ExpressionAttributeValues: {
            ":userId" : {S:userId}
        }
    };

//Gets a single item

    try{
        let result = await documentClient.query(params).promise();
        console.log("Successful get Item: ");
        console.log(JSON.stringify(result));
        let resuls_data=result
        return JSON.stringify(result)
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }   
}

/* The function below is used to get a specific video based on it's id*/
async function get_video(userId)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Video_details",
        IndexName: "Video_id-index",
        KeyConditionExpression: "Video_id=:userId",
        ExpressionAttributeValues: {
            ":userId" : {S:userId}
        }
    };

    try{
        let result = await documentClient.query(params).promise();
        return JSON.stringify(result)
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }   
}

/* The function below is used to get all the videos of a specific teacher based on their email*/
async function all_videos(userId)
{
    let data_found= await user_videos(userId)
    let format_data=JSON.parse(data_found)
    let videos=format_data.Items
    let videos_obj=[]
    for(let i=0;i<videos.length;i++)
    {
        let current_video={
            "thumbnail_url":videos[i]["thumbnail_url"]["S"],
            "Name":videos[i]["Name"]["S"],
            "Video_id":videos[i]["Video_id"]["S"],
            "description":videos[i]["description"]["S"],
            "bad_apples":videos[i]["bad_apples"]["N"],
            "good_apples":videos[i]["good_apples"]["N"],
            "video_url":videos[i]["video_url"]["S"]
        }
        videos_obj.push(current_video)
    }
    return JSON.stringify(videos_obj)
}

/* The function below is used to get a specific video based on its id.*/
async function specified_video(userId)
{
    let data_found= await get_video(userId)
    let format_data=JSON.parse(data_found)
    let videos=format_data.Items
    let videos_obj=[]
    for(let i=0;i<videos.length;i++)
    {
        let current_video={
            "thumbnail_url":videos[i]["thumbnail_url"]["S"],
            "Name":videos[i]["Name"]["S"],
            "Video_id":videos[i]["Video_id"]["S"],
            "description":videos[i]["description"]["S"],
            "bad_apples":videos[i]["bad_apples"]["N"],
            "good_apples":videos[i]["good_apples"]["N"],
            "video_url":videos[i]["video_url"]["S"]
        }
        videos_obj.push(current_video)
    }
    console.log(JSON.stringify(videos_obj))
    
    return JSON.stringify(videos_obj)
}

/* The function below is used to handle the request which get all the videos of a specific teacher.*/
async function teachers_videos(req,res)
{
    let user_data=JSON.stringify(req.body)
    let format_data=JSON.parse(user_data)
    let users_vids= await all_videos(format_data.email)
    res.send(users_vids)
}

/* The function below is used to handle the request which get all the details of a specific video.*/
async function video_body(req,res)
{
    let user_data=JSON.stringify(req.body)
    let format_data=JSON.parse(user_data)
    let users_vids= await specified_video(format_data.video_id)
    let vid_details =JSON.parse(users_vids)
    vid_details.video_url
    let html=format_video(vid_details.video_url,vid_details.Name,vid_details.description)
    res.send(html)

}

/* The function below is used to get the names of teachers based on their user name.*/
async function searching_word(searchWord)
{
    console.log("SEARCH QUERY: "+searchWord)
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    const params = {
        TableName: "Teachers_profile",
        FilterExpression: 'contains(#attr, :value)',
        ExpressionAttributeNames: {'#attr': 'users_name'},
        ExpressionAttributeValues: {':value': {'S': searchWord}}
      };
      
    try{
        let result = await documentClient.scan(params).promise();
        return JSON.stringify(result)
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }  
}

/* The function below is used to the details of a specific video based on the name of the video. */
async function searching_video(searchWord)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    const params = {
        TableName: "Video_details",
        FilterExpression: 'contains(#attr, :value)',
        ExpressionAttributeNames: {'#attr': 'Name'},
        ExpressionAttributeValues: {':value': {'S': searchWord}}
      };
      
    try{
        let result = await documentClient.scan(params).promise();
        return JSON.stringify(result)
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* The function below is used to  handle the request which finds users with a given name*/
async function teacher_search(req,res)
{
    let queryDetais= req.params
    let search_results= await searching_word(queryDetais.search_query)
    let format_results= JSON.parse(search_results)
    let store_results=[]
    let results_found=format_results.Items
    for(let i=0;i<results_found.length;i++)
    {
        let numer_of_ratings=Number(results_found[i]["numer_of_ratings"]["N"])
        let total_ratings=Number(results_found[i]["total_ratings"]["N"])
        let find_rating = total_ratings/numer_of_ratings
        let teachers_rating = find_rating.toFixed(1)
        let current_rating= `RATING: ${teachers_rating}`
        if(numer_of_ratings==0)
        {
            current_rating="RATING: No ratings"
        }
        let result_obj={"users_name":results_found[i]["users_name"]["S"],"profile_picture":results_found[i]["profile_picture"]["S"],"subject":results_found[i]["subject"]["S"],"email":results_found[i]["email"]["S"],"ranking":current_rating}
        store_results.push(result_obj)
    }
    res.send(JSON.stringify(store_results))

}

/* The function below is used to  handle the request which finds videos with the given name*/
async function video_search(req,res)
{
    let queryDetais= req.params
    let search_results= await searching_video(queryDetais.search_query)
    let format_results= JSON.parse(search_results)
    let store_results=[]
    let results_found=format_results.Items
    for(let i=0;i<results_found.length;i++)
    {
        let teacher_data= await get_email(results_found[i]["owner_email"]["S"])
        let format_teach= JSON.parse(teacher_data)
        let all_teach_data= format_teach.Items
        let numer_of_ratings=Number(all_teach_data[0]["numer_of_ratings"]["N"])
        let total_ratings=Number(all_teach_data[0]["total_ratings"]["N"])
        let find_rating = total_ratings/numer_of_ratings
        let teachers_rating = find_rating.toFixed(1)
        let current_rating= `RATING: ${teachers_rating}`
        if(numer_of_ratings==0)
        {
            current_rating="RATING: No ratings"
        }
         let current_video={
            "thumbnail_url":results_found[i]["thumbnail_url"]["S"],
            "Name":results_found[i]["Name"]["S"],
            "Video_id":results_found[i]["Video_id"]["S"],
            "description":results_found[i]["description"]["S"],
            "bad_apples":results_found[i]["bad_apples"]["N"],
            "good_apples":results_found[i]["good_apples"]["N"],
            "video_url":results_found[i]["video_url"]["S"],
            "owner_email":results_found[i]["owner_email"]["S"],
            "ranking":current_rating
        }
        store_results.push(current_video)
    }
    res.send(JSON.stringify(store_results))

}

/* The function below is used to create a message id*/
async function store_message_id(user_one,user_two) {

    const uniqueId = () => uuidv4();
    let message_id=`msg-${uniqueId()}`
    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Message_details",
        Item: {
            "message_id": {S:message_id},
            "user_one": {S:user_one},
            "user_two": {S:user_two}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.putItem(params).promise();
        return message_id
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to check if a message id has been created for a chat between two users*/
async function getMsgID(user_one,user_two)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    const params = {
        TableName: "Message_details",
        FilterExpression: '(contains(#attr, :value) AND contains(#attrTwo, :valueTwo)) OR (contains(#attr, :valueTwo) AND contains(#attrTwo, :value))',
        ExpressionAttributeNames: {
            '#attr': 'user_one',
            '#attrTwo': 'user_two'
        },
        ExpressionAttributeValues: {
            ':value': {'S': user_one},
            ':valueTwo': {'S': user_two},
        }
      };
      
    try{
        let result = await documentClient.scan(params).promise();
        return JSON.stringify(result)
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* The function below is used to get all the messages that a specific user is involved in based on their email.*/
async function get_my_messages(user_one)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    const params = {
        TableName: "Message_details",
        FilterExpression: '(contains(#attr, :value)) OR (contains(#attrTwo, :value))',
        ExpressionAttributeNames: {
            '#attr': 'user_one',
            '#attrTwo': 'user_two'
        },
        ExpressionAttributeValues: {
            ':value': {'S': user_one}
        }
      };
    try{
        let result = await documentClient.scan(params).promise();
        return JSON.stringify(result)
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* The function below is used to create or get the id of a chat between two specific users*/
async function set_MsgID(user_one,user_two)
{
    let msg_data= await getMsgID(user_one,user_two)
    let format_data = JSON.parse(msg_data)
    let items_found = parseInt(format_data.Count)
    if(items_found>0)
    {
        let msg_id=format_data.Items[0]["message_id"]["S"]
        return msg_id
    }
    else
    {
        let new_id= await store_message_id(user_one,user_two)
        return new_id
    }
}

/* The function below is used to store messages stored between two users*/
async function storeMessage(message_id,user_id,message)
{
    const unixTime = Math.floor(Date.now() / 1000); // divide by 1000 to convert from milliseconds to seconds
    console.log(unixTime); // prints the current Unix time in seconds
    let message_date=`${unixTime}`
    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Messages",
        Item: {
            "message_id": {S:message_id},
            "message_date": {N:message_date},
            "user_id": {S:user_id},
            "message": {S:message},
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.putItem(params).promise();
        console.log("Data uploaded successfully: " + JSON.stringify(result));
        return message_id
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
    
}

/* The function below is used to handle the request which stores the messages sent between two users.*/
async function sendMessage(sender_id,receiver_id,message)
{
    let message_id= await set_MsgID(sender_id,receiver_id)
    storeMessage(message_id,sender_id,message)
}

/* The function below is used to get the username of a specific user*/
async function get_users_names(user_email)
{
    let table_name="Teachers_profile"
    let name_field ="users_name"
    let table_checker= await find_email(user_email)
    if(table_checker==0)
    {
        table_name= "Student_profile"
        name_field ="user_name"
    }
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: table_name,
        IndexName: "email-index",
        KeyConditionExpression: "email = :mail",
        ExpressionAttributeValues: {
            ":mail" : {S:user_email}
        }
    };
    //Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        let resuls_data=JSON.stringify(result)
        let transform_data =JSON.parse(resuls_data)
        let name_found=transform_data["Items"][0][name_field]["S"]
        return name_found
    }
    catch(err){
        console.error("Get Error:", err)
    }
}

/* The function below is used to all the details of the chats that a user is a part of.*/
async function users_chats(user_email)
{
    let chats_data= await get_my_messages(user_email)
    let my_chats= JSON.parse(chats_data)
    let all_messages=my_chats.Items
    let message_details=[]
    for(let i=0;i<all_messages.length;i++)
    {
        let message_id=all_messages[i]["message_id"]["S"]
        let other_name=all_messages[i]["user_one"]["S"]
        if(user_email==other_name)
        {
            other_name=all_messages[i]["user_two"]["S"]
        }
        let second_name= await get_users_names(other_name)
        let details_obj={
            "message_id": message_id,
            "other_name": second_name,
            "email":user_email,
            "receiver_id":other_name
        }
        message_details.push(details_obj)
    }
    return JSON.stringify(message_details)
}

/* The function below is used to get certain messages sent between two users based on the id of the chats*/
async function get_chat(message_id)
{
    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Messages",
        IndexName: "message_id-message_date-index",
        KeyConditionExpression: "message_id=:msg_id",
        ExpressionAttributeValues: {
            ":msg_id" : {S:message_id}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.query(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
    
}

/* The function below is used to get all the messages between two users and format them correctly.*/
async function users_messages(message_id)
{
    let chats_data= await get_chat(message_id)
    let my_chats= JSON.parse(chats_data)
    let all_messages=my_chats.Items
    let message_details=[]
    let msg_obj={"message_id":message_id}
    message_details.push(msg_obj)
    for(let i=0;i<all_messages.length;i++)
    {
        let other_name=all_messages[i]["user_id"]["S"]
        let message_date= parseInt(all_messages[i]["message_date"]["N"])
        let message= all_messages[i]["message"]["S"]
        let second_name= await get_users_names(other_name)
        let details_obj={
            "other_name": second_name,
            "message_date":message_date,
            "message":message
        }
        message_details.push(details_obj)
    }
    return JSON.stringify(message_details)

}

/* The function below is used to handle the request which gets all the other users that the user has started messaging.*/
async function my_messages(req,res)
{
    let users_data= req.body
    let user_email=users_data.email
    let all_chats= await users_chats(user_email)
    res.send(all_chats)
}

/* The function below is used to handle the request which gets all the messages between two users.*/
async function chat_messages(req,res)
{
    let users_data= req.body
    let message_id=users_data.message_id
    let all_chats= await users_messages(message_id)
    res.send(all_chats)
}

/* The function below is used to send new messages to all users and store new messages.*/
async function send_message(req,res)
{
    let users_data = req.body
    sendMessage(users_data.sender_id,users_data.receiver_id,users_data.message)
}

/* The function below is used to handle the request which initiates a message between two users it will either get the id for all
the messages between two users or create a new id for the messages between two users*/
async function set_up_messaging(req,res)
{
    let users_data= req.body
    let user_one=users_data.user_one
    let user_two=users_data.user_two
    console.log("body: "+JSON.stringify(users_data))
    console.log("user_one: "+user_one)
    console.log("user_two: "+user_two)
    
    let message_id=await set_MsgID(user_one,user_two)
    let msg_obj= JSON.stringify({"message_id":message_id})
    console.log("msg_obj: "+msg_obj)
    res.send(msg_obj)
}

/* The function below is used to set up a request for a student that would like tutoring sessions.*/
async function set_request(student_id,teacher_id)
{
    const uniqueId = () => uuidv4();
    let request_id=`request-${uniqueId()}`
    const unixTime = Math.floor(Date.now() / 1000); // divide by 1000 to convert from milliseconds to seconds
    let request_date=`${unixTime}`
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Student_requests",
        Item: {
            "student_request_id": {S:request_id},
            "request_date": {N:request_date},
            "student_id": {S:student_id},
            "teacher_id": {S:teacher_id},
            "current_status": {N:'0'}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.putItem(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to handle the request which lets students to request for lessons from teachers*/
async function make_request(req,res)
{
    let users_data= req.body
    await set_request(users_data.student_id,users_data.teacher_id)
    res.send(JSON.stringify({"request_made":"success"}))

}

/* The function below is used to get for teachers all requests that students had sent to them from the database.*/
async function find_requests(email)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Student_requests",
        IndexName: "teacher_id-request_date-index",
        KeyConditionExpression: "teacher_id=:tutor",
        ExpressionAttributeValues: {
            ":tutor" : {S:email}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.query(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to get and format all the requests which have been sent to a specific teacher based on their email.*/
async function all_requests(email)
{
    let user_data= await find_requests(email)
    let format_data = JSON.parse(user_data)
    let all_items = format_data.Items
    let all_results=[]
    for(let i=0;i<all_items.length;i++)
    {
        let teacher_id=all_items[i]["teacher_id"]["S"]
        let student_id=all_items[i]["student_id"]["S"]
        let student_request_id=all_items[i]["student_request_id"]["S"]
        let unixTimestamp=parseInt(all_items[i]["request_date"]["N"])
        let status=parseInt(all_items[i]["current_status"]["N"])
        let student_name= await get_users_names(student_id)
        let date = new Date(unixTimestamp * 1000);
        // Format the date and time
        let formattedDate = date.toLocaleDateString();
        let formattedTime = date.toLocaleTimeString();  
        if(status==0)
        {
            all_results.push({"student_name":student_name,
            "student_request_id":student_request_id,
            "formattedDate":formattedDate,
            "formattedTime":formattedTime,
            "unixTimestamp":unixTimestamp,
            "teacher_id":teacher_id,
            "student_id":student_id })
        }
    }
    return JSON.stringify(all_results)
}

/* The function below is used to handle the request which gets all the requests that a teacher has been sent by students.*/
async function get_requests(req,res)
{
    let users_data= req.body
    let user_data= await all_requests(users_data.email)
    res.send(user_data)
}

/* The function below is used to update a teachers decision about a students request.*/
async function update_status(req_id,req_date,new_status)
{
    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    let status=String(new_status)
    let request_date=String(req_date)
    //Table name and data for table
    let params = {
        TableName: "Student_requests",
        Key: {
            "student_request_id":{S:req_id},
            'request_date': { N: request_date }
        },
        UpdateExpression: 'set current_status= :status',
        ExpressionAttributeValues: {
            ":status" : {N:status}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.updateItem(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
    
}

/* The function below is used to set a session when a teacher decides to tutor a student*/
async function set_session(student_id,teacher_id,sessions_left)
{
    const uniqueId = () => uuidv4();
    let session_id=`session-${uniqueId()}`
    //Create new DocumentClient
    let format_sessions_left= String(sessions_left)
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Teaching_sessions",
        Item: {
            "teaching_session_id": {S:session_id},
            "student_id": {S:student_id},
            "teacher_id": {S:teacher_id},
            "sessions_left": {N:format_sessions_left},
            "rank_given": {N:'0'}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.putItem(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to handle the request which handles decisions made by teachers about whether or not a students has been
allowed to be tutored by the given teacher.*/
async function handle_request(req,res)
{
    let users_data= req.body
    let req_id=users_data.req_id
    let req_date=users_data.req_date
    let new_status=users_data.new_status
    let student_id=users_data.student_id
    let teacher_id=users_data.teacher_id
    let format_status =parseInt(new_status)
    update_status(req_id,req_date,new_status)
    if(format_status==1)
    {
        set_session(student_id,teacher_id,8)
    }
    res.send(JSON.stringify({"success":"done"}))
}

/* The function below is used to set a meeting between a student from a teacher.*/
async function set_meeting(student_id,teacher_id,meeting_date,meeting_name,meeting_time,teaching_session_id)
{
    const uniqueId = () => uuidv4();
    let meeting_id =`meeting-${uniqueId()}`
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Meetings",
        Item: {
            "meeting_id": {S:meeting_id },
            "meeting_date": {S:meeting_date},
            "meeting_time": {S:meeting_time},
            "student_id": {S:student_id},
            "teacher_id": {S:teacher_id},
            "meeting_name": {S:meeting_name},
            "fulfiled_status": {N:'0'},
            "teaching_session_id":{S:teaching_session_id}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.putItem(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to get all the students under a teacher from the dynamoDb database.*/
async function get_students(email)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Teaching_sessions",
        IndexName: "teacher_id-index",
        KeyConditionExpression: "teacher_id=:tutor",
        ExpressionAttributeValues: {
            ":tutor" : {S:email}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.query(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to handle the request which schedules a meeting between a student and a teacher and store this in the database.*/
async function store_meeting(req,res)
{
    let user_data=req.body
    let student_id=user_data.student_id
    let meeting_date=user_data.meeting_date
    let meeting_name=user_data.meeting_name
    let meeting_time=user_data.meeting_time
    let teacher_id=user_data.teacher_id
    let teaching_session_id=user_data.teaching_session_id
    await set_meeting(student_id,teacher_id,meeting_date,meeting_name,meeting_time,teaching_session_id)
    res.send(JSON.stringify({"success":"done"}))
}

/* The function below is used to handle the request which gets all the teachers under a student.*/
async function teachers_students(req,res)
{
    let user_data=req.body
    let email=user_data.email
    let students= await get_students(email)
    let format_students = JSON.parse(students)
    let student_list= format_students.Items
    let all_students =[]
    for(let i=0;i<student_list.length;i++)
    {
        let student_id=student_list[i]["student_id"]["S"]
        let teacher_id=student_list[i]["teacher_id"]["S"]
        let sessions_left=student_list[i]["sessions_left"]["N"]
        let teaching_session_id=student_list[i]["teaching_session_id"]["S"]
        let student_name=await get_users_names(student_id)
        let checker= parseInt(sessions_left)
        if(checker>0)
        {
            let session_data={"student_id":student_id,"teacher_id":teacher_id,"teaching_session_id":teaching_session_id,"student_name":student_name,"sessions_left":sessions_left}
            all_students.push(session_data)
        }
    }
    res.send(JSON.stringify(all_students))
}

/* The function below is used to get all the meetings that a student had with a teacher from the dynamoDb database.*/
async function get_meeting(email)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Meetings",
        IndexName: "student_id-index",
        KeyConditionExpression: "student_id=:id",
        ExpressionAttributeValues: {
            ":id" : {S:email}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.query(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to handle the request which gets all the meetings that a student has with their teacher.*/
async function students_meetings(req,res)
{
    let user_data=req.body
    let email=user_data.email

    let data_found= await get_meeting(email)
    let format_meetings = JSON.parse(data_found)
    let meetings = format_meetings.Items
    let all_meetings=[]
    for(let i=0;i<meetings.length;i++)
    {
        let meeting_date=meetings[i]["meeting_date"]["S"]
        let meeting_name=meetings[i]["meeting_name"]["S"]
        let teacher_id=meetings[i]["teacher_id"]["S"]
        let teachers_name=await get_users_names(teacher_id)
        let student_id=meetings[i]["student_id"]["S"]
        let meeting_id=meetings[i]["meeting_id"]["S"]
        let meeting_time=meetings[i]["meeting_time"]["S"]
        let fulfiled_status=meetings[i]["fulfiled_status"]["N"]
        let teaching_session_id=meetings[i]["teaching_session_id"]["S"]
        let formated_status=parseInt(fulfiled_status)
        if(formated_status==0)
        {
            all_meetings.push({"meeting_date":meeting_date,"meeting_name":meeting_name,"teacher_id":teacher_id,"student_id":student_id,"meeting_id":meeting_id,"meeting_time":meeting_time,"teachers_name":teachers_name,"teaching_session_id":teaching_session_id})
        }
    }
    res.send(JSON.stringify(all_meetings))
}

/* The function below is used to update the students decision about whether they confirm if a meeting took place and store this in the dynamoDb database*/
async function update_meetings(meeting_id ,new_status)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    let status=String(new_status)
    //Table name and data for table
    let params = {
        TableName: "Meetings",
        Key: {
            "meeting_id":{S:meeting_id}
        },
        UpdateExpression: 'set fulfiled_status= :status',
        ExpressionAttributeValues: {
            ":status" : {N:status}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.updateItem(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to handle the request which updates the students decision about whether or not a meeting took place*/
async function student_decision(req,res)
{
    let user_data=req.body
    let meeting_id=user_data.meeting_id
    let new_status=user_data.new_status
    let teaching_session_id=user_data.teaching_session_id
    let current_status = parseInt(new_status)
    if(current_status==1)
    {
        update_meetings(meeting_id ,new_status)
        set_decision(teaching_session_id)
    }
    update_meetings(meeting_id ,new_status)
    res.send(JSON.stringify({"success":"done"}))
}

/* The function below is used to get a tutoring session with a specific id*/
async function get_session(session_id)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Teaching_sessions",
        KeyConditionExpression: "teaching_session_id=:id",
        ExpressionAttributeValues: {
            ":id" : {S:session_id}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.query(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to reduce the number of sessions that a student has with a teacher when a student accepts that a tutotring session took place.*/
async function set_decision(session_id)
{
    let data_found = await get_session(session_id)
    let session_data = JSON.parse(data_found)
    let all_data = session_data.Items
    let sessions_left= parseInt(all_data[0]["sessions_left"]["N"])
    let new_sessions = sessions_left-1
    await update_sessions(session_id ,new_sessions)
}

/* The function below is used to update the new number of sessions the a student has with a teacher.*/
async function update_sessions(session_id ,new_sessions)
{
    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    let sessions=String(new_sessions)
    //Table name and data for table
    let params = {
        TableName: "Teaching_sessions",
        Key: {
            "teaching_session_id":{S:session_id}
        },
        UpdateExpression: 'set sessions_left= :remmaining',
        ExpressionAttributeValues: {
            ":remmaining" : {N:sessions}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.updateItem(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to get all the sessions that a student had with a teacher from the dynamoDb database.*/
async function students_teachers(email){
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Teaching_sessions",
        IndexName: "student_id-index",
        KeyConditionExpression: "student_id= :mail",
        ExpressionAttributeValues: {
            ":mail" : {S:email}
        }
    };
    //Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        return JSON.stringify(result)
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* The function below is used to handle the request which gets all the sessions that a student had with a teacher.*/
async function get_students_teachers(req,res)
{
    let data_sent=req.body
    let email=data_sent.email
    let user_data=await students_teachers(email)
    let format_data= JSON.parse(user_data)
    let all_data=format_data.Items
    let unranked=[]
    for(let i=0;i<all_data.length;i++)
    {
        let string_rank =all_data[i]["rank_given"]["N"]
        let rank= parseInt(string_rank)
        let teaching_session_id =all_data[i]["teaching_session_id"]["S"]
        let teacher_id =all_data[i]["teacher_id"]["S"]
        let teachers_name=await get_users_names(teacher_id)
        let student_id =all_data[i]["student_id"]["S"]
        if(rank==0)
        {
            unranked.push({"teaching_session_id":teaching_session_id,"teacher_id":teacher_id,"student_id":student_id,"teachers_name":teachers_name})
        }
    }
    res.send(JSON.stringify(unranked))
}

/* The function below is used to mark a session as rated after it has been given a rating. After marking it the session will not be displayed to the student again.*/
async function session_ranking(session_id ,rank_given)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    let ranking = String(rank_given)
    //Table name and data for table
    let params = {
        TableName: "Teaching_sessions",
        Key: {
            "teaching_session_id":{S:session_id}
        },
        UpdateExpression: 'set rank_given= :rank',
        ExpressionAttributeValues: {
            ":rank" : {N:ranking}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.updateItem(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
    
}

/* The function below is used to handle the request which gives a ranking to a tutoring session that a student had with a teacher.*/
async function update_ranking(req,res)
{
    let user_data=req.body
    let email=user_data.email
    let new_rating=Number(user_data.new_rating)
    let session_id=user_data.teaching_session_id
    let teacher_details= await get_email(email)
    let formated_details=JSON.parse(teacher_details)
    let format_details = formated_details.Items
    let all_details = format_details[0]
    let total_ratings=all_details["total_ratings"]["N"]
    let numer_of_ratings=all_details["numer_of_ratings"]["N"]
    let users_name=all_details["users_name"]["S"]
    let rating_count= parseInt(numer_of_ratings)
    let rating_sum= parseInt(total_ratings)
    let new_rating_count=rating_count+1
    let new_rating_sum=rating_sum+new_rating
    await update_count(email,users_name,new_rating_count)
    await update_total(email,users_name,new_rating_sum)
    await  session_ranking(session_id ,1)
    res.send(JSON.stringify({"success":"done"}))
}

/* The function below is used to update the number of ratings given to a teacher.*/
async function update_count(email,users_name,new_sessions)
{
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    let sessions=String(new_sessions)
    //Table name and data for table
    let params = {
        TableName: "Teachers_profile",
        Key: {
            "email":{S:email},
            "users_name":{S:users_name}
        },
        UpdateExpression: 'set numer_of_ratings= :numb',
        ExpressionAttributeValues: {
            ":numb" : {N:sessions}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.updateItem(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to update the sum of ratings given to a teacher.*/
async function update_total(email,users_name,new_sessions)
{
    //Create new DocumentClient
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    let sessions=String(new_sessions)
    //Table name and data for table
    let params = {
        TableName: "Teachers_profile",
        Key: {
            "email":{S:email},
            "users_name":{S:users_name}
        },
        UpdateExpression: 'set total_ratings= :numb',
        ExpressionAttributeValues: {
            ":numb" : {N:sessions}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.updateItem(params).promise();
        return JSON.stringify(result)
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

module.exports = {handle_login,verify_login,profile_details,logout,upload_media,upload_picture,final_upload,teachers_videos,video_body,teacher_search,video_search,my_messages,chat_messages,send_message,set_up_messaging,make_request,get_requests,handle_request,teachers_students,store_meeting,students_meetings,student_decision,get_students_teachers,update_ranking}