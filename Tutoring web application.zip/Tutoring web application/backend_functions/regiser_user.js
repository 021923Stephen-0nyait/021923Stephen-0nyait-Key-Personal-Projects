/* This script is used to handle the handle the authenication of the teachers details.*/
//Link to AWS-SDK
const AWS = require("aws-sdk");

/* The function below is used to store a new teacher to the Teachers_profile dynamoDb database containing teachers data.*/
async function put_teacher_data(name,Phone,Subject,Email,password) {
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Teachers_profile",
        Item: {
            "users_name": {S:name},
            "email": {S:Email},
            "phone": {N:Phone},
            "subject":{S:Subject},
            "password": {S:password},
            "description":{S:`I teach ${Subject}`},
            "profile_picture":{S:""},
            "numer_of_ratings":{N:'0'},
            "total_ratings": {N:'0'}
        }
    }
    //Store data in DynamoDB and handle errors
    try {
        let result = await documentClient.putItem(params).promise();
        console.log("Data uploaded successfully: " + JSON.stringify(result));
    } catch (err) {
        console.error("ERROR uploading data: " + err);
    }
}

/* The function below is used to check if a specific teachers email exists in the Teachers_profile dynamoDb database.*/
async function find_email(email) {
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Teachers_profile",
        IndexName: "email-index",
        KeyConditionExpression: "email = :mail",
        ExpressionAttributeValues: {
            ":mail" : {S:email}
        }
    };
    //Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        let resuls_data=result
        return resuls_data.Count
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* The function below is used to see if there is a teacher with a certain user name in the Teachers_profile dynamoDb database.*/
async function find_name(name) {
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Teachers_profile",
        IndexName: "users_name-index",
        KeyConditionExpression: "users_name = :nom",
        ExpressionAttributeValues: {
            ":nom" : {S:name}
        }
    };
    //Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        let resuls_data=result
        return resuls_data.Count
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* The function below is used to see if there is a teacher with a certain phone number in the Teachers_profile dynamoDb database.*/
async function find_phone(phone) {
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Teachers_profile",
        IndexName: "phone-index",
        KeyConditionExpression: "phone = :number",
        ExpressionAttributeValues: {
            ":number" : {N:phone}
        }
    };
    //Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        let resuls_data=result
        return resuls_data.Count
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* The function below is used to get a the details of a teacher with a given email from Teachers_profile dynamoDb database.*/
async function get_email(email) {
    let documentClient = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    //Table name and data for table
    let params = {
        TableName: "Teachers_profile",
        IndexName: "email-index",
        KeyConditionExpression: "email = :mail",
        ExpressionAttributeValues: {
            ":mail" : {S:email}
        }
    };
    //Gets a single item
    try{
        let result = await documentClient.query(params).promise();
        return JSON.stringify(result)
    }
    catch(err){
        console.error("Get Error:", JSON.stringify(err))
    }
}

/* The function below is used to confirm that the details that the user sent are correct if they are it sends a number to indicate success.*/
async function login_User(email,password)
{
    let existing_user= await find_email(email)
    if(existing_user>0)
    {
        let current_email=await get_email(email)
        let process_data= JSON.parse(current_email)
        let user_password=process_data["Items"][0]["password"]["S"]
        if(password==user_password)
        {
            return 1
        }
        if(password!=user_password)
        {
            return 2
        }
    }
    else{
        return 3
    }    
}

module.exports = {find_email,find_name,find_phone,put_teacher_data,login_User}