window.onload = check_login()
let USERS_EMAIL = ""
let USER_TYPE ="teacher"

/*The function below is used to check if a user is signed in.*/
function check_login()
{
    handle_navigation('nav_schedule','scheduledg')
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":"",
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            let current_status = parseInt(transform_data.status)
            if( current_status == 1)
            {
                let uType=transform_data.type
                if(uType=="teacher")
                {
                    let mail=transform_data.mail
                    USERS_EMAIL=mail
                    show_students()
                }
                else
                {
                    window.location.href="/default/students_schedule"
                }                
            }
            if( current_status == 0)
            {
                window.location.href="/default/home"
            }
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/check_login", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/*The function below is used to store meeting details if the details passed in are correct*/
function schedules(student_id,teaching_session_id)
{
    let current_date=document.getElementById("submit_date").value
    let current_time=document.getElementById("submit_time").value
    let meeting_name=document.getElementById("meeting_name").value
    if(current_date!="" && current_time!="" && meeting_name!="")
    {
        set_meeting(student_id,USERS_EMAIL,current_date,meeting_name,current_time,teaching_session_id)
    }
    else
    {
        alert("ERROR: BLANK FIELD")
    }
}

/*The function below is used to send the meeting details to the database about meetings details*/
function set_meeting(student_id,teacher_id,meeting_date,meeting_name,meeting_time,teaching_session_id)
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "student_id":student_id,
        "meeting_date":meeting_date,
        "meeting_name":meeting_name,
        "meeting_time":meeting_time,
        "teacher_id":teacher_id,
        "teaching_session_id":teaching_session_id
    };
    console.log("reqssbody: "+JSON.stringify(users_data))
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("SUCCESSFUL: CLASS SCHEDULED")
            
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
        alert("ERROR: CLASS NOT SCHEDULED")
    }
    //Send new user data to server
    xhttp.open("POST", "/default/store_meeting", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(users_data));
}

/* The function below is used to show a teacher all the students that a teacher owes sessions to.*/
function show_students()
{
    //Create object with user data
    let doc_results=document.getElementById("all_results")
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":USERS_EMAIL
    };
    let all_results=`
    <div>
        <div>
            <a href="/default/schedule"><button class="upload_btn" >VIEW REQUESTS</button></a>
        </div>
    </div>
    `
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            for(let i=0;i<transform_data.length;i++)
            {
                let student_name=transform_data[i].student_name
                let teaching_session_id=transform_data[i].teaching_session_id
                let student_id=transform_data[i].student_id
                let sessions_left=transform_data[i].sessions_left

                all_results+=`
                <div class="search_results_found">
                    <div>
                        <div class="results">
                            <div><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/profile.png" alt="" class="results_picture"></div>
                            <div>
                                <h3>NAME: ${student_name}</h3>
                                <h3>SESSIONS LEFT: ${sessions_left}</h3>
                                
                            </div>
                            <div style="padding-top: 10px;">
                                <button class="upload_btn" onclick="make_meeting('${student_id}','${teaching_session_id}')">SCHEDULE CLASS</button>
                            </div>
                        </div>
                    </div>
                </div>
                `

            }
            doc_results.innerHTML=all_results
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/teachers_students", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/*The function below is used to display the page where teachers will be able to create meetings.*/
function make_meeting(student_id,teaching_session_id)
{
    let add_schedule=document.getElementById("all_results")

    let scheduling=`
    <div class="search_results_found">
        <div>
            <div class="results">
                <div><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/profile.png" alt="" class="results_picture"></div>
                <div class="schedule_class">
                    <div><div><h5>MEETING DATE:</h5></div><div><input type="date"  id="submit_date" class="input_details"></div></div>
                    <div><div><h5>MEETING NAME</h5></div><div><input type="text" id="meeting_name" class="input_details"></div></div>
                    <div><div><h5>MEETING TIME</h5></div><div><input type="time" id="submit_time" class="input_details"></div></div>
                </div>
                <div style="padding-top: 10px;">
                    
                    <button class="upload_btn" onclick="schedules('${student_id}','${teaching_session_id}')">SUBMIT</button>
                </div>
            </div>
        </div>
    </div>
    `
    add_schedule.innerHTML=scheduling
}

/*The function below is used to logout the users*/
function logout()
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":USERS_EMAIL,
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href="/default/home"
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/logout", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}
