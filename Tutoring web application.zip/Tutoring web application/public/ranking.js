window.onload = check_login()
let USERS_EMAIL = ""
let USER_TYPE ="teacher"

/*The function below is used to check if a user is signed in.*/
function check_login()
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":"",
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            let current_status = parseInt(transform_data.status)
            if( current_status == 1)
            {
                let uType=transform_data.type
                if(uType=="student")
                {
                    let mail=transform_data.mail
                    USERS_EMAIL=mail
                    show_sessions()
                }
                else
                {
                    window.location.href="/default/schedule"
                }
            }
            if( current_status == 0)
            {
                window.location.href="/default/home"
            }
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/check_login", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/* The function below is used to show all the tutoring sessions that a student had with a teacher. All the sessions showed were sessions
that a teacher did not rank.
*/
function show_sessions()
{
    //Create object with user data
    let doc_results=document.getElementById("all_results")
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":USERS_EMAIL
    };
    let all_results=`
    <div>
        <div>
            <a href="/default/students_schedule"><button class="upload_btn">VIEW CLASSES</button></a>
        </div>
        
    </div>
    `
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            for(let i=0;i<transform_data.length;i++)
            {
                let teachers_name=transform_data[i].teachers_name
                let teacher_id=transform_data[i].teacher_id
                let teaching_session_id=transform_data[i].teaching_session_id
                all_results+=`
                <div class="search_results_found">
                    <div>
                        <div class="results">
                            <div><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/profile.png" alt="" class="results_picture"></div>
                            <div>
                                <h3>TEACHERS NAME: ${teachers_name}</h3>
                                <div class="slidecontainer">
                                    <div>1<input type="range" min="1" max="5" value="2.5" class="slider" id="myRange" onclick="show_ranking()">5</div>
                                    <div id="current_rank">RANKING 3</div>
                                
                                </div>
                            </div>
                            <div style="padding-top: 10px;">
                                <button class="upload_btn" onclick="submit_ranking('${teaching_session_id}','${teacher_id}')">SUBMIT</button>
                                
                            </div>
                        </div>
                    </div>
                </div>
                `
            }
            doc_results.innerHTML=all_results
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/get_students_teachers", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/* The function below is used to submit a ranking that a student has given a tutoring session that they had with a tutor.*/
function submit_ranking(teaching_session_id,teacher_id)
{
    let rank_given=document.getElementById("myRange").value
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":teacher_id,
        "new_rating":rank_given,
        "teaching_session_id":teaching_session_id
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href="/default/ranking_page"
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/update_ranking", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/* The function below is used to update the current ranting on the slider when the slider is moved.*/
function show_ranking()
{
    let rank_given=document.getElementById("myRange").value
    document.getElementById("current_rank").innerHTML ="RANK GIVEN: "+rank_given
}


/*The function below is used to logout the users*/
function logout()
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":USERS_EMAIL,
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href="/default/home"
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/logout", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}
