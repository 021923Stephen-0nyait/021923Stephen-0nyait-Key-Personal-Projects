window.onload = check_login()
let USERS_EMAIL = ""
let USER_TYPE ="teacher"
let image_checker=0
let video_checker=0

/*The function below is used to check if a user is signed in.*/
function check_login()
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":"",
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            let current_status = parseInt(transform_data.status)
            if( current_status == 1)
            {
                let mail=transform_data.mail
                let uType=transform_data.type
                if(uType=="teacher")
                {
                    USERS_EMAIL=mail
                }
                else
                {
                    window.location.href="/default/home"
                }
            }
            if( current_status == 0)
            {
                window.location.href="/default/home"
            }
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/check_login", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/* The function below is used to upload details about a video to a dynamoDb database if all the information passed in is in the correct format*/
function upload_video_details()
{

    let vidoe_length=document.getElementById("get_video").files.length
    let image_length=document.getElementById("get_picture").files.length
    let theError=document.getElementById("error")
    if(vidoe_length!=0 && image_length!=0)
    {
        let image_path=document.getElementById("get_picture").files[0]
        let video_path=document.getElementById("get_video").files[0]
        let description=document.getElementById("video_description").value
        let title=document.getElementById("video_title").value
        let vidoe_name=video_path.name
        let image_name=image_path.name
        if(description!="" && title!="" && vidoe_name!="" && image_name!="" && video_checker==1 && image_checker==1)
        {
            let xhttp = new XMLHttpRequest();
            let users_data = {
                "vidoe_name":vidoe_name,
                "image_name":image_name,
                "description":description,
                "title":title,
                "email":USERS_EMAIL,
            };
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    theError.innerHTML ="SUCCESSFULL UPLOAD"
                }
            };
            xhttp.onerror=function(){
                console.log('Error occured') //Shows error if error occured
            }

            //Send new user data to server
            xhttp.open("POST", "/default/final_upload", true);
            xhttp.setRequestHeader("Content-type", "application/json");
            xhttp.send(JSON.stringify(users_data));
        }
        else
        {
            if(image_name=="")
            {
                theError.innerHTML ="ERROR: IMAGE NOT UPLOADED"
                
            }

            if(vidoe_name=="")
            {
                theError.innerHTML ="ERROR: VIDEO NOT UPLOADED"
            }

            if(title=="")
            {
                theError.innerHTML ="ERROR: EMPTY TITLE"
            }

            if(description=="")
            {
                theError.innerHTML ="ERROR: EMPTY DESCRIPTION"
            }
            if(video_checker==0)
            {
                theError.innerHTML ="ERROR: VIDEO NOT UPLOADED PRESS THE 'UPLOAD FILE' BUTTON"
            }
    
            if(image_checker==0)
            {
                theError.innerHTML ="ERROR: THUMBNAIL NOT UPLOADED PRESS THE 'UPLOAD FILE' BUTTON"
            }
        }
    }
    else
    {
        if(vidoe_length==0)
        {
            theError.innerHTML ="ERROR: VIDEO NOT UPLOADED"
        }

        if(image_length==0)
        {
            theError.innerHTML ="ERROR: IMAGE NOT UPLOADED"
        }
        if(video_checker==0)
        {
            theError.innerHTML ="ERROR: VIDEO NOT UPLOADED PRESS THE 'UPLOAD FILE' BUTTON"
        }

        if(image_checker==0)
        {
            theError.innerHTML ="ERROR: THUMBNAIL NOT UPLOADED PRESS THE 'UPLOAD FILE' BUTTON"
        }
    }
}

/*The function below is used to confirm that the user has clicked the upload video button*/
function update_video_checker()
{
    image_checker=1
}

/*The function below is used to confirm that the user has clicked the upload thumbnail button*/
function update_image_checker()
{
    video_checker=1
}


/*The function below is used to logout the users*/
function logout()
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":USERS_EMAIL,
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href="/default/home"
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/logout", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}