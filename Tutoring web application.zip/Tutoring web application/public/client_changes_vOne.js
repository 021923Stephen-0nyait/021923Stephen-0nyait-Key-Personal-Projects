function show_menu(button_id)
{
    let subject=document.getElementById(button_id).value
    console.log(subject)
    document.getElementById("menu").value=subject
}

function teacher_registration()
{

    let registration_form=`
    <div id="form_top">REGISTER</div>
    <div class="user_type">
        <div class="user_type_btns" id="occupation">
            <div id="user_type_two"><button class="type_btns" onclick="student_registration()">STUDENT</button></div>
            <div id="user_type_one"><button class="type_btns" onclick="teacher_registration()">TEACHER</button></div>
        </div>
    </div>
    <div class="subjects_section">
        <div id="drop">
            <button id="menu" onclick="console.log(value)">SELECT SUBJECT</button>
            <div id="menu_list">
                <div><button class="subjects" id="btn1" value="Math" onclick="show_menu('btn1')">MATH</button></div>
                <div><button class="subjects" id="btn2" value="Physics" onclick="show_menu('btn2')">PHYSICS</button></div>
                <div><button class="subjects" id="btn3" value="Chemistry" onclick="show_menu('btn3')">CHEMISTRY</button></div>
                <div><button class="subjects" id="btn4" value="Biology" onclick="show_menu('btn4')">BIOLOGY</button></div>
                <div><button class="subjects" id="btn5" value="English" onclick="show_menu('btn5')">ENGLISH</button></div>
                <div><button class="subjects" id="btn6" value="Literature" onclick="show_menu('btn6')">LITERATURE</button></div>
                <div><button class="subjects" id="btn7" value="Geography" onclick="show_menu('btn7')">GEOGRAPHY</button></div>
                <div><button class="subjects" id="btn8" value="History" onclick="show_menu('btn8')">HISTORY</button></div>
                <div><button class="subjects" id="btn9" value="Economics" onclick="show_menu('btn9')">ECONOMICS</button></div>
                <div><button class="subjects" id="btn10" value="Swahili" onclick="show_menu('btn10')">SWAHILI</button></div>
                <div><button class="subjects" id="btn11" value="Art" onclick="show_menu('btn11')">ART</button></div>
                <div><button class="subjects" id="btn12" value="Religion" onclick="show_menu('btn12')">RELIGION</button></div>
                <div><button class="subjects" id="btn13" value="Science" onclick="show_menu('btn13')">SCIENCE</button></div>
            </div>
        </div>
    </div>
    <div class="grid_components">NAME:</div>
    <div class="grid_components"><input type="text" class="input_feild" id ="name"></div>
    <div class="grid_components">EMAIL: </div>
    <div class="grid_components"><input type="text" class="input_feild" id ="email"></div>
    <div class="grid_components">PHONE:</div>
    <div class="grid_components"><input type="text" class="input_feild" id ="phone"></div>
    <div class="grid_components">PASSWORD:</div>
    <div class="grid_components"><input type="text" class="input_feild" id ="password"></div>
    <div class="grid_components">RE-ENTER PASSWORD:</div>
    <div class="grid_components"><input type="text" class="input_feild" id ="password_two"></div>

    <div id="submit" ><button id="submit_btn" type="submit" onclick="add_teacher()">SUBMIT</button><div id="error"></div></div>
    `
    document.getElementById("register_form").innerHTML=registration_form
}

function student_registration()
{

    document.getElementById("register_form").innerHTML=`
    <div id="form_top">REGISTER</div>
    <div class="user_type">
        <div class="user_type_btns">
            <div id="user_type_one"><button class="type_btns" onclick="student_registration()">STUDENT</button></div>
            <div id="user_type_two"><button class="type_btns" onclick="teacher_registration()">TEACHER</button></div>
        </div>
    </div>
    <div class="grid_components">NAME:</div>
    <div class="grid_components"><input type="text" class="input_feild" id ="name"></div>
    <div class="grid_components">EMAIL: </div>
    <div class="grid_components"><input type="text" class="input_feild" id ="email"></div>
    <div class="grid_components">PHONE:</div>
    <div class="grid_components"><input type="text" class="input_feild" id ="phone"></div>
    <div class="grid_components">PASSWORD:</div>
    <div class="grid_components"><input type="text" class="input_feild" id ="password"></div>
    <div class="grid_components">RE-ENTER PASSWORD:</div>
    <div class="grid_components"><input type="text" class="input_feild" id ="password_two"></div>
    <div id="submit" ><button id="submit_btn" type="submit" onclick="add_student()">SUBMIT</button><div id="error"></div></div>
    
    `
}

function login_student(){
    document.getElementById("occupation").innerHTML=`
    <div id="user_type_one"><button class="type_btns" onclick="login_student()">STUDENT</button></div>
    <div id="user_type_two"><button class="type_btns" onclick="login_teacher()">TEACHER</button></div>
    `
    document.getElementById("submit").innerHTML=`
    <div><button id="submit_btn" type="submit" onclick="get_student()">SUBMIT</button></div>
    <div id="error"></div>
    `
}

function login_teacher(){
    document.getElementById("occupation").innerHTML=`
    <div id="user_type_two"><button class="type_btns" onclick="login_student()">STUDENT</button></div>
    <div id="user_type_one"><button class="type_btns" onclick="login_teacher()">TEACHER</button></div>
    `
    document.getElementById("submit").innerHTML=`
    <div><button id="submit_btn" type="submit" onclick="get_teacher()">SUBMIT</button></div>
    <div id="error"></div>
    `
}

function get_student()
{
    let user_email= document.getElementById("user_email").value
    let user_password=document.getElementById("user_password").value
    let theError=document.getElementById("error")
    /*The code from line 57 to line 84 is used to see if the user has not typed
    their username,email,password,address or phone number. If they don't 
    an error message is displayed
    */
    if(user_email =="")
    {
         theError.innerHTML = "Email required"
    }
    else if(user_password =="")
    {
         theError.innerHTML = "Password required"
         
    }

    //This else if statement below helps is used to see if the email has an "@" and a dot
    else if((!user_email.includes("@")) || (!user_email.includes(".")))
    {
         theError.innerHTML ="Invalid email"
    }
    else{
        //Create object with user data
        let xhttp = new XMLHttpRequest();
        let users_data = {
            "email":user_email,
            "password":user_password,
            "user_type":"student"
        };
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                let get_data=JSON.stringify(xhttp.responseText)
                let data = xhttp.responseText
                console.log(data)
                console.log(get_data)
                let data_err = data.error
                console.log(data)
                console.log(data_err)
                let transform_data= JSON.parse(xhttp.responseText)
                console.log(xhttp.responseText)
                let error_found = parseInt(transform_data.error)
                console.log("err: "+error_found)
                if( error_found == 1){
                    theError.innerHTML="Incorrect password"
                }

                if( error_found == 2){
                    theError.innerHTML="Email does not exist"
                }


                if( error_found == 0){
                    theError.innerHTML="Successfully Logged in"
                    window.location.href="/default/profile"
                }
            }
        };
        xhttp.onerror=function(){
            console.log('Error occured') //Shows error if error occured
        }
        //Send new user data to server
        xhttp.open("POST", "/default/login_user", true);
        xhttp.setRequestHeader("Content-type", "application/json");
        xhttp.send( JSON.stringify(users_data) );
    }
}



function get_teacher()
{
    console.log("finding teacher")
    let user_email= document.getElementById("user_email").value
    let user_password=document.getElementById("user_password").value
    console.log("Email: "+user_email+" , password: "+user_password)
    let theError=document.getElementById("error")



    /*The code from line 57 to line 84 is used to see if the user has not typed
    their username,email,password,address or phone number. If they don't 
    an error message is displayed
    */

    if(user_email =="")
    {
         theError.innerHTML = "Email required"
    }
    else if(user_password =="")
    {
         theError.innerHTML = "Password required"
         
    }

    //This else if statement below helps is used to see if the email has an "@" and a dot
    else if((!user_email.includes("@")) || (!user_email.includes(".")))
    {
         theError.innerHTML ="Invalid email"
    }
    else{
        //Create object with user data
        let xhttp = new XMLHttpRequest();
        let users_data = {
            "email":user_email,
            "password":user_password,
            "user_type":"teacher"
        };
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                let get_data=JSON.stringify(xhttp.responseText)
                let data = xhttp.responseText
                console.log(data)
                console.log(get_data)
                let data_err = data.error
                console.log(data)
                console.log(data_err)
                let transform_data= JSON.parse(xhttp.responseText)
                console.log(xhttp.responseText)
                let error_found = parseInt(transform_data.error)
                console.log("err: "+error_found)
                if( error_found == 1){
                    theError.innerHTML="Incorrect password"
                }

                if( error_found == 2){
                    theError.innerHTML="Email does not exist"
                }


                if( error_found == 0){
                    theError.innerHTML="Successfully Logged in"
                    window.location.href="/default/profile"
                }
            }
        };
        xhttp.onerror=function(){
            console.log('Error occured') //Shows error if error occured
        }
        //Send new user data to server
        xhttp.open("POST", "/default/login_user", true);
        xhttp.setRequestHeader("Content-type", "application/json");
        xhttp.send( JSON.stringify(users_data) );
    }
}

function verify_student_details(name,email,phone,password,renter_password){
    //Set up XMLHttpRequest
    let xhttp = new XMLHttpRequest();
    
    
    //Create object with user data
    let users_data = {
        "name":name,
        "email":email,
        "phone":phone,
        "password":password,
        "renter_password":renter_password,
    }; 
    //Set up function that is called when reply received from server
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let get_data=JSON.stringify(xhttp.responseText)
            let data = xhttp.responseText
            let data_err = data.error
            console.log(data)
            console.log(data_err)
            let transform_data= JSON.parse(xhttp.responseText)
            console.log(xhttp.responseText)
            console.log(transform_data)
            console.log(JSON.stringify(get_data.error))
            console.log(JSON.stringify(get_data["error"]))
            let error_found = parseInt(transform_data.error)
            console.log("err: "+error_found)
            if( error_found == 1){
                document.getElementById("error").innerHTML="email already registered"
            }

            if( error_found == 2){
                document.getElementById("error").innerHTML="name already registered"
            }

            if( error_found == 3){
                document.getElementById("error").innerHTML="phone already registered"
            }

            if( error_found == 0){
                document.getElementById("error").innerHTML="Successfully registered"
            }
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/register_student", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}



function add_student()
{
    let name = document.getElementById("name").value
    let email = document.getElementById("email").value
    let phone = document.getElementById("phone").value
    let password = document.getElementById("password").value
    let renter_password = document.getElementById("password_two").value

    let theError= document.getElementById("error")


    if(name =="")
    {
         theError.innerHTML = "Username required"
         
    }

    /*The code from line 57 to line 84 is used to see if the user has not typed
    their username,email,password,address or phone number. If they don't 
    an error message is displayed
    */

    else if(email =="")
    {
         theError.innerHTML = "Email required"
         
    }

    //This else if statement below helps is used to see if the email has an "@" and a dot
    else if((!email.includes("@")) || (!email.includes(".")))
    {
         theError.innerHTML ="Invalid email"
    }

    else if(phone =="")
    {
         theError.innerHTML = "Phone Number required"
         
    }

    //The else if staement below is used to see if the users input is a number
    else if(isNaN(phone)== true)
    {
         theError.innerHTML ="Invalid number"
    }
    //The else if staement below is used to see if the users entered 10 digits
    else if(phone.length<10 ||phone.length>10)
    {
         theError.innerHTML ="Enter 10 digits"
    }

    else if(password =="")
    {
         theError.innerHTML = "Password required"
         
    }

    else if(renter_password =="")
    {
         theError.innerHTML = "re-ernter the password required"
         
    }

    else if(renter_password != password)
    {
         theError.innerHTML = "Password don't match"
         
    }

    else{
        verify_student_details(name,email,phone,password,renter_password)
        //document.getElementById("error").innerHTML="User registered"
    }


}
//name,email,phone,password,renter_password,subject_selected


function verify_teacher_details(name,email,phone,password,renter_password,subject_selected){
    //Set up XMLHttpRequest
    let xhttp = new XMLHttpRequest();
    
    
    //Create object with user data
    let users_data = {
        "name":name,
        "email":email,
        "phone":phone,
        "password":password,
        "renter_password":renter_password,
        "subject_selected":subject_selected
    }; 
    //Set up function that is called when reply received from server
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let get_data=JSON.stringify(xhttp.responseText)
            let data = xhttp.responseText
            let data_err = data.error
            console.log(data)
            console.log(data_err)
            let transform_data= JSON.parse(xhttp.responseText)
            let error_found = parseInt(transform_data.error)
            console.log("err: "+error_found)
            if( error_found == 1){
                document.getElementById("error").innerHTML="email already registered"
            }

            if( error_found == 2){
                document.getElementById("error").innerHTML="name already registered"
            }

            if( error_found == 3){
                document.getElementById("error").innerHTML="phone already registered"
            }

            if( error_found == 0){
                document.getElementById("error").innerHTML="Successfully registered"
            }
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/register_teacher", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}


function add_teacher()
{

    let name = document.getElementById("name").value
    let email = document.getElementById("email").value
    let phone = document.getElementById("phone").value
    let password = document.getElementById("password").value
    let renter_password = document.getElementById("password_two").value
    let subject_selected = document.getElementById("menu").value
    
    let temp=""
    let present=""
    let theError= document.getElementById("error")
    if(present == "USER_EXISTANT")
    {
         theError.innerHTML = "USER EXISTS"
    }

    //The else if statement below helps us to see if an email exists.
    else if(temp =="EXISTANT")
    {
         theError.innerHTML ="Email Exists"
    }

    else if(subject_selected =="")
    {
         theError.innerHTML = "Please select a subject"
         
    }

    else if(name =="")
    {
         theError.innerHTML = "Username required"
         
    }

    /*The code from line 57 to line 84 is used to see if the user has not typed
    their username,email,password,address or phone number. If they don't 
    an error message is displayed
    */
 

    else if(email =="")
    {
         theError.innerHTML = "Email required"
         
    }

    //This else if statement below helps is used to see if the email has an "@" and a dot
    else if((!email.includes("@")) || (!email.includes(".")))
    {
         theError.innerHTML ="Invalid email"
    }

    else if(phone =="")
    {
         theError.innerHTML = "Phone Number required"
         
    }

    //The else if staement below is used to see if the users input is a number
    else if(isNaN(phone)== true)
    {
         theError.innerHTML ="Invalid number"
    }
    //The else if staement below is used to see if the users entered 10 digits
    else if(phone.length<10 ||phone.length>10)
    {
         theError.innerHTML ="Enter 10 digits"
    }

    else if(password =="")
    {
         theError.innerHTML = "Password required"
         
    }

    else if(renter_password =="")
    {
         theError.innerHTML = "re-ernter the password required"
         
    }

    else if(renter_password != password)
    {
         theError.innerHTML = "Password don't match"
         
    }

    else{
        verify_teacher_details(name,email,phone,password,renter_password,subject_selected)
    }

    
}

function handle_navigation(nav_id,nav_image)
{
    //document.getElementsByClassName("nav_icons").style="background: rgb(0, 145, 0);color: rgb(154, 246, 152);"
    const collection = document.getElementsByClassName("nav_btns");
    for (let i = 0; i < collection.length; i++) {
      collection[i].style = "background: rgb(0, 145, 0);color: rgb(154, 246, 152);";
    }

    const imgaes_collection = document.getElementsByClassName("nav_icons");
    for (let i = 0; i < imgaes_collection.length; i++) {
        image_details=imgaes_collection[i].src
        all_images=image_details.split("/")
        image_names=all_images[all_images.length-1].split(".")
        let end =image_names[0].length -1
        let start =image_names[0].length -2
        let ending=image_names[0].substr(start,end)
        let potential_name=image_names[0].substr(0,start)
        if(ending=="dg"){
            document.getElementById(image_names[0]).src= `../images/${potential_name}.png`
        }
    }

    document.getElementById(nav_id).style="background: rgb(70, 209, 68); color: rgb(0, 80, 8);"
    document.getElementById(nav_image).src= `../images/${nav_image}.png`
}



function work_you()
{
    document.getElementById("word").innerHTML ="workkkkkkkk!"
    console.log("woorr")
}

function send_query(search_query)
{
    let doc_results=document.getElementById("all_results")
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let all_results=`
    <div>
        <h2 style="font-family: Arial;color: rgb(4, 97, 4);">SEARCH RESULTS FOR TEACHERS NAMED: "${search_query}"</h2>
    </div>
    <div>
        <button class="upload_btn" onclick="video_query('${search_query}')">SEE VIDEOS</button>
    </div>

    `
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let get_data=JSON.stringify(xhttp.responseText)
            let data = xhttp.responseText
            console.log(data)
            let transform_data= JSON.parse(xhttp.responseText)
            for(let i=0;i<transform_data.length;i++)
            {
                all_results+=`
                <div class="search_results_found">
                    <div>
                        <div class="results">
                            <div><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/profile.png" alt="" class="results_picture"></div>
                            <div>
                                <h3>NAME: ${transform_data[i].users_name}</h3>
                                <h3>SUBJECT: ${transform_data[i].subject}</h3>
                                <h3>${transform_data[i].ranking}</h3>
                            </div>
                            <div style="padding-top: 10px;">
                                <button class="upload_btn" onclick="view_others_profiles('${transform_data[i].email}','${transform_data[i].ranking}')">PROFILE</button>
                                <button class="upload_btn" onclick="make_subscription('${USERS_EMAIL}','${transform_data[i].email}')">SUBSCRIBE</button>
                                <button class="upload_btn" onclick="new_chat('${USERS_EMAIL}','${transform_data[i].email}')">MESSAGE</button>
                                
                            </div>
                        </div>
                    </div>
                </div>
                
                `
            }
            doc_results.innerHTML=all_results
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    let user_query='/default/search/'+search_query
    xhttp.open("GET", user_query, true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send();
}

function video_query(search_query)
{
    let doc_results=document.getElementById("all_results")
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let all_results=`
    <div>
        <h2 style="font-family: Arial;color: rgb(4, 97, 4);">SEARCH RESULTS FOR VIDEOS NAMED: "${search_query}"</h2>
    </div>
    <div>
        <button class="upload_btn" onclick="send_query('${search_query}')">SEE TEACHERS</button>
    </div>

    `
    
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let get_data=JSON.stringify(xhttp.responseText)
            let data = xhttp.responseText
            console.log(data)
            let transform_data= JSON.parse(xhttp.responseText)
            for(let i=0;i<transform_data.length;i++)
            {
                all_results+=`
                <div class="search_results_found">
                    <div>
                        <div class="results">
                            <div><img src="${transform_data[i].thumbnail_url}" alt="" class="results_picture"></div>
                            <div>
                                <h3>NAME: ${transform_data[i].Name}</h3>
                                
                                
                            </div>
                            <div style="padding-top: 10px;">
                                
                                <button class="upload_btn" onclick="view_others_profiles('${transform_data[i].owner_email}','${transform_data[i].ranking}')">PROFILE</button>
                                <button class="upload_btn" onclick='display_video("${transform_data[i].video_url}","${transform_data[i].Name}","${transform_data[i].description}")'>WATCH</button>
                                <button class="upload_btn" onclick="new_chat('${USERS_EMAIL}','${transform_data[i].owner_email}')">MESSAGE</button>
                                
                            </div>
                        </div>
                    </div>
                </div>
                
                `
            }
            doc_results.innerHTML=all_results
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    let user_query='/default/video_search/'+search_query
    xhttp.open("GET", user_query, true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send();
}


function display_search(search_query)
{
    let results_found=`
    <link rel="stylesheet" href="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/css/search_results.css">
    <div id="navigation_bar">

    </div>

    <div id="full_body">
        <div id="section_1">
            <h1>SEARCH RESULTS</h1>
        </div>
        <div id="all_results">
        <h1>Loading results.....</h1>
        </div>
    </div>
    `
    document.getElementById("page_body").innerHTML=results_found
    send_query(search_query)
    
}


function display_video(video_url,video_name,video_description)
{
    let video_detail=`
    <link rel="stylesheet" href="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/css/watch_video.css">
    <div id="navigation_bar">
    </div>
    <div id="full_body">
        <div id="section_1">
            <div id="intro_div">
                <h1 id="intro_label">CURRENTLY WATCHING</h1>
            </div>
            <div id="name_div">
                <h1 id="name_label">${video_name}</h1>
            </div>
        </div>

        <div id="section_2">
            <div id="video_div">
                <video controls id="user_video">
                    <source src="${video_url}" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </div>
            <div id="description_div">
                <div id="description_title">DESCRIPTION</div>
                <div id="description_details">
                    ${video_description}
                </div>
            </div>
        </div>
    </div>
    `
    document.getElementById("page_body").innerHTML = video_detail
    generate_navagation()
}

function get_search()
{
    let search_query=document.getElementById("search_bar").value
    display_search(search_query)
    generate_navagation()

}

function generate_navagation()
{
    let navigation_details=`
    <div id="user_brief">
        <img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/profile.png" id="user_image">
        <h3 id="user_name"></h3>
    </div>
    <div id="search"><input type="text" name="" id="search_bar"><button id="search_btn" onclick="get_search()">SEARCH</button></div>
    <div><a href="/default/profile"><button class="nav_btns" id="nav_profile"><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/user.png" class="nav_icons" id="userdg">PROFILE</button></a></div>
    <div><a href="/default/view_messages"><button class="nav_btns" id="nav_messages"><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/paper-plane.png" class="nav_icons" id="paper-planedg">MESSAGES</button></a></div>
    <div><a href="/default/schedule"><button class="nav_btns" id="nav_schedule" onclick="handle_navigation('nav_schedule','scheduledg')"><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/schedule.png" class="nav_icons" id="scheduledg">SCHEDULE</button></a></div>
    <div>
        <button class="nav_btns"  id="nav_profile" onclick="logout()">
            <img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/logout.png" class="nav_icons">LOG OUT
        </button>
    </div>
    `
    document.getElementById("navigation_bar").innerHTML=navigation_details
}


///default
function view_others_profiles(user_email,ranking)
{
    let others_page=`
    <link rel="stylesheet" href="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/css/other_profile.css">
    <div id="navigation_bar">
    </div>
    <div id="full_body">
        <div id="section_1">
            <div>
                <img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/profile.png" id="profile_pic">
                <span><h1 id="user_name_major"></h1></span>
                <span><button id="upload_btn" onclick="make_subscription('${USERS_EMAIL}','${user_email}')">SUBSCRIBE</button></span>
            </div>
            <div></div>
        </div>

        <div id="section_2">
            <div>
                <h1>ABOUT</h1>
                <p  id="about"></p>
            </div>
            <div id="ranking">
                <h1>${ranking}</h1>
            </div>
        </div>
        <div id="section_3">
            <div id="video_title">
                <div><h1 style="text-align: right;">VIDEOS</h1></div>
                
            </div>
            <div id="videos_section">
            </div>
            
        </div>
    </div>
    `
    document.getElementById("page_body").innerHTML=others_page
    generate_navagation()
    other_profile(user_email)
    usersVideos(user_email)
}


function other_profile(user_email)
{
    let doc_name=document.getElementById("user_name_major")
    let doc_description=document.getElementById("about")
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":user_email,
        "user_type":"teacher"
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let get_data=JSON.stringify(xhttp.responseText)
            let data = xhttp.responseText
            console.log(data)
            let transform_data= JSON.parse(xhttp.responseText)
            doc_name.innerHTML=transform_data.user_name
            doc_description.innerHTML=transform_data.description
            
            console.log(xhttp.responseText)
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/profile_details", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

function usersVideos(user_email)
{
    let doc_videos=document.getElementById("videos_section")
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":user_email,
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            //let get_data=JSON.stringify(xhttp.responseText)
            let data = xhttp.responseText
            //console.log(get_data)
            let transform_data= JSON.parse(xhttp.responseText)
            console.log(typeof(transform_data))
            
            //console.log(typeof(transform_data))
            let video_display=''
            for(let i=0;i<transform_data.length;i++)
            {
                video_display+=`
                <div>
                    <a onclick='display_video("${transform_data[i].video_url}","${transform_data[i].Name}","${transform_data[i].description}")'><img src="${transform_data[i].thumbnail_url}" alt="${transform_data[i].Name}" class="thumbnail"></a>
                    <a onclick='display_video("${transform_data[i].video_url}","${transform_data[i].Name}","${transform_data[i].description}")'><p id="video_headings">${transform_data[i].Name}</p></a>
                </div>
                `
            }
            doc_videos.innerHTML=video_display
            //console.log(xhttp.responseText)
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/teachers_videos", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}


function chat_messages(message_id)
{
    console.log("message_id: "+message_id)
    let doc_results=document.getElementById("msg_display")
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {"message_id":message_id};
    let all_results=""
    console.log("reqssbody: "+JSON.stringify(users_data))
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let get_data=JSON.stringify(xhttp.responseText)
            let data = xhttp.responseText
            console.log(get_data)
            let transform_data= JSON.parse(xhttp.responseText)

            for(let i=1;i<transform_data.length;i++)
            {
                all_results+=`
                <div class="holding_msg">
                    <div class="msg_box">
                        <div class="msg_name">
                        ${transform_data[i].other_name}
                        </div>
                        <div>
                            ${transform_data[i].message}
                        </div>
                    </div>
                </div>
                   
                
                `
            }
            doc_results.innerHTML=all_results
            scrollDown()
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/chat_messages", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(users_data));
}


function display_messaging(receiver_id)
{
    let messaging_body=`
    <link rel="stylesheet" href="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/css/chat.css">
    <div id="navigation_bar">
    </div>
    <div id="full_body">
        <div id="section_1">
            <h1 id="others_name">CHAT</h1>
        </div>
        <div id="all_results">
            <div id="messaging_section">
                <div id="msg_display">
                <h1>Loading messages.....</h1>
                </div>
                <div id="send_section"> 
                    <div><input type="text" id="message_input"></div>
                    <div><button class="upload_btn" onclick="send_messages('${receiver_id}')">SEND</button></div>
                </div>
            </div>
        </div>
    </div>
    `//chat_messages(receiver_id)

    document.getElementById("page_body").innerHTML = messaging_body
    generate_navagation()

    //generate nav_bar
}

function output_chat(message_id,receiver_id)
{
    display_messaging(receiver_id)
    chat_messages(message_id)
}


function send_messages(receiver_id)
{
    let message=document.getElementById("message_input").value
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "sender_id":USERS_EMAIL,
        "receiver_id":receiver_id,
        "message":message
    };
    console.log("reqssbody: "+JSON.stringify(users_data))
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let get_data=JSON.stringify(xhttp.responseText)
            let data = xhttp.responseText
            console.log(get_data)
            let transform_data= JSON.parse(xhttp.responseText)
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/send_message", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(users_data));
}



function new_chat(user_one,user_two)
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "user_one":user_one,
        "user_two":user_two
    };
    console.log("reqssbody: "+JSON.stringify(users_data))
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let get_data=JSON.stringify(xhttp.responseText)
            let data = xhttp.responseText
            console.log(get_data)
            let transform_data= JSON.parse(xhttp.responseText)
            console.log("MSG ID"+transform_data.message_id)
            let msg_id=transform_data.message_id
            display_messaging(user_two)
            chat_messages(msg_id)
            open_messaging(msg_id)
            scrollDown()
            
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/set_up_messaging", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(users_data));
}


function open_messaging(user_email){
    let sock = new WebSocket(" wss://9qakz7sib5.execute-api.us-east-1.amazonaws.com/production")

    sock.addEventListener('open', e => {
        console.log("Connected to server")
        console.log(e)
        //initialConnection(email)
        let msgObject = {action: "initialConnection",message_id: user_email};
        sock.send(JSON.stringify(msgObject));
    })

    sock.addEventListener('message', e => {
        console.log("Message from server")
        let dataParsed=JSON.parse(e.data)
        console.log(e.data)
        update_messages(dataParsed.sender_name,dataParsed.message)
              

    })

    sock.addEventListener('error', e => {
        console.error("Error: ",e)
    })

}

function update_messages(name,message)
{
    let doc_results=document.getElementById("msg_display")
    let new_msg=`
    <div class="holding_msg">
        <div class="msg_box">
            <div class="msg_name">
            ${name}
            </div>
            <div>
                ${message}
            </div>
        </div>
    </div>
    `
    doc_results.innerHTML+=new_msg
    scrollDown()

}

function scrollDown()
{
    let msg_body = document.getElementById("msg_display")
    let doc_height = document.getElementById("msg_display").scrollHeight
    msg_body.scroll(0,doc_height)
    console.log("hiiiiiit: "+doc_height)
    //msg_display
}


function make_subscription(user_one,user_two)
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "student_id":user_one,
        "teacher_id":user_two
    };
    console.log("reqssbody: "+JSON.stringify(users_data))
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let get_data=JSON.stringify(xhttp.responseText)
            let data = xhttp.responseText
            console.log(get_data)
            let transform_data= JSON.parse(xhttp.responseText)
            alert("SUCCESSFUL SUBSCRIPTION")
            
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
        alert("ERROR: UNSUCCESSFUL SUBSCRIPTION")
    }
    //Send new user data to server
    xhttp.open("POST", "/default/make_request", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(users_data));
}
