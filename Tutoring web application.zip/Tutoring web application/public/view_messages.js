window.onload = check_login()
let USERS_EMAIL = ""

/*The function below is used to check if a user is signed in.*/
function check_login()
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":"",
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            let current_status = parseInt(transform_data.status)
            if( current_status == 1)
            {
                let mail=transform_data.mail
                USERS_EMAIL=mail
                get_my_messages()
            }

            if( current_status == 0)
            {
                window.location.href="/default/home"
            }
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/check_login", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/*The function below is used to display all the messages that the current user signed in has had with other users in the past.*/
function get_my_messages()
{
    let doc_results=document.getElementById("all_results")
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {"email":USERS_EMAIL};
    let all_results=""
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            for(let i=0;i<transform_data.length;i++)
            {
                all_results+=`
                <div class="search_results_found">
                    <div>
                        <div class="results">
                            <div><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/profile.png" alt="" class="results_picture"></div>
                            <div>
                                <h3>NAME: ${transform_data[i].other_name}</h3>
                            </div>
                            <div style="padding-top: 10px;">
                                <button class="upload_btn" onclick="view_others_profiles('${transform_data[i].email}')">PROFILE</button>
                                <button class="upload_btn" onclick="output_chat('${transform_data[i].message_id}','${transform_data[i].receiver_id}');open_messaging('${transform_data[i].message_id}')">MESSAGE</button>
                            </div>
                        </div>
                    </div>
                </div>
                `
            }
            doc_results.innerHTML=all_results
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/my_messages", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(users_data));
}


/*The function below is used to logout the users*/
function logout()
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":USERS_EMAIL,
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href="/default/home"
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/logout", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}