window.onload = check_login()
let USERS_EMAIL = ""
let USER_TYPE ="teacher"

/*The function below is used to check if a user is signed in.*/
function check_login()
{
    handle_navigation('nav_schedule','scheduledg')
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":"",
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            let current_status = parseInt(transform_data.status)
            if( current_status == 1)
            {
                let uType=transform_data.type
                if(uType=="teacher")
                {
                    let mail=transform_data.mail
                    USERS_EMAIL=mail
                    show_requests()

                }
                else
                {
                    window.location.href="/default/students_schedule"
                }
            }

            if( current_status == 0)
            {
                window.location.href="/default/home"
            }
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/check_login", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/*The function below is used to show the teacher all the requests sent to them by students.*/
function show_requests()
{
    //Create object with user data
    let doc_results=document.getElementById("all_results")
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":USERS_EMAIL
    };
    let all_results=`
    <div>
        <div>
            <a href="/default/schedule_class"><button class="upload_btn" >VIEW STUDENTS</button></a>
        </div>
    </div>
    `
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            for(let i=0;i<transform_data.length;i++)
            {
                let student_name=transform_data[i].student_name
                let student_request_id=transform_data[i].student_request_id
                let formattedDate=transform_data[i].formattedDate
                let formattedTime=transform_data[i].formattedTime
                let unixTimestamp=transform_data[i].unixTimestamp
                let student_id=transform_data[i].student_id
                all_results+=`
                <div class="search_results_found">
                    <div>
                        <div class="results">
                            <div><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/profile.png" alt="" class="results_picture"></div>
                            <div>
                                <h3>NAME: ${student_name}</h3>
                                <h3>DATE: ${formattedDate}</h3>
                                <h3>TIME: ${formattedTime}</h3>
                                
                            </div>
                            <div style="padding-top: 10px;">
                                <button class="upload_btn" onclick="update_status('${student_request_id}',${unixTimestamp},${1},'${student_id}','${USERS_EMAIL}')">ACCEPT</button>
                                <button class="upload_btn" onclick="update_status('${student_request_id}',${unixTimestamp},${-1},'${student_id}','${USERS_EMAIL}')">DECLINE</button>
                            </div>
                        </div>
                    </div>
                </div>
                `
            }
            doc_results.innerHTML=all_results
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/get_requests", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/* The function below is used to update the decision that a teacher made about a students request for tutoring sessions.*/
function update_status(req_id,req_date,new_status,student_id,teacher_id)
{
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "req_id":req_id,
        "req_date":req_date,
        "new_status":new_status,
        "student_id":student_id,
        "teacher_id":teacher_id
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href="/default/schedule"
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/handle_request", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}


/*The function below is used to logout the users*/
function logout()
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":USERS_EMAIL,
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href="/default/home"
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/logout", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}
