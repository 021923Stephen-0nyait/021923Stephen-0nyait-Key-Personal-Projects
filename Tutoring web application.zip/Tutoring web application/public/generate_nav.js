window.onload = generate_navagation()

/*The function below is used to generate the navigation bar on every page that loads except the login and registration pages.*/
function generate_navagation()
{
    let navigation_details=`
    <div id="user_brief">
        <img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/profile.png" id="user_image">
        <h3 id="user_name"></h3>
    </div>
    <div id="search"><input type="text" name="" id="search_bar"><button id="search_btn" onclick="get_search()">SEARCH</button></div>
    <div><a href="/default/profile"><button class="nav_btns" id="nav_profile"><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/user.png" class="nav_icons" id="userdg">PROFILE</button></a></div>
    <div><a href="/default/view_messages"><button class="nav_btns" id="nav_messages"><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/paper-plane.png" class="nav_icons" id="paper-planedg">MESSAGES</button></a></div>
    <div><a href="/default/schedule"><button class="nav_btns" id="nav_schedule" onclick="handle_navigation('nav_schedule','scheduledg')"><img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/schedule.png" class="nav_icons" id="scheduledg">SCHEDULE</button></a></div>
    <div>
        <button class="nav_btns"  id="nav_profile" onclick="logout()">
            <img src="https://cst3990-c0ursew0rk-2-tut0ringp1ug.s3.amazonaws.com/images/logout.png" class="nav_icons">LOG OUT
        </button>
    </div>
    `
    document.getElementById("navigation_bar").innerHTML=navigation_details
}
