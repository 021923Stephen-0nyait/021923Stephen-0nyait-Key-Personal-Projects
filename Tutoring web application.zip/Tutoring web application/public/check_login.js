window.onload = check_login()
let USERS_EMAIL = ""
let USER_TYPE ="teacher"

/*The function below is used to check if a user is signed in.*/
function check_login()
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":"",
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            let current_status = parseInt(transform_data.status)
            if( current_status == 1)
            {
                let mail=transform_data.mail
                let uType=transform_data.type
                if(uType=="teacher")
                {
                    USERS_EMAIL=mail
                    getProfile()
                    getMyVideos()
                }
                else
                {
                    window.location.href="/default/student_profile"
                }
            }

            if( current_status == 0)
            {
                window.location.href="/default/home"
            }
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/check_login", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/*The function below is used to get the profile details of the current teacher signed into the current device.*/
function getProfile()
{
    let doc_name=document.getElementById("user_name_major")
    let doc_mini_name=document.getElementById("user_name")
    let doc_description=document.getElementById("about")
    let my_ranking=document.getElementById("my_ranking")
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":USERS_EMAIL,
        "user_type":USER_TYPE
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            doc_name.innerHTML=transform_data.user_name
            doc_mini_name.innerHTML=transform_data.user_name
            doc_description.innerHTML=transform_data.description
            my_ranking.innerHTML=transform_data.ranking
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/profile_details", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/*The function below is used to get all the videos belonging to the current teacher signed into the current device.*/
function getMyVideos()
{
    let doc_videos=document.getElementById("videos_section")
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":USERS_EMAIL,
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let transform_data= JSON.parse(xhttp.responseText)
            let video_display=''
            for(let i=0;i<transform_data.length;i++)
            {
                video_display+=`
                <div>
                    <a onclick='display_video("${transform_data[i].video_url}","${transform_data[i].Name}","${transform_data[i].description}")'><img src="${transform_data[i].thumbnail_url}" alt="${transform_data[i].Name}" class="thumbnail"></a>
                    <a onclick='display_video("${transform_data[i].video_url}","${transform_data[i].Name}","${transform_data[i].description}")'><p id="video_headings">${transform_data[i].Name}</p></a>
                </div>
                `
            }
            doc_videos.innerHTML=video_display
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/teachers_videos", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}


/*The function below is used to play a specified video*/
function playVideo(video_id)
{
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "video_id":video_id
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/video_body", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}

/*The function below is used to logout the users*/
function logout()
{
    //Create object with user data
    let xhttp = new XMLHttpRequest();
    let users_data = {
        "email":USERS_EMAIL,
    };
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href="/default/home"
        }
    };
    xhttp.onerror=function(){
        console.log('Error occured') //Shows error if error occured
    }
    //Send new user data to server
    xhttp.open("POST", "/default/logout", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send( JSON.stringify(users_data) );
}