const express = require('express')
const app = express()
const bodyParser=require('body-parser')
let {create_teacher_folder,create_student_folder} = require("backend_functions/bucket_handler")
let {find_email,find_name,find_phone,put_teacher_data}=require("backend_functions/regiser_user")
let {find_student_email,find_student_name,find_student_phone,put_student_data}=require("backend_functions/register_student")
let {handle_login,verify_login,profile_details,logout,upload_media,upload_picture,final_upload,teachers_videos,video_body,teacher_search,video_search,my_messages,chat_messages,send_message,set_up_messaging,make_request,get_requests,handle_request,teachers_students,store_meeting,students_meetings,student_decision,get_students_teachers,update_ranking}=require("backend_functions/server_functions")
const serverless = require('serverless-http')
const AWS = require("aws-sdk");
const multer = require('multer');
const path = require('path');
const fs = require('fs');

//Tell AWS about region
AWS.config.update({
    region: "us-east-1"
});

//the middle where below is used to help to store files
const storage = multer.diskStorage({
    filename: function (req, file, cb) {
      // set the filename for uploaded files
      console.log("ext: "+ path.extname(file.originalname))
      cb(null, file.originalname+ path.extname(file.originalname));
    }
  });
  
const upload = multer({ storage: storage });

app.use(bodyParser.json())
app.use(express.static('public'))

/* The request handler below is used to authenicate users and sign the users in if the authenication is passed*/
app.post("/login_user",handle_login)

/* The request handler below is used to check if the user is already signed into the  platform*/
app.post("/check_login",verify_login)

/* The request handler below is used to get the users details for their profile*/
app.post("/profile_details",profile_details)

/* The request handler below is used to logout the user*/
app.post("/logout",logout)

/* The request handler below is used to get videos that users upload and store them on Amazon S3 Bucket*/
app.post("/upload_media",upload.single("myVideo"),upload_media)

/* The request handler below is used to get images that users upload and store them on Amazon S3 Bucket*/
app.post("/upload_picture",upload.single("myPicture"),upload_picture)

/* The request handler below is used to store a the details of a video when a teacher uploads it*/
app.post("/final_upload",final_upload)

/* The request handler below is used to get all the videos of a specific teacher*/
app.post("/teachers_videos",teachers_videos)

/* The request handler below is used to get all the details of a specific video*/
app.post("/video_body",video_body)

/* The request handler below is used to find users with a given name*/
app.get('/search/:search_query',teacher_search)

/* The request handler below is used to find videos with the given name.*/
app.get('/video_search/:search_query',video_search)

/* The request handler below is used to get all the other users that the user has started messaging.*/
app.post("/my_messages",my_messages)

/* The request handler below is used to get all the messages between two users.*/
app.post("/chat_messages",chat_messages)

/* The request handler below is used to store the messages sent between two users.*/
app.post("/send_message",send_message)

/* The request handler below is used to initiate a message between two users it will either get the id for all
the messages between two users or create a new id for the messages between two users.
*/
app.post("/set_up_messaging",set_up_messaging)

/* The request handler below is used for students to request for lessons from teachers.*/
app.post("/make_request",make_request)

/* The request handler below is used to get all the requests that a teacher has been sent by students.*/
app.post("/get_requests",get_requests)

/* The request handler below is used to handle decisions made by teachers about whether or not a students has been
allowed to be tutored by the given teacher.
*/
app.post("/handle_request",handle_request)

/* The request handler below is used to get all the teachers under a student.*/
app.post("/teachers_students",teachers_students)

/* The request handler below is used to schedule a meeting between a student and a teacher and store this in the database.*/
app.post("/store_meeting",store_meeting)

/* The request handler below is used to get all the meetings that a student has with their teacher.*/
app.post("/students_meetings",students_meetings)

/* The request handler below is used to update the students decision about whether or not a meeting took place.*/
app.post("/student_decision",student_decision)

/* The request handler below is used to get all the sessions that a student had with a teacher*/
app.post("/get_students_teachers",get_students_teachers)

/* The request handler below is used to give a rating to a tutoring session that a student had with a teacher.*/
app.post("/update_ranking",update_ranking)

/* The request handler below is used to register a teacher to the platform*/
app.post("/register_teacher",(req,res)=>{
    let teachers_data= req.body
    let user_name = teachers_data.name
    let email = teachers_data.email
    let phone = teachers_data.phone
    console.log(typeof(phone))
    find_email(email).then(
        function(value){
            if(value>0){
                console.log("error 1")
                res.send(JSON.stringify({"error":1}))

            }
            if(value<=0){
                find_name(user_name).then(
                    function(value_two){
                        if(value_two>0){
                            console.log("error 2")
                            res.send(JSON.stringify({"error":2}))
                        }
                        if(value_two<=0){
                            console.log("part 2")
                            find_phone(phone).then(
                                function(value_three){
                                    console.log("part 3")
                                    if(value_three>0){
                                        console.log("error 3")
                                        res.send(JSON.stringify({"error":3}))
                                    }
                                    if(value_three<=0){
                                        console.log("End")
                                        
                                        create_teacher_folder(email)
                                        put_teacher_data(user_name,phone,teachers_data.subject_selected,email,teachers_data.password)
                                        
                                        res.send(JSON.stringify({"error":0}))
                                    }
                                }
                            )
                        }
                    }
                )
            }
        }
      );
    
})

/* The request handler below is used to register students into the platform*/
app.post("/register_student",(req,res)=>{
    let student_data= req.body
    let user_name = student_data.name
    let email = student_data.email
    let phone = student_data.phone
    console.log(typeof(phone))
    find_student_email(email).then(
        function(value){
            if(value>0){
                console.log("error 1")
                res.send(JSON.stringify({"error":1}))

            }
            if(value<=0){
                find_student_name(user_name).then(
                    function(value_two){
                        if(value_two>0){
                            console.log("error 2")
                            res.send(JSON.stringify({"error":2}))
                        }
                        if(value_two<=0){
                            console.log("part 2")
                            find_student_phone(phone).then(
                                function(value_three){
                                    console.log("part 3")
                                    if(value_three>0){
                                        console.log("error 3")
                                        res.send(JSON.stringify({"error":3}))
                                    }
                                    if(value_three<=0){
                                        console.log("End")
                                        
                                        create_student_folder(email)
                                        put_student_data(user_name,phone,email,student_data.password)
                                        //name,Phone,Email,password
                                        
                                        res.send(JSON.stringify({"error":0}))
                                    }
                                }
                            )
                        }
                    }
                )
            }
        }
      );
    
})

/* The request handler below is used to get the login page*/
app.get('/home',(req,res)=>{
    console.log(path.resolve("public","login.html"))
    res.sendFile(path.resolve("public","login.html"))
})

/* The request handler below is used to get the registration page*/
app.get('/register',(req,res)=>{
    console.log(path.resolve("public","register.html"))
    res.sendFile(path.resolve("public","register.html"))
})

/* The request handler below is used to get the page where teachers will be able to upload videos*/
app.get('/video_upload',(req,res)=>{
    console.log(path.resolve("public","video_uploading.html"))
    res.sendFile(path.resolve("public","video_uploading.html"))
})

/* The request handler below is used to get the teachers profile page */
app.get('/profile',(req,res)=>{
    console.log(path.resolve("public","profile.html"))
    res.sendFile(path.resolve("public","profile.html"))
})

/* The request handler below is used to get the messaging page*/
app.get('/view_messages',(req,res)=>{
    console.log(path.resolve("public","view_messages.html"))
    res.sendFile(path.resolve("public","view_messages.html"))
})

/* The request handler below is used to get the students profile*/
app.get('/student_profile',(req,res)=>{
    console.log(path.resolve("public","student_profile.html"))
    res.sendFile(path.resolve("public","student_profile.html"))
})

/* The request handler below is used to get the page which displays the number of lessons which a student has with a teacher for the teachers*/
app.get('/schedule',(req,res)=>{
    console.log(path.resolve("public","scheduling.html"))
    res.sendFile(path.resolve("public","scheduling.html"))
})

/* The request handler below is used to get the page where teachers can schedule a class with a student*/
app.get('/schedule_class',(req,res)=>{
    console.log(path.resolve("public","schedule_class.html"))
    res.sendFile(path.resolve("public","schedule_class.html"))
})

/* The request handler below is used to get all the classes that a student has for the students*/
app.get('/students_schedule',(req,res)=>{
    console.log(path.resolve("public","students_schedule.html"))
    res.sendFile(path.resolve("public","students_schedule.html"))
})

/* The request handler below is used to get the page where students will rank tutoring sessions that they had with their teachers*/
app.get('/ranking_page',(req,res)=>{
    console.log(path.resolve("public","ranking.html"))
    res.sendFile(path.resolve("public","ranking.html"))
})

/* The request handler below is used to redirect the users to the login page if the request for a url that does not exist*/
app.get('/*',(req,res)=>{
    console.log(path.resolve("public","login.html"))
    res.sendFile(path.resolve("public","login.html"))
})



module.exports.handler = serverless(app)