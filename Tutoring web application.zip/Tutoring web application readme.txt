TUTORING WEB APPLICATION
The project developed is a for the Tutoring Web Application. The application is designed to connect students with tutors for online lessons.
 It is built using AWS (Amazon Web Services) and incorporates various features to enhance the tutoring experience. The following sections provide an overview of the application's
features and the technologies employed.

FEATURES
1. Country-Based Tutor Requests: Students can only request lessons from tutors who are located in their country, ensuring localized educational support.
2. Messaging System: Students can communicate with tutors via a messaging system to discuss their courses, ask questions, and address specific concerns.
3. Meeting Scheduling: Teachers can schedule meetings with tutors, simplifying coordination and ensuring mutually convenient tutoring sessions.
4. Lesson Confirmation: Students are required to confirm that tutoring sessions have taken place, establishing accountability and maintaining accurate records.
5. Video Upload for Tutor Promotion: Teachers can post videos to showcase their tutoring skills and attract more students.
6. Teacher Rating System: Students can provide ratings and feedback on their tutoring experience, facilitating quality control and aiding future student selections.
7. Teacher Search Functionality: Students can search for tutors based on specific criteria such as subject, availability, rating, and location.
8. Responsive Design for Mobile: The web application is optimized for mobile devices, ensuring usability and accessibility on phones.
9. User Registration: Users can register as either students or teachers to access the relevant features and functionalities.
10. Profile Viewing: Users can view profiles of tutors and students, gaining insight into qualifications, expertise, teaching experience, and ratings.
11. Monthly Subscriptions: Students can opt for a monthly subscription plan to avail themselves of tutoring services.

TECHNOLOGIES USED
The Tutoring Web Application utilizes the following AWS services and technologies:
- Amazon CloudWatch: Monitors and logs application performance for operational efficiency.
- Amazon S3 Bucket: Stores and serves static content such as images, videos, and media files.
- API Gateway: Provides a scalable and secure API endpoint for accessing application functionalities and data.
- AWS Lambda: Executes serverless functions responsible for specific tasks and processes within the application.
- DynamoDB: A NoSQL database service used for storing and retrieving user data, tutor information, student records, ratings, and lesson details.
These technologies collectively form a robust and scalable infrastructure, enabling seamless user experiences and efficient data management.

CONTRIBUTORS
Stephen Onyait
